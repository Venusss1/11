# -*- coding: utf-8 -*-
"""
实验6：图像分类实验 - MindSpore
任务：使用 MindSpore 构建基于 ResNet 的 CIFAR-10 图像分类模型，并保存训练结果。

运行建议：
1. 先完成 MindSpore 环境安装，并确认 `import mindspore` 不报错。
2. 第一次运行会下载 CIFAR-10 binary version 数据集。
3. CPU 上训练 ResNet50 会比较慢，可先把 --epochs 设为 1 或 2 试运行。
4. 正式写报告时，以本脚本实际生成的 summary.json、history.csv 和图片为准。
"""

import argparse
import json
import os
import pickle
import tarfile
import time
import urllib.request
from pathlib import Path
from typing import List, Optional, Tuple, Type, Union

import matplotlib.pyplot as plt
import mindspore as ms
import mindspore.dataset as ds
import mindspore.dataset.transforms as transforms
import mindspore.dataset.vision as vision
import numpy as np
from mindspore import Tensor, nn, ops
from mindspore.common.initializer import HeNormal, Normal


CIFAR10_URL = (
    "https://mindspore-website.obs.cn-north-4.myhuaweicloud.com/"
    "notebook/datasets/cifar-10-binary.tar.gz"
)

CLASSES = [
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck"
]


def set_seed(seed: int = 42) -> None:
    """设置随机种子，增强实验可复现性。"""
    np.random.seed(seed)
    ms.set_seed(seed)
    ds.config.set_seed(seed)


def load_cifar10_python(py_dir: Path, usage: str) -> Tuple[np.ndarray, np.ndarray]:
    """从 CIFAR-10 Python 版（pickle）加载图像与标签。"""
    images_list = []
    labels_list = []

    if usage == "train":
        for i in range(1, 6):
            batch_path = py_dir / f"data_batch_{i}"
            with open(batch_path, "rb") as f:
                batch = pickle.load(f, encoding="bytes")
            images_list.append(batch[b"data"])
            labels_list.extend(batch[b"labels"])
    else:
        with open(py_dir / "test_batch", "rb") as f:
            batch = pickle.load(f, encoding="bytes")
        images_list.append(batch[b"data"])
        labels_list = batch[b"labels"]

    images = np.vstack(images_list).reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
    labels = np.array(labels_list, dtype=np.int32)
    return images, labels


def resolve_cifar10_dataset(root: str) -> Tuple[str, str]:
    """
    解析 CIFAR-10 数据目录。
    返回 (dataset_dir, dataset_format)，format 为 "bin" 或 "py"。
    """
    root_path = Path(root)

    py_dir = root_path / "cifar-10-batches-py"
    if py_dir.exists() and (py_dir / "data_batch_1").exists():
        print(f"[Info] 复用已有 CIFAR-10 Python 数据集：{py_dir}")
        return str(py_dir), "py"

    bin_dir = root_path / "cifar-10-batches-bin"
    if bin_dir.exists():
        print(f"[Info] 复用已有 CIFAR-10 binary 数据集：{bin_dir}")
        return str(bin_dir), "bin"

    return download_and_extract_cifar10(root), "bin"


def download_and_extract_cifar10(root: str) -> str:
    """
    下载并解压 CIFAR-10 binary version。
    返回 Cifar10Dataset 所需的数据目录。
    """
    root_path = Path(root)
    data_dir = root_path / "cifar-10-batches-bin"

    if data_dir.exists():
        print(f"[Info] CIFAR-10 数据集已存在：{data_dir}")
        return str(data_dir)

    root_path.mkdir(parents=True, exist_ok=True)
    archive_path = root_path / "cifar-10-binary.tar.gz"

    if not archive_path.exists():
        print("[Info] 正在下载 CIFAR-10 数据集，首次运行可能需要几分钟...")
        urllib.request.urlretrieve(CIFAR10_URL, archive_path)
        print(f"[Info] 下载完成：{archive_path}")

    print("[Info] 正在解压 CIFAR-10 数据集...")
    with tarfile.open(archive_path, "r:gz") as tar:
        tar.extractall(root_path)

    if not data_dir.exists():
        raise FileNotFoundError(f"未找到解压后的数据目录：{data_dir}")

    print(f"[Info] 数据集准备完成：{data_dir}")
    return str(data_dir)


def _apply_cifar10_transforms(
    dataset,
    usage: str,
    image_size: int,
    batch_size: int,
    workers: int
):
    image_trans = []
    if usage == "train":
        image_trans += [
            vision.RandomCrop((32, 32), (4, 4, 4, 4)),
            vision.RandomHorizontalFlip(prob=0.5),
        ]

    image_trans += [
        vision.Resize((image_size, image_size)),
        vision.Rescale(1.0 / 255.0, 0.0),
        vision.Normalize(
            mean=[0.4914, 0.4822, 0.4465],
            std=[0.2023, 0.1994, 0.2010]
        ),
        vision.HWC2CHW(),
    ]

    label_trans = transforms.TypeCast(ms.int32)

    dataset = dataset.map(
        operations=image_trans,
        input_columns="image",
        num_parallel_workers=workers
    )
    dataset = dataset.map(
        operations=label_trans,
        input_columns="label",
        num_parallel_workers=workers
    )
    return dataset.batch(batch_size, drop_remainder=False)


def create_dataset_cifar10(
    dataset_dir: str,
    usage: str,
    image_size: int,
    batch_size: int,
    workers: int,
    dataset_format: str = "bin"
):
    """
    创建 CIFAR-10 训练集或测试集。
    usage: "train" 或 "test"
    """
    if dataset_format == "py":
        images, labels = load_cifar10_python(Path(dataset_dir), usage)

        def data_generator():
            for image, label in zip(images, labels):
                yield image, np.int32(label)

        dataset = ds.GeneratorDataset(
            source=data_generator,
            column_names=["image", "label"],
            shuffle=(usage == "train"),
            num_parallel_workers=workers
        )
    else:
        dataset = ds.Cifar10Dataset(
            dataset_dir=dataset_dir,
            usage=usage,
            num_parallel_workers=workers,
            shuffle=(usage == "train")
        )

    return _apply_cifar10_transforms(
        dataset, usage, image_size, batch_size, workers
    )


def conv3x3(in_channels: int, out_channels: int, stride: int = 1):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        pad_mode="pad",
        padding=1,
        has_bias=False,
        weight_init=HeNormal()
    )


def conv1x1(in_channels: int, out_channels: int, stride: int = 1):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=1,
        stride=stride,
        pad_mode="pad",
        padding=0,
        has_bias=False,
        weight_init=HeNormal()
    )


class Bottleneck(nn.Cell):
    """ResNet50 使用的 Bottleneck 残差块。"""
    expansion = 4

    def __init__(
        self,
        in_channels: int,
        channels: int,
        stride: int = 1,
        down_sample: Optional[nn.Cell] = None
    ):
        super().__init__()
        out_channels = channels * self.expansion
        self.conv1 = conv1x1(in_channels, channels)
        self.bn1 = nn.BatchNorm2d(channels)
        self.relu = nn.ReLU()

        self.conv2 = conv3x3(channels, channels, stride=stride)
        self.bn2 = nn.BatchNorm2d(channels)

        self.conv3 = conv1x1(channels, out_channels)
        self.bn3 = nn.BatchNorm2d(out_channels)

        self.down_sample = down_sample

    def construct(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.down_sample is not None:
            identity = self.down_sample(x)

        out = out + identity
        out = self.relu(out)
        return out


class ResNet(nn.Cell):
    """
    适配 CIFAR-10 32x32 图像的 ResNet。
    与 ImageNet 版本相比，首层使用 3x3 卷积，不使用 7x7 卷积和初始最大池化。
    """

    def __init__(
        self,
        block: Type[Union[Bottleneck]],
        layers: List[int],
        num_classes: int = 10
    ):
        super().__init__()
        self.in_channels = 64

        self.conv1 = conv3x3(3, 64, stride=1)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU()

        self.layer1 = self._make_layer(block, 64, layers[0], stride=1)
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

        self.mean = ops.ReduceMean(keep_dims=False)
        self.flatten = nn.Flatten()
        self.fc = nn.Dense(512 * block.expansion, num_classes, weight_init=Normal(0.01))

    def _make_layer(
        self,
        block: Type[Union[Bottleneck]],
        channels: int,
        blocks: int,
        stride: int = 1
    ):
        down_sample = None
        out_channels = channels * block.expansion

        if stride != 1 or self.in_channels != out_channels:
            down_sample = nn.SequentialCell([
                conv1x1(self.in_channels, out_channels, stride=stride),
                nn.BatchNorm2d(out_channels)
            ])

        layers = [block(self.in_channels, channels, stride, down_sample)]
        self.in_channels = out_channels

        for _ in range(1, blocks):
            layers.append(block(self.in_channels, channels))

        return nn.SequentialCell(layers)

    def construct(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        # 全局平均池化：对 H、W 两个维度取平均
        x = self.mean(x, (2, 3))
        x = self.flatten(x)
        x = self.fc(x)
        return x


def resnet50(num_classes: int = 10):
    return ResNet(Bottleneck, [3, 4, 6, 3], num_classes=num_classes)


def evaluate_model(network, dataset, loss_fn, num_classes: int = 10):
    """在验证集/测试集上计算损失、准确率、各类别准确率和混淆矩阵。"""
    network.set_train(False)

    total_loss = 0.0
    total_num = 0
    correct_num = 0

    class_correct = np.zeros(num_classes, dtype=np.int64)
    class_total = np.zeros(num_classes, dtype=np.int64)
    conf_mat = np.zeros((num_classes, num_classes), dtype=np.int64)

    for batch in dataset.create_dict_iterator():
        images = batch["image"]
        labels = batch["label"]

        logits = network(images)
        loss = loss_fn(logits, labels)

        batch_size = labels.shape[0]
        total_loss += float(loss.asnumpy()) * batch_size
        total_num += batch_size

        preds = ops.Argmax(axis=1)(logits).asnumpy()
        labels_np = labels.asnumpy()

        correct_num += int((preds == labels_np).sum())

        for true_label, pred_label in zip(labels_np, preds):
            class_total[true_label] += 1
            if true_label == pred_label:
                class_correct[true_label] += 1
            conf_mat[true_label, pred_label] += 1

    avg_loss = total_loss / max(total_num, 1)
    accuracy = correct_num / max(total_num, 1)

    class_acc = {}
    for i, name in enumerate(CLASSES):
        if class_total[i] == 0:
            class_acc[name] = None
        else:
            class_acc[name] = float(class_correct[i] / class_total[i])

    return avg_loss, accuracy, class_acc, conf_mat


def plot_history(history, output_dir: str) -> None:
    """保存训练/测试损失和准确率曲线。"""
    output_path = Path(output_dir)
    epochs = [item["epoch"] for item in history]

    train_loss = [item["train_loss"] for item in history]
    test_loss = [item["test_loss"] for item in history]
    train_acc = [item["train_acc"] for item in history]
    test_acc = [item["test_acc"] for item in history]

    plt.figure()
    plt.plot(epochs, train_loss, label="Train Loss")
    plt.plot(epochs, test_loss, label="Test Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Loss Curve")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(output_path / "loss_curve.png", dpi=300)
    plt.close()

    plt.figure()
    plt.plot(epochs, train_acc, label="Train Accuracy")
    plt.plot(epochs, test_acc, label="Test Accuracy")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title("Accuracy Curve")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(output_path / "accuracy_curve.png", dpi=300)
    plt.close()


def plot_confusion_matrix(conf_mat: np.ndarray, output_dir: str) -> None:
    """保存混淆矩阵图片。"""
    output_path = Path(output_dir)

    plt.figure(figsize=(8, 7))
    plt.imshow(conf_mat, interpolation="nearest")
    plt.title("Confusion Matrix")
    plt.colorbar()

    tick_marks = np.arange(len(CLASSES))
    plt.xticks(tick_marks, CLASSES, rotation=45, ha="right")
    plt.yticks(tick_marks, CLASSES)

    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")

    thresh = conf_mat.max() / 2.0 if conf_mat.max() > 0 else 0
    for i in range(conf_mat.shape[0]):
        for j in range(conf_mat.shape[1]):
            plt.text(
                j, i, format(conf_mat[i, j], "d"),
                ha="center", va="center",
                color="white" if conf_mat[i, j] > thresh else "black"
            )

    plt.tight_layout()
    plt.savefig(output_path / "confusion_matrix.png", dpi=300)
    plt.close()


def _tensor_to_float(value) -> float:
    """将 MindSpore/Numpy 标量安全转为 Python float。"""
    if hasattr(value, "asnumpy"):
        value = value.asnumpy()
    arr = np.asarray(value).reshape(-1)
    return float(arr[0])


def save_history_csv(history, output_dir: str) -> None:
    """保存训练日志为 CSV。"""
    output_path = Path(output_dir) / "history.csv"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("epoch,train_loss,train_acc,test_loss,test_acc,epoch_seconds\n")
        for item in history:
            f.write(
                f"{item['epoch']},{item['train_loss']:.6f},"
                f"{item['train_acc']:.6f},{item['test_loss']:.6f},"
                f"{item['test_acc']:.6f},{item['epoch_seconds']:.2f}\n"
            )


def save_running_summary(
    history,
    output_dir: str,
    args,
    best_epoch: int,
    best_test_acc: float,
    total_seconds: float,
    class_acc=None,
) -> None:
    """每个 epoch 结束后增量保存 summary.json，避免训练中断后丢失记录。"""
    output_path = Path(output_dir) / "summary.json"
    latest = history[-1]
    summary = {
        "model": "ResNet50",
        "dataset": "CIFAR-10",
        "epochs": args.epochs,
        "completed_epochs": len(history),
        "batch_size": args.batch_size,
        "learning_rate": args.lr,
        "optimizer": "Momentum",
        "device_target": args.device_target,
        "mode": args.mode,
        "best_epoch": best_epoch,
        "best_test_acc": best_test_acc,
        "final_train_loss": latest["train_loss"],
        "final_train_acc": latest["train_acc"],
        "final_test_loss": latest["test_loss"],
        "final_test_acc": latest["test_acc"],
        "class_accuracy": class_acc,
        "total_seconds": total_seconds,
        "status": "running" if len(history) < args.epochs else "completed",
        "output_files": [
            "history.csv",
            "loss_curve.png",
            "accuracy_curve.png",
            "confusion_matrix.png",
            "summary.json",
            "best_resnet50_cifar10.ckpt",
            "train.log",
        ],
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


def train_one_epoch(network, dataset, loss_fn, optimizer):
    """单轮训练。"""
    network.set_train(True)

    total_loss = 0.0
    total_num = 0
    correct_num = 0

    def forward_fn(data, label):
        logits = network(data)
        return loss_fn(logits, label)

    grad_fn = ms.value_and_grad(forward_fn, None, optimizer.parameters)

    for batch in dataset.create_dict_iterator():
        images = batch["image"]
        labels = batch["label"]

        loss, grads = grad_fn(images, labels)
        optimizer(grads)

        logits = ops.stop_gradient(network(images))
        preds = ops.Argmax(axis=1)(logits).asnumpy()
        labels_np = labels.asnumpy()

        batch_size = labels.shape[0]
        loss_val = _tensor_to_float(loss)
        if np.isfinite(loss_val):
            total_loss += loss_val * batch_size
        total_num += batch_size
        correct_num += int((preds == labels_np).sum())

    return total_loss / max(total_num, 1), correct_num / max(total_num, 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data_root",
        type=str,
        default="/share/project/guotianyu/zhanghuanyao/syz_rl/data_mine/CIFAR10"
    )
    parser.add_argument("--output_dir", type=str, default="./exp6_outputs")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--mode", type=str, default="GRAPH", choices=["GRAPH", "PYNATIVE"])
    parser.add_argument("--device_target", type=str, default="CPU", choices=["CPU", "GPU", "Ascend"])
    args = parser.parse_args()

    set_seed(args.seed)

    if args.mode == "GRAPH":
        ms.set_context(mode=ms.GRAPH_MODE, device_target=args.device_target)
    else:
        ms.set_context(mode=ms.PYNATIVE_MODE, device_target=args.device_target)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    data_dir, dataset_format = resolve_cifar10_dataset(args.data_root)

    dataset_train = create_dataset_cifar10(
        data_dir, "train", image_size=32,
        batch_size=args.batch_size, workers=args.workers,
        dataset_format=dataset_format
    )
    dataset_test = create_dataset_cifar10(
        data_dir, "test", image_size=32,
        batch_size=args.batch_size, workers=args.workers,
        dataset_format=dataset_format
    )

    network = resnet50(num_classes=10)
    loss_fn = nn.SoftmaxCrossEntropyWithLogits(sparse=True, reduction="mean")
    optimizer = nn.Momentum(
        params=network.trainable_params(),
        learning_rate=args.lr,
        momentum=0.9,
        weight_decay=5e-4
    )

    history = []
    best_test_acc = 0.0
    best_epoch = 0
    total_start = time.time()

    print("[Info] 开始训练")
    print(
        f"[Config] epochs={args.epochs}, batch_size={args.batch_size}, "
        f"lr={args.lr}, device={args.device_target}, mode={args.mode}"
    )

    for epoch in range(1, args.epochs + 1):
        epoch_start = time.time()

        train_loss, train_acc = train_one_epoch(network, dataset_train, loss_fn, optimizer)
        test_loss, test_acc, class_acc, conf_mat = evaluate_model(network, dataset_test, loss_fn)

        epoch_seconds = time.time() - epoch_start

        history.append({
            "epoch": epoch,
            "train_loss": train_loss,
            "train_acc": train_acc,
            "test_loss": test_loss,
            "test_acc": test_acc,
            "epoch_seconds": epoch_seconds,
        })

        if test_acc > best_test_acc:
            best_test_acc = test_acc
            best_epoch = epoch
            ms.save_checkpoint(network, str(output_dir / "best_resnet50_cifar10.ckpt"))

        print(
            f"Epoch [{epoch:03d}/{args.epochs}] "
            f"train_loss={train_loss:.4f}, train_acc={train_acc*100:.2f}%, "
            f"test_loss={test_loss:.4f}, test_acc={test_acc*100:.2f}%, "
            f"time={epoch_seconds:.2f}s"
        )

        save_history_csv(history, args.output_dir)
        plot_history(history, args.output_dir)
        save_running_summary(
            history,
            args.output_dir,
            args,
            best_epoch,
            best_test_acc,
            time.time() - total_start,
            class_acc=class_acc,
        )

    total_seconds = time.time() - total_start

    # 最终评估并保存结果
    final_test_loss, final_test_acc, class_acc, conf_mat = evaluate_model(
        network, dataset_test, loss_fn
    )

    save_history_csv(history, args.output_dir)
    plot_history(history, args.output_dir)
    plot_confusion_matrix(conf_mat, args.output_dir)

    summary = {
        "model": "ResNet50",
        "dataset": "CIFAR-10",
        "epochs": args.epochs,
        "completed_epochs": len(history),
        "batch_size": args.batch_size,
        "learning_rate": args.lr,
        "optimizer": "Momentum",
        "device_target": args.device_target,
        "mode": args.mode,
        "best_epoch": best_epoch,
        "best_test_acc": best_test_acc,
        "final_train_loss": history[-1]["train_loss"],
        "final_train_acc": history[-1]["train_acc"],
        "final_test_loss": final_test_loss,
        "final_test_acc": final_test_acc,
        "class_accuracy": class_acc,
        "total_seconds": total_seconds,
        "status": "completed",
        "output_files": [
            "history.csv",
            "loss_curve.png",
            "accuracy_curve.png",
            "confusion_matrix.png",
            "summary.json",
            "best_resnet50_cifar10.ckpt",
            "train.log",
        ]
    }

    with open(output_dir / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("[Info] 训练结束，结果已保存到：", output_dir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
