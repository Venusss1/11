04组 实验3 数据集说明
项目：中国近海海洋多要素环境监测可视分析系统

【本目录 — 提交用主数据】
1. 04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json
   4200 条，29 字段；2023-01~2025-12；6 海域 × 3 深度层
2. 04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON
   6 个 Polygon Feature，含 region/count/risk_mean/center 等属性

【runtime/ — 静态演示运行依赖（指南未单独列项）】
前端双击 index.html 时需加载 lab3-runtime-bundle.js（内嵌聚合、风险、
相关性、时空特征、海岸线等派生数据）。同目录 *.json 为可读备份/脚本输入。

说明：因浏览器 file:// 协议无法 fetch 本地 JSON，故用 JS 全局变量注入；
通过 Flask 启动时可改走 /api/* 接口（见 docs/04-实验3-核心接口文档.docx）。

生成脚本：code/week12/geo_processing/create_geojson.py
