# -*- coding: utf-8 -*-
from flask import Flask, jsonify, request, send_from_directory
from pathlib import Path
from data_service import load_dataset, load_geojson, metadata, records
from modelarts_stub import predict_stub
from analytics_service import load_analytics, filter_anomaly, diagnosis_payload
from risk_service import algorithm_payload, aggregate_payload
from correlation_service import load_correlation, load_spacetime

PACKAGE = Path(__file__).resolve().parents[3]
FRONTEND = PACKAGE / "code" / "week13" / "final-system"
app = Flask(__name__, static_folder=str(FRONTEND), static_url_path="")

@app.get("/")
def index():
    return send_from_directory(FRONTEND, "index.html")

@app.get("/api/metadata")
def api_metadata():
    return jsonify(metadata())

@app.get("/api/records")
def api_records():
    rows = records(
        region=request.args.get("region"),
        month=request.args.get("month"),
        depth=request.args.get("depth"),
        risk=request.args.get("risk"),
    )
    limit = int(request.args.get("limit", 500))
    offset = int(request.args.get("offset", 0))
    return jsonify({"total": len(rows), "offset": offset, "limit": limit, "records": rows[offset:offset + limit]})

@app.get("/api/risk/models")
def api_risk_models():
    return jsonify(algorithm_payload())

@app.get("/api/risk/aggregate")
def api_risk_aggregate():
    return jsonify(aggregate_payload(
        algorithm=request.args.get("algorithm", "expert_rule"),
        region=request.args.get("region"),
        month=request.args.get("month"),
        depth=request.args.get("depth"),
        risk=request.args.get("risk"),
    ))

@app.get("/api/aggregate/risk")
def api_risk_legacy():
    return jsonify(load_dataset()["aggregates"]["riskCounts"])

@app.get("/api/aggregate/matrix")
def api_matrix_legacy():
    return jsonify(load_dataset()["aggregates"]["matrix"])

@app.get("/api/geojson")
def api_geojson():
    return jsonify(load_geojson())

@app.get("/api/timeseries")
def api_timeseries():
    return jsonify(load_dataset()["aggregates"]["timeseries"])

@app.get("/api/highdim")
def api_highdim():
    return jsonify(load_dataset()["aggregates"]["highdim"])

@app.get("/api/correlation/matrix")
def api_correlation_matrix():
    data = load_correlation()
    method = request.args.get("method", "pearson")
    return jsonify({"metrics": data["metrics"], "method": method, "matrix": data["matrices"].get(method, data["matrices"]["pearson"])})

@app.get("/api/correlation/timelag")
def api_correlation_timelag():
    return jsonify(load_correlation()["time_lag"])

@app.get("/api/correlation/spatial")
def api_correlation_spatial():
    return jsonify(load_correlation()["spatial_moran"])

@app.get("/api/spacetime/features")
def api_spacetime_features():
    return jsonify(load_spacetime())

@app.get("/api/analytics/anomaly")
def api_analytics_anomaly():
    rows = filter_anomaly(region=request.args.get("region"), month=request.args.get("month"), depth=request.args.get("depth"), level=request.args.get("level"))
    return jsonify({"total": len(rows), "records": rows})

@app.get("/api/analytics/seasonality")
def api_analytics_seasonality():
    return jsonify(load_analytics()["seasonality"])

@app.get("/api/analytics/clusters")
def api_analytics_clusters():
    data = load_analytics()
    return jsonify({"clusters": data["clusters"], "summary": data["cluster_summary"]})

@app.get("/api/analytics/contribution")
def api_analytics_contribution():
    data = load_analytics()
    region = request.args.get("region")
    if region and region in data.get("regional_contributions", {}):
        return jsonify({"scope": region, "records": data["regional_contributions"][region]})
    return jsonify({"scope": "global", "records": data["contributions"]})

@app.get("/api/analytics/diagnosis")
def api_analytics_diagnosis():
    return jsonify(diagnosis_payload(region=request.args.get("region"), month=request.args.get("month"), depth=request.args.get("depth")))

@app.post("/api/modelarts/predict")
def api_modelarts_predict():
    return jsonify(predict_stub(request.get_json(silent=True) or {}))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5053, debug=False)
