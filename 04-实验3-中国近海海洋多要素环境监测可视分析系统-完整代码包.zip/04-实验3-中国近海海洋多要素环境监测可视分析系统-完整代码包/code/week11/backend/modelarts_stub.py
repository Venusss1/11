# -*- coding: utf-8 -*-
def predict_stub(payload):
    """Reserved interface for Lab4 Huawei ModelArts model deployment."""
    score = float(payload.get("risk_score", 0.5)) if isinstance(payload, dict) else 0.5
    if score >= 0.68:
        level = "高风险"
    elif score >= 0.42:
        level = "中风险"
    else:
        level = "低风险"
    return {
        "model": "ModelArts-reserved-risk-classifier",
        "status": "stub",
        "risk_score": round(score, 4),
        "risk_level": level,
        "explain": "实验3预留输入输出协议；实验4可替换为真实云端模型。",
    }
