# -*- coding: utf-8 -*-
import json
from functools import lru_cache
from pathlib import Path
from aggregations import apply_filters

PACKAGE = Path(__file__).resolve().parents[3]
DATA_PATH = PACKAGE / "data" / "04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json"
GEO_PATH = PACKAGE / "data" / "04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON"

@lru_cache(maxsize=1)
def load_dataset():
    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    return data

@lru_cache(maxsize=1)
def load_geojson():
    return json.loads(GEO_PATH.read_text(encoding="utf-8"))

def records(**filters):
    data = load_dataset()
    return apply_filters(data["records"], **filters)

def metadata():
    data = load_dataset()
    return data["aggregates"]["metadata"]
