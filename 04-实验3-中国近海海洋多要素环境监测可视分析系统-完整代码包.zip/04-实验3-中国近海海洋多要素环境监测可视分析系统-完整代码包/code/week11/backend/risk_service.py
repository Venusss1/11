# -*- coding: utf-8 -*-
import json
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[3]
DATA = PACKAGE / "data"
ALL_REGION = {None, "", "全部海域"}
ALL_MONTH = {None, "", "全部月份"}
ALL_DEPTH = {None, "", "全部深度"}
ALL_RISK = {None, "", "全部风险"}
LEVELS = ["低风险", "中风险", "高风险"]
ZONE_TO_LEVEL = {"稳定区": "低风险", "波动区": "中风险", "高压区": "高风险"}

@lru_cache(maxsize=1)
def load_risk_models():
    return json.loads((DATA / "lab3-risk-models.json").read_text(encoding="utf-8"))

@lru_cache(maxsize=1)
def load_records():
    for path in sorted(DATA.glob("*.json"), key=lambda p: p.stat().st_size, reverse=True):
      try:
        data = json.loads(path.read_text(encoding="utf-8"))
      except Exception:
        continue
      if isinstance(data, dict) and len(data.get("records", [])) >= 4000:
        return data["records"]
    raise FileNotFoundError("Cannot locate Lab3 records JSON.")

@lru_cache(maxsize=1)
def _score_map():
    return {row["record_id"]: row for row in load_risk_models()["record_scores"]}

def level_of(record, algorithm):
    row = _score_map().get(record["record_id"], {})
    item = row.get(algorithm)
    if not item:
        return record.get("risk_level", "低风险")
    return item.get("level") or ZONE_TO_LEVEL.get(item.get("zone"), record.get("risk_level", "低风险"))

def score_of(record, algorithm):
    row = _score_map().get(record["record_id"], {})
    item = row.get(algorithm)
    if not item:
        return float(record.get("risk_score", 0))
    return float(item.get("score", 0))

def filter_records(algorithm="expert_rule", region=None, month=None, depth=None, risk=None):
    out = []
    for r in load_records():
        if region not in ALL_REGION and r.get("region_name") != region:
            continue
        if month not in ALL_MONTH and r.get("month_label") != month:
            continue
        if depth not in ALL_DEPTH and r.get("depth_group") != depth:
            continue
        if risk not in ALL_RISK and level_of(r, algorithm) != risk:
            continue
        out.append(r)
    return out

def risk_counts(rows, algorithm):
    c = Counter(level_of(r, algorithm) for r in rows)
    return {lv: c.get(lv, 0) for lv in LEVELS}

def region_risk(rows, algorithm):
    by_region = defaultdict(list)
    for r in rows:
        by_region[r["region_name"]].append(r)
    output = []
    for region in sorted(by_region):
        arr = by_region[region]
        c = risk_counts(arr, algorithm)
        level = max(LEVELS, key=lambda lv: c.get(lv, 0))
        output.append({
            "region": region,
            "count": len(arr),
            "low": c["低风险"],
            "mid": c["中风险"],
            "high": c["高风险"],
            "score_mean": round(sum(score_of(r, algorithm) for r in arr) / len(arr), 4) if arr else 0,
            "level": level,
        })
    return output

def timeseries(rows, algorithm):
    by_month = defaultdict(list)
    for r in rows:
        by_month[r["month_label"]].append(r)
    output = []
    for month in sorted(by_month):
        arr = by_month[month]
        c = risk_counts(arr, algorithm)
        output.append({
            "month": month,
            "count": len(arr),
            "low": c["低风险"],
            "mid": c["中风险"],
            "high": c["高风险"],
            "score_mean": round(sum(score_of(r, algorithm) for r in arr) / len(arr), 4) if arr else 0,
        })
    return output

def matrix(rows, algorithm):
    by_cell = defaultdict(list)
    for r in rows:
        by_cell[(r["region_name"], r["depth_group"], r["month_label"])].append(r)
    output = []
    for (region, depth, month), arr in sorted(by_cell.items()):
        c = risk_counts(arr, algorithm)
        level = max(LEVELS, key=lambda lv: c.get(lv, 0))
        output.append({
            "region": region,
            "depth": depth,
            "month": month,
            "count": len(arr),
            "low": c["低风险"],
            "mid": c["中风险"],
            "high": c["高风险"],
            "score_mean": round(sum(score_of(r, algorithm) for r in arr) / len(arr), 4) if arr else 0,
            "dominant_level": level,
        })
    return output

def algorithm_payload():
    data = load_risk_models()
    return {"algorithms": data["meta"]["algorithms"], "consensus": data["consensus"]}

def aggregate_payload(algorithm="expert_rule", region=None, month=None, depth=None, risk=None):
    rows = filter_records(algorithm=algorithm, region=region, month=month, depth=depth, risk=risk)
    all_month_rows = filter_records(algorithm=algorithm, region=region, month=None, depth=depth, risk=risk)
    return {
        "algorithm": algorithm,
        "scope": {"region": region or "全部海域", "month": month or "全部月份", "depth": depth or "全部深度", "risk": risk or "全部风险"},
        "riskCounts": risk_counts(rows, algorithm),
        "regionRisk": region_risk(rows, algorithm),
        "timeseries": timeseries(all_month_rows, algorithm),
        "matrix": matrix(all_month_rows, algorithm),
    }
