# -*- coding: utf-8 -*-
import json
from functools import lru_cache
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[3]
ANALYTICS_PATH = PACKAGE / "data" / "analytics-lab3.json"


@lru_cache(maxsize=1)
def load_analytics():
    return json.loads(ANALYTICS_PATH.read_text(encoding="utf-8"))


def filter_anomaly(region=None, month=None, depth=None, level=None):
    rows = load_analytics().get("anomaly", [])
    if region and region not in ("全部海域", "all"):
        rows = [r for r in rows if r["region"] == region]
    if month and month not in ("全部月份", "all"):
        rows = [r for r in rows if r["month"] == month]
    if depth and depth not in ("全部深度", "all"):
        rows = [r for r in rows if r["depth"] == depth]
    if level and level not in ("全部异常", "all"):
        rows = [r for r in rows if r["anomaly_level"] == level]
    return rows


def diagnosis_payload(region=None, month=None, depth=None):
    data = load_analytics()
    anomaly = filter_anomaly(region=region, month=month, depth=depth)
    top = sorted(anomaly, key=lambda d: (d["anomaly_level"] == "高异常", d["anomaly_score"]), reverse=True)[:3]
    payload = dict(data["diagnosis"]["global"])
    payload["query"] = {"region": region or "全部海域", "month": month or "全部月份", "depth": depth or "全部深度"}
    payload["top_anomalies"] = top
    return payload
