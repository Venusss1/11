# -*- coding: utf-8 -*-
from collections import Counter, defaultdict

RISK_ORDER = ["低风险", "中风险", "高风险"]

def apply_filters(records, region=None, month=None, depth=None, risk=None, metric=None):
    rows = []
    for r in records:
        if region and region != "全部海域" and r.get("region_name") != region:
            continue
        if month and month != "全部月份" and r.get("month_label") != month:
            continue
        if depth and depth != "全部深度" and r.get("depth_group") != depth:
            continue
        if risk and risk != "全部风险" and r.get("risk_level") != risk:
            continue
        rows.append(r)
    return rows

def risk_distribution(records):
    c = Counter(r.get("risk_level", "低风险") for r in records)
    return [{"risk_level": k, "count": c.get(k, 0)} for k in RISK_ORDER]

def matrix(records, regions, months, depths):
    out = []
    for region in regions:
        for month in months:
            for depth in depths:
                rows = [r for r in records if r.get("region_name") == region and r.get("month_label") == month and r.get("depth_group") == depth]
                if rows:
                    out.append({"region": region, "month": month, "depth": depth, "count": len(rows), "risk_mean": round(sum(float(r.get("risk_score", 0)) for r in rows) / len(rows), 4), "high_count": sum(1 for r in rows if r.get("risk_level") == "高风险")})
                else:
                    out.append({"region": region, "month": month, "depth": depth, "count": 0, "risk_mean": 0, "high_count": 0})
    return out

def timeseries(records, months):
    out = []
    for month in months:
        rows = [r for r in records if r.get("month_label") == month]
        mean = round(sum(float(r.get("risk_score", 0)) for r in rows) / len(rows), 4) if rows else 0
        out.append({"month": month, "count": len(rows), "risk_mean": mean, "high_count": sum(1 for r in rows if r.get("risk_level") == "高风险")})
    return out
