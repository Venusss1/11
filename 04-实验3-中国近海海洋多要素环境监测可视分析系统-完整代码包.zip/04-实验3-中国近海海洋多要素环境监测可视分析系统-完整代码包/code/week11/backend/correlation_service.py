# -*- coding: utf-8 -*-
import json
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[3]
DATA = PACKAGE / "data"

def load_correlation():
    return json.loads((DATA / "lab3-correlation-analytics.json").read_text(encoding="utf-8"))

def load_spacetime():
    return json.loads((DATA / "lab3-spacetime-features.json").read_text(encoding="utf-8"))
