
(() => {
  const meta = window.LAB3_AGGREGATES.metadata;
  const params = new URLSearchParams(location.search);
  if (params.get("stage")) Lab3State.state.stage = params.get("stage");
  if (params.get("tab")) Lab3State.state.tab = params.get("tab");
  if (params.get("region")) Lab3State.state.region = params.get("region");
  if (params.get("month")) Lab3State.state.month = params.get("month");
  if (params.get("depth")) Lab3State.state.depth = params.get("depth");

  function renderSummary(state){
    const rows = Lab3Utils.filtered(window.LAB3_DATA.records, state);
    const analytics = window.LAB3_ANALYTICS || {};
    const anomalyRows = (analytics.anomaly || []).filter(d =>
      (state.region === "全部海域" || d.region === state.region) &&
      (state.month === "全部月份" || d.month === state.month) &&
      (state.depth === "全部深度" || d.depth === state.depth)
    );
    const highAnomaly = anomalyRows.filter(d => d.anomaly_level === "高异常").length;
    const cards = [
      ["筛选记录", Lab3Utils.fmt(rows.length), "records"],
      ["覆盖海域", new Set(rows.map(d=>d.region_name)).size, "regions"],
      ["月份范围", state.month==="全部月份" ? `${meta.months[0]} 至 ${meta.months.at(-1)}` : state.month, "months"],
      ["高风险记录", rows.filter(d=>d.risk_level==="高风险").length, "high risk"],
      ["高异常单元", highAnomaly, "analytics"],
    ];
    d3.select("#summary-strip").selectAll(".metric-card").data(cards).join("div").attr("class","metric-card").html(d=>`<span>${d[0]}</span><b>${d[1]}</b><em>${d[2]}</em>`);
  }

  function renderQuality(){
    const q = [
      ["数据规模", `${meta.records} 条记录，${meta.fields} 个字段，原始 records 未被新增分析字段污染`],
      ["时空覆盖", `${meta.months.length} 个月，${meta.regions.length} 个海域，${meta.depths.length} 个深度层`],
      ["接口模式", "静态入口可双击打开；Flask 动态接口包含 records / GeoJSON / highdim / analytics"],
      ["视觉编码", "位置 > 长度 > 面积 > 亮度 > 色相；有序风险与异常使用语义亮度阶"]
    ];
    d3.select("#quality-cards").selectAll(".box").data(q).join("div").attr("class","box").html(d=>`<b>${d[0]}</b><span>${d[1]}</span>`);
  }

  function renderEvidence(){
    const e = [
      ["静态入口", "index.html / 打开实验3可视化系统.html 可直接双击打开"],
      ["动态接口", "/api/metadata, /api/records, /api/geojson, /api/highdim, /api/analytics/*, /api/modelarts/predict"],
      ["交互类别", "筛选、选择、高亮、详情查询、播放、Focus、全屏、重置、智能研判摘要"],
      ["新增研判", "异常检测、季节分解、空间聚类、贡献解释、诊断卡均由真实 records 派生"],
      ["提交证据", "screenshots_videos 包含 Matplotlib 图、浏览器截图、MP4 与生成记录"],
      ["老师建议", "类别比较用条形/矩阵；气泡面积编码；桑基流宽=记录数；风险等级不用彩虹色"]
    ];
    d3.select("#evidence-grid").selectAll(".box").data(e).join("div").attr("class","box").html(d=>`<b>${d[0]}</b><span>${d[1]}</span>`);
  }

  function renderAll(state){
    Lab3Filters.syncState(state);
    renderSummary(state);
    renderQuality();
    renderEvidence();
    ChartRiskBar.render(state);
    ChartTimeseries.render(state);
    ChartLab2.render(state);
    ChartGeoMap.render(state);
    ChartRiskMatrix.render(state);
    ChartParallel.render(state);
    if (window.ChartSmartAnalysis) ChartSmartAnalysis.render(state);
  }
  Lab3Filters.init();
  Lab3State.on(renderAll);
  renderAll(Lab3State.state);
})();
