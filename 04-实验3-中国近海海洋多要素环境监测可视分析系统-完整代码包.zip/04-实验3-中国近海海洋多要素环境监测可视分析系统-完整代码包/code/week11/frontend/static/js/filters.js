
window.Lab3Filters = (() => {
  const meta = window.LAB3_AGGREGATES.metadata;
  function fillSelect(id, values, allLabel, selected){
    const sel = d3.select(id); sel.selectAll("option").remove();
    [allLabel, ...values].forEach(v => sel.append("option").attr("value", v).text(v));
    sel.property("value", selected || allLabel);
  }
  function init(){
    const S = Lab3State.state;
    fillSelect("#metric-select", meta.metrics, "风险评分", S.metric);
    fillSelect("#region-select", meta.regions, "全部海域", S.region);
    fillSelect("#month-select", meta.months, "全部月份", S.month);
    fillSelect("#depth-select", meta.depths, "全部深度", S.depth);
    fillSelect("#risk-select", meta.riskLevels, "全部风险", S.riskLevel);
    d3.select("#month-slider").attr("max", meta.months.length - 1);
    if(S.month !== "全部月份" && meta.months.includes(S.month)){
      d3.select("#month-slider").property("value", meta.months.indexOf(S.month));
      d3.select("#slider-label").text(S.month);
    }
    d3.select("#metric-select").on("change", e => Lab3State.set({metric:e.target.value}));
    d3.select("#region-select").on("change", e => Lab3State.set({region:e.target.value, selectedRegion:e.target.value==="全部海域"?null:e.target.value}));
    d3.select("#month-select").on("change", e => Lab3State.set({month:e.target.value, selectedCell:null}));
    d3.select("#depth-select").on("change", e => Lab3State.set({depth:e.target.value, selectedCell:null}));
    d3.select("#risk-select").on("change", e => Lab3State.set({riskLevel:e.target.value}));
    d3.select("#month-slider").on("input", e => {
      const m = meta.months[+e.target.value]; d3.select("#slider-label").text(m); d3.select("#month-select").property("value", m); Lab3State.set({month:m, selectedCell:null});
    });
    d3.select("#btn-reset").on("click", () => {
      d3.select("#region-select").property("value","全部海域"); d3.select("#month-select").property("value","全部月份"); d3.select("#depth-select").property("value","全部深度"); d3.select("#risk-select").property("value","全部风险");
      d3.select("#slider-label").text("全部月份"); Lab3State.set({region:"全部海域",month:"全部月份",depth:"全部深度",riskLevel:"全部风险",selectedCell:null,selectedRegion:null});
    });
    d3.select("#btn-fullscreen").on("click", () => document.documentElement.requestFullscreen && document.documentElement.requestFullscreen());
    d3.select("#btn-focus").on("click", () => document.body.classList.toggle("focus-mode"));
    d3.select("#btn-play").on("click", () => togglePlay());
    d3.selectAll(".stage-btn").on("click", e => Lab3State.set({stage:e.currentTarget.dataset.stage}));
    d3.selectAll(".tab-btn").on("click", e => Lab3State.set({tab:e.currentTarget.dataset.tab}));
  }
  let timer = null;
  function togglePlay(){
    if(timer){ clearInterval(timer); timer=null; d3.select("#btn-play").text("播放"); return; }
    d3.select("#btn-play").text("暂停");
    timer = setInterval(() => {
      const months = meta.months; const current = Lab3State.state.month === "全部月份" ? -1 : months.indexOf(Lab3State.state.month);
      const idx = (current + 1) % months.length;
      d3.select("#month-slider").property("value", idx); d3.select("#month-select").property("value", months[idx]); d3.select("#slider-label").text(months[idx]);
      Lab3State.set({month: months[idx], selectedCell:null});
    }, 1200);
  }
  function syncState(s){
    d3.selectAll(".stage-btn").classed("active", function(){ return this.dataset.stage === s.stage; });
    d3.selectAll(".stage").classed("active", false); d3.select(`#stage-${s.stage}`).classed("active", true);
    d3.selectAll(".tab-btn").classed("active", function(){ return this.dataset.tab === s.tab; });
  }
  return {init, syncState};
})();
