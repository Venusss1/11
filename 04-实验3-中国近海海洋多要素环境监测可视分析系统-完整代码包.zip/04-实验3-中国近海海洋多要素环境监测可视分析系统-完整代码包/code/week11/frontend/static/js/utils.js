
window.Lab3Utils = (() => {
  const riskColor = {"低风险":"#1B9E77","中风险":"#D8A20F","高风险":"#D95F02"};
  const regionPalette = ["#2B83BA","#66C2A5","#ABDDA4","#FDAE61","#F46D43","#984EA3","#5E4FA2"];
  const fmt = d3.format(",");
  const get = (obj, key, fallback="") => obj && obj[key] !== undefined ? obj[key] : fallback;
  const filtered = (records, state) => records.filter(d =>
    (state.region === "全部海域" || d.region_name === state.region) &&
    (state.month === "全部月份" || d.month_label === state.month) &&
    (state.depth === "全部深度" || d.depth_group === state.depth) &&
    (state.riskLevel === "全部风险" || d.risk_level === state.riskLevel)
  );
  const mean = (arr, fn) => arr.length ? d3.mean(arr, fn) : 0;
  const sum = (arr, fn) => arr.length ? d3.sum(arr, fn) : 0;
  const clear = sel => d3.select(sel).selectAll("*").remove();
  const size = sel => { const node = d3.select(sel).node(); const r = node.getBoundingClientRect(); return {w: Math.max(320, r.width), h: Math.max(260, r.height)}; };
  const metricKey = label => (window.LAB3_DATA.metrics || {})[label] || "risk_score";
  const downloadHint = () => alert("截图建议：使用浏览器全屏后截图，或使用提交包 screenshots_videos 中的真实浏览器截图。");
  return {riskColor, regionPalette, fmt, get, filtered, mean, sum, clear, size, metricKey, downloadHint};
})();
