
window.Lab3State = (() => {
  const meta = window.LAB3_AGGREGATES.metadata;
  const state = {
    stage: "overview",
    metric: meta.metrics[0] || "风险评分",
    region: "全部海域",
    month: "全部月份",
    depth: "全部深度",
    riskLevel: "全部风险",
    selectedCell: null,
    selectedRegion: null,
    tab: "scatter",
    playing: false
  };
  const listeners = [];
  const set = patch => { Object.assign(state, patch); listeners.forEach(fn => fn(state)); };
  const on = fn => listeners.push(fn);
  return {state, set, on};
})();
