
window.ChartRiskMatrix = (() => {
  function render(state){ const svg=d3.select("#chart-risk-matrix"), {w,h}=Lab3Utils.size("#chart-risk-matrix"); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear("#chart-risk-matrix"); drawInto(svg,w,h,state,false); detail(state); }
  function drawInto(svg,w,h,state,compact){
    const meta=window.LAB3_AGGREGATES.metadata, depth=state.depth==="全部深度"?meta.depths[0]:state.depth, regions=meta.regions, months=meta.months;
    const data=window.LAB3_AGGREGATES.matrix.filter(d=>d.depth===depth);
    const m={t:compact?34:58,r:compact?24:34,b:compact?62:80,l:compact?86:110}, x=d3.scaleBand().domain(months).range([m.l,w-m.r]).padding(.06), y=d3.scaleBand().domain(regions).range([m.t,h-m.b]).padding(.08), color=d3.scaleSequential(d3.interpolateYlOrBr).domain([0,d3.max(data,d=>d.risk_mean)||1]);
    const focusMonth = state.month !== "全部月份" ? state.month : null;
    const focusRegion = state.region !== "全部海域" ? state.region : null;
    svg.append("text").attr("x",m.l).attr("y",compact?18:28).attr("fill","#5b7484").text(`深度层：${depth}；亮度=平均风险评分；${focusMonth?`播放/筛选月份：${focusMonth}`:"点击单元钻取"}`);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(months.filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-30)").style("text-anchor","end");
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    if(focusMonth && x(focusMonth) !== undefined){
      svg.append("rect").attr("class","matrix-month-band").attr("x",x(focusMonth)-3).attr("y",m.t-8).attr("width",x.bandwidth()+6).attr("height",h-m.b-m.t+16).attr("rx",7);
      svg.append("text").attr("x",x(focusMonth)+x.bandwidth()/2).attr("y",m.t-16).attr("text-anchor","middle").attr("font-size",12).attr("font-weight",800).attr("fill","#0077a8").text(focusMonth);
    }
    if(focusRegion && y(focusRegion) !== undefined){
      svg.append("rect").attr("class","matrix-region-band").attr("x",m.l-8).attr("y",y(focusRegion)-3).attr("width",w-m.r-m.l+16).attr("height",y.bandwidth()+6).attr("rx",7);
    }
    svg.selectAll("rect.cell").data(data).join("rect").attr("class",d=>`cell ${state.selectedCell&&state.selectedCell.region===d.region&&state.selectedCell.month===d.month&&state.selectedCell.depth===d.depth?"selected-cell":""}`).attr("x",d=>x(d.month)).attr("y",d=>y(d.region)).attr("width",x.bandwidth()).attr("height",y.bandwidth()).attr("rx",compact?2:4).attr("fill",d=>d.count?color(d.risk_mean):"#eef4f7").attr("stroke","#fff").attr("opacity",d=>focusMonth&&d.month!==focusMonth?0.42:1).on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.region} · ${d.month}</b><br/>深度：${d.depth}<br/>记录数：${d.count}<br/>平均风险：${d.risk_mean}<br/>高风险：${d.high_count}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide).on("click",(e,d)=>{d3.select("#region-select").property("value",d.region); d3.select("#month-select").property("value",d.month); d3.select("#depth-select").property("value",d.depth); d3.select("#slider-label").text(d.month); Lab3State.set({region:d.region,month:d.month,depth:d.depth,selectedCell:d,selectedRegion:d.region});});
    if(focusMonth && x(focusMonth) !== undefined){
      svg.append("rect").attr("class","matrix-month-outline").attr("x",x(focusMonth)-3).attr("y",m.t-8).attr("width",x.bandwidth()+6).attr("height",h-m.b-m.t+16).attr("rx",7);
    }
    if(!compact){ const defs=svg.append("defs"); const grad=defs.append("linearGradient").attr("id","risk-grad").attr("x1","0%").attr("x2","100%"); grad.append("stop").attr("offset","0%").attr("stop-color",color(0)); grad.append("stop").attr("offset","100%").attr("stop-color",color(1)); svg.append("rect").attr("x",w-220).attr("y",24).attr("width",150).attr("height",12).attr("rx",6).attr("fill","url(#risk-grad)"); svg.append("text").attr("x",w-220).attr("y",20).attr("font-size",12).attr("fill","#5b7484").text("风险亮度阶"); svg.append("text").attr("x",w-70).attr("y",45).attr("font-size",11).attr("fill","#5b7484").attr("text-anchor","end").text("高");}
  }
  function detail(state){
    const d=state.selectedCell;
    if(!d && state.month !== "全部月份"){
      const rows = Lab3Utils.filtered(window.LAB3_DATA.records, state);
      const high = rows.filter(r=>r.risk_level==="高风险").length;
      const avg = Lab3Utils.mean(rows,r=>+r.risk_score).toFixed(3);
      d3.select("#matrix-detail").html(`<h4>播放月份详情 · ${state.month}</h4><p>当前筛选记录：<b>${Lab3Utils.fmt(rows.length)}</b>；高风险记录：<b class="risk-high">${high}</b>；平均风险：<b>${avg}</b>。</p><p>矩阵中该月份整列已高亮；播放按钮会逐月移动高亮列，地图、趋势线和摘要卡同步更新。</p>`);
      return;
    }
    if(!d){ d3.select("#matrix-detail").html("<h4>矩阵钻取详情</h4><p>点击任一单元后，会显示海域、月份、深度、记录数、高风险数量和联动状态。当前为全量默认视角。</p>"); return; }
    d3.select("#matrix-detail").html(`<h4>${d.region} · ${d.month} · ${d.depth}</h4><p>记录数：<b>${d.count}</b>；平均风险：<b>${d.risk_mean}</b>；高风险记录：<b class="risk-high">${d.high_count}</b>。</p><p>已同步筛选区、空间地图、趋势线和平行坐标。该矩阵是本组创新图表，用“海域 × 月份 × 深度”组织近海风险场。</p>`);
  }
  return {render, drawInto};
})();
