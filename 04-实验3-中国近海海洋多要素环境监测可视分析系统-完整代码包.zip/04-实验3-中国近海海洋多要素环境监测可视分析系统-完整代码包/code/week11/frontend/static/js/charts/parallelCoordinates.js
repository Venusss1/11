
window.ChartParallel = (() => {
  function render(state){
    const svg=d3.select("#chart-parallel"), {w,h}=Lab3Utils.size("#chart-parallel"); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear("#chart-parallel");
    const dims=[...window.LAB3_AGGREGATES.metadata.metrics.slice(0,5),"risk_score"], data=window.LAB3_AGGREGATES.highdim;
    const m={t:44,r:52,b:64,l:68}, x=d3.scalePoint().domain(dims).range([m.l,w-m.r]), scales={}; dims.forEach(dim=>{scales[dim]=d3.scaleLinear().domain(d3.extent(data,d=>+d[dim]||0)).nice().range([h-m.b,m.t]);});
    function path(d){ return d3.line()(dims.map(dim=>[x(dim),scales[dim](+d[dim]||0)])); }
    data.forEach((d,i)=>{svg.append("path").attr("d",path(d)).attr("fill","none").attr("stroke",Lab3Utils.regionPalette[i%7]).attr("stroke-width",d.region===state.region?4:2).attr("opacity",(state.region==="全部海域"||d.region===state.region)?0.75:0.2).on("click",()=>{d3.select("#region-select").property("value",d.region); Lab3State.set({region:d.region,selectedRegion:d.region});}).on("mouseenter",(e)=>Lab3Tooltip.show(`<b>${d.region}</b><br/>平均风险：${(+d.risk_score).toFixed(3)}<br/>记录数：${d.count}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide);});
    dims.forEach(dim=>{svg.append("g").attr("class","axis").attr("transform",`translate(${x(dim)},0)`).call(d3.axisLeft(scales[dim]).ticks(4)); svg.append("text").attr("x",x(dim)).attr("y",h-22).attr("text-anchor","middle").attr("font-size",12).attr("font-weight",700).attr("fill","#17384a").text(dim);});
    const rows=Lab3Utils.filtered(window.LAB3_DATA.records,state); d3.select("#contribution-detail").html(`<h4>高维分析任务</h4><p><b>Analyze：</b>比较六海域多指标风险模式。<br/><b>Search：</b>通过筛选定位特定月份/深度/风险等级。<br/><b>Query：</b>点击海域后查询该海域平均风险与指标均值。</p><p>当前筛选记录：<b>${Lab3Utils.fmt(rows.length)}</b>，平均风险：<b>${Lab3Utils.mean(rows,d=>+d.risk_score).toFixed(3)}</b>。</p>`);
  }
  return {render};
})();
