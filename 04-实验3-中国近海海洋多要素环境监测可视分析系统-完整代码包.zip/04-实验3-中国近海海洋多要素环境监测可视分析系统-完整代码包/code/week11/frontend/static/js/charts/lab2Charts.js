
window.ChartLab2 = (() => {
  function render(state){
    const tab = state.tab || "scatter"; const svg=d3.select("#chart-lab2-main"), {w,h}=Lab3Utils.size("#chart-lab2-main"); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear("#chart-lab2-main");
    const records = Lab3Utils.filtered(window.LAB3_DATA.records,state); d3.select("#lab2-detail").html(`<h4>实验2成果层说明</h4><p>当前视图：<b>${tab}</b>；筛选后记录数：<b>${Lab3Utils.fmt(records.length)}</b>。这些图表保留实验2成果，并在实验3中接入统一状态、Tooltip、点击筛选与高亮。</p><p>其中气泡图使用<b>面积编码</b>，桑基图流宽表示<b>记录数</b>。</p>`);
    if(tab==="scatter") return scatter(svg,w,h,records,state);
    if(tab==="bubble") return bubble(svg,w,h,records);
    if(tab==="radar") return radar(svg,w,h,state);
    if(tab==="sankey") return sankey(svg,w,h,state);
    matrixMini(svg,w,h,state);
  }
  function scatter(svg,w,h,records,state){
    const m={t:26,r:32,b:46,l:56}, x=d3.scaleLinear().domain(d3.extent(records,d=>+d.longitude)).nice().range([m.l,w-m.r]), y=d3.scaleLinear().domain(d3.extent(records,d=>+d.latitude)).nice().range([h-m.b,m.t]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(6)); svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(6));
    svg.selectAll("circle").data(records.slice(0,900)).join("circle").attr("cx",d=>x(+d.longitude)).attr("cy",d=>y(+d.latitude)).attr("r",3.2).attr("fill",d=>Lab3Utils.riskColor[d.risk_level]).attr("opacity",.7).on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.region_name}</b><br/>${d.month_label} / ${d.depth_group}<br/>风险：${d.risk_level} ${(+d.risk_score).toFixed(3)}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide);
    svg.append("text").attr("x",w-m.r).attr("y",h-10).attr("text-anchor","end").attr("fill","#5b7484").text("经度 / °E"); svg.append("text").attr("x",m.l).attr("y",18).attr("fill","#5b7484").text("纬度 / °N");
  }
  function bubble(svg,w,h,records){
    const regions=window.LAB3_AGGREGATES.metadata.regions; const data=regions.map(r=>{const rows=records.filter(d=>d.region_name===r);return{region:r,count:rows.length,high:rows.filter(d=>d.risk_level==="高风险").length,risk:Lab3Utils.mean(rows,d=>+d.risk_score)}}).filter(d=>d.count>0);
    const m={t:30,r:30,b:72,l:60}, x=d3.scaleBand().domain(regions).range([m.l,w-m.r]).padding(.25), y=d3.scaleLinear().domain([0,d3.max(data,d=>d.risk)||1]).nice().range([h-m.b,m.t]), area=d3.scaleSqrt().domain([0,d3.max(data,d=>d.count)||1]).range([5,34]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x)).selectAll("text").attr("transform","rotate(-18)").style("text-anchor","end"); svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.selectAll("circle").data(data).join("circle").attr("cx",d=>x(d.region)+x.bandwidth()/2).attr("cy",d=>y(d.risk)).attr("r",d=>area(d.count)).attr("fill","#19b7cf").attr("stroke","#0077a8").attr("stroke-width",1.5).attr("opacity",.72).on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.region}</b><br/>面积编码记录数：${d.count}<br/>高风险：${d.high}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide);
    svg.append("text").attr("x",m.l).attr("y",18).attr("fill","#5b7484").text("Y=平均风险评分；圆面积=记录数");
  }
  function radar(svg,w,h,state){
    const metrics=window.LAB3_AGGREGATES.metadata.metrics.slice(0,5); const regions=window.LAB3_AGGREGATES.highdim.map(d=>d.region); const cx=w*.43, cy=h*.54, radius=Math.min(w*.34,h*.40);
    const angle=m=>metrics.indexOf(m)*Math.PI*2/metrics.length; const maxBy={}; metrics.forEach(m=>maxBy[m]=d3.max(window.LAB3_AGGREGATES.highdim,d=>+d[m])||1);
    [0.25,0.5,0.75,1].forEach(t=>{const pts=metrics.map(m=>[cx+Math.sin(angle(m))*radius*t,cy-Math.cos(angle(m))*radius*t]); svg.append("polygon").attr("points",pts.map(p=>p.join(",")).join(" ")).attr("fill","none").attr("stroke","#d8e8ee");});
    metrics.forEach(m=>{const a=angle(m), tx=cx+Math.sin(a)*(radius+38), ty=cy-Math.cos(a)*(radius+38); svg.append("line").attr("x1",cx).attr("y1",cy).attr("x2",cx+Math.sin(a)*radius).attr("y2",cy-Math.cos(a)*radius).attr("stroke","#d8e8ee"); svg.append("text").attr("x",tx).attr("y",ty).attr("text-anchor",Math.sin(a)>0.25?"start":Math.sin(a)<-0.25?"end":"middle").attr("dominant-baseline","middle").attr("font-size",13).attr("font-weight",700).attr("fill","#17384a").text(m);});
    window.LAB3_AGGREGATES.highdim.forEach((row,i)=>{const pts=metrics.map(m=>[cx+Math.sin(angle(m))*radius*(+row[m]/maxBy[m]),cy-Math.cos(angle(m))*radius*(+row[m]/maxBy[m])]); svg.append("polygon").attr("points",pts.map(p=>p.join(",")).join(" ")).attr("fill","none").attr("stroke",Lab3Utils.regionPalette[i%7]).attr("stroke-width",row.region===state.region?4:1.8).attr("opacity",(row.region===state.region||state.region==="全部海域")?0.9:0.25);});
    svg.selectAll("line.legend").data(regions).join("line").attr("class","legend").attr("x1",w-205).attr("x2",w-172).attr("y1",(d,i)=>52+i*28).attr("y2",(d,i)=>52+i*28).attr("stroke",(d,i)=>Lab3Utils.regionPalette[i%7]).attr("stroke-width",4).attr("stroke-linecap","round");
    svg.selectAll("text.legend").data(regions).join("text").attr("class","legend").attr("x",w-164).attr("y",(d,i)=>56+i*28).attr("fill","#17384a").attr("font-size",13).attr("font-weight",d=>d===state.region?800:500).text(d=>d);
  }
  function sankey(svg,w,h,state){
    const links=window.LAB3_AGGREGATES.sankey.links; const regions=window.LAB3_AGGREGATES.metadata.regions; const m={t:38,r:130,b:30,l:120}; const yR=d3.scalePoint().domain(regions).range([m.t,h-m.b]), yK=d3.scalePoint().domain(window.LAB3_AGGREGATES.metadata.riskLevels).range([h*.25,h*.75]); const width=d3.scaleLinear().domain([0,d3.max(links,d=>d.value)]).range([2,18]);
    regions.forEach((r,i)=>{svg.append("rect").attr("x",m.l-72).attr("y",yR(r)-11).attr("width",64).attr("height",22).attr("rx",6).attr("fill",Lab3Utils.regionPalette[i%7]); svg.append("text").attr("x",m.l-78).attr("y",yR(r)+4).attr("text-anchor","end").attr("font-size",12).text(r);});
    window.LAB3_AGGREGATES.metadata.riskLevels.forEach(k=>{svg.append("rect").attr("x",w-m.r).attr("y",yK(k)-13).attr("width",68).attr("height",26).attr("rx",7).attr("fill",Lab3Utils.riskColor[k]); svg.append("text").attr("x",w-m.r+76).attr("y",yK(k)+4).attr("font-size",12).text(k);});
    links.forEach(l=>{svg.append("path").attr("d",`M${m.l},${yR(l.source)} C${w*.45},${yR(l.source)} ${w*.58},${yK(l.target)} ${w-m.r},${yK(l.target)}`).attr("fill","none").attr("stroke",Lab3Utils.riskColor[l.target]).attr("stroke-width",width(l.value)).attr("opacity",.38).on("mouseenter",(e)=>Lab3Tooltip.show(`<b>${l.source} → ${l.target}</b><br/>流宽 = 记录数：${l.value}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide);});
    svg.append("text").attr("x",m.l).attr("y",20).attr("fill","#5b7484").text("桑基图流宽统一表示记录数");
  }
  function matrixMini(svg,w,h,state){ window.ChartRiskMatrix.drawInto(svg,w,h,state,true); }
  return {render};
})();
