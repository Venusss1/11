
window.ChartSmartAnalysis = (() => {
  const levelColor = {"正常":"#DCEEF4","低异常":"#9BD7E6","中异常":"#F2C75C","高异常":"#D95F02"};

  function scopedAnomaly(state){
    return (window.LAB3_ANALYTICS.anomaly || []).filter(d =>
      (state.region === "全部海域" || d.region === state.region) &&
      (state.depth === "全部深度" || d.depth === state.depth)
    );
  }

  function renderAnomaly(state){
    const selector = "#chart-anomaly-strip";
    const svg = d3.select(selector), {w,h}=Lab3Utils.size(selector);
    svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear(selector);
    const meta = window.LAB3_AGGREGATES.metadata;
    const data = scopedAnomaly(state);
    const region = state.region === "全部海域" ? meta.regions[0] : state.region;
    const depth = state.depth === "全部深度" ? meta.depths[0] : state.depth;
    const rows = data.filter(d => d.region === region && d.depth === depth);
    const m={t:48,r:30,b:70,l:86};
    const x=d3.scaleBand().domain(meta.months).range([m.l,w-m.r]).padding(.08);
    const y=d3.scaleBand().domain([depth]).range([m.t,h-m.b]).padding(.2);
    const maxScore=d3.max(rows,d=>d.anomaly_score)||1;
    const color=d3.scaleSequential(d3.interpolateYlOrBr).domain([0,maxScore]);
    svg.append("text").attr("x",m.l).attr("y",24).attr("fill","#5b7484").attr("font-weight",700).text(`${region} / ${depth}：异常亮度 = |残差 z-score|；播放月份列与矩阵同步`);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(meta.months.filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-30)").style("text-anchor","end");
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    if(state.month !== "全部月份" && x(state.month) !== undefined){
      svg.append("rect").attr("x",x(state.month)-4).attr("y",m.t-12).attr("width",x.bandwidth()+8).attr("height",h-m.t-m.b+24).attr("rx",8).attr("fill","#19b7cf").attr("opacity",.14).attr("stroke","#0077a8").attr("stroke-width",2).attr("stroke-dasharray","7 5");
    }
    svg.selectAll("rect.cell").data(rows).join("rect").attr("class","cell")
      .attr("x",d=>x(d.month)).attr("y",d=>y(depth)).attr("width",x.bandwidth()).attr("height",y.bandwidth()).attr("rx",8)
      .attr("fill",d=>color(d.anomaly_score)).attr("stroke",d=>d.month===state.month?"#08283a":"#fff").attr("stroke-width",d=>d.month===state.month?3:1.5)
      .on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.region} · ${d.month}</b><br/>异常等级：${d.anomaly_level}<br/>残差：${d.residual}<br/>原因：${d.anomaly_reason}`,e))
      .on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide)
      .on("click",(e,d)=>{d3.select("#month-select").property("value",d.month); Lab3State.set({month:d.month, region:d.region, depth:d.depth, selectedCell:{region:d.region,month:d.month,depth:d.depth}});});
    const high = rows.filter(d=>d.anomaly_level==="高异常");
    svg.selectAll("text.flag").data(high).join("text").attr("class","flag").attr("x",d=>x(d.month)+x.bandwidth()/2).attr("y",y(depth)+y.bandwidth()/2+5).attr("text-anchor","middle").attr("fill","#fff").attr("font-weight",800).text("!");
  }

  function renderSeasonality(state){
    const selector="#chart-seasonality", svg=d3.select(selector), {w,h}=Lab3Utils.size(selector);
    svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear(selector);
    const data=window.LAB3_ANALYTICS.seasonality || [], m={t:34,r:26,b:58,l:56};
    const x=d3.scalePoint().domain(data.map(d=>d.month)).range([m.l,w-m.r]);
    const ys=[...data.map(d=>d.risk_mean),...data.map(d=>d.trend)];
    const y=d3.scaleLinear().domain(d3.extent(ys)).nice().range([h-m.b,m.t]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(data.map(d=>d.month).filter((_,i)=>i%6===0))).selectAll("text").attr("transform","rotate(-30)").style("text-anchor","end");
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    const line=d3.line().x(d=>x(d.month)).y(d=>y(d.risk_mean)).curve(d3.curveMonotoneX);
    const trend=d3.line().x(d=>x(d.month)).y(d=>y(d.trend)).curve(d3.curveMonotoneX);
    svg.append("path").datum(data).attr("d",line).attr("fill","none").attr("stroke","#19b7cf").attr("stroke-width",2.6);
    svg.append("path").datum(data).attr("d",trend).attr("fill","none").attr("stroke","#D95F02").attr("stroke-width",3.2);
    if(state.month !== "全部月份"){
      const d=data.find(x=>x.month===state.month);
      if(d) svg.append("circle").attr("cx",x(d.month)).attr("cy",y(d.risk_mean)).attr("r",7).attr("fill","#fff").attr("stroke","#08283a").attr("stroke-width",3);
    }
    const legend=[["风险均值","#19b7cf"],["长期趋势","#D95F02"]];
    svg.selectAll("g.legend").data(legend).join("g").attr("transform",(d,i)=>`translate(${m.l+i*100},${m.t-16})`).each(function(d){const g=d3.select(this);g.append("line").attr("x1",0).attr("x2",26).attr("stroke",d[1]).attr("stroke-width",4);g.append("text").attr("x",32).attr("y",4).attr("fill","#17384a").attr("font-size",12).text(d[0]);});
  }

  function renderClusters(state){
    const selector="#chart-clusters", svg=d3.select(selector), {w,h}=Lab3Utils.size(selector);
    svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear(selector);
    const data=window.LAB3_ANALYTICS.clusters || [], m={t:42,r:32,b:56,l:62};
    const x=d3.scaleLinear().domain([0,1]).range([m.l,w-m.r]);
    const y=d3.scaleLinear().domain([0,1]).range([h-m.b,m.t]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(5));
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.append("text").attr("x",w/2).attr("y",h-14).attr("text-anchor","middle").attr("fill","#5b7484").text("归一化平均风险");
    svg.append("text").attr("x",18).attr("y",h/2).attr("transform",`rotate(-90,18,${h/2})`).attr("text-anchor","middle").attr("fill","#5b7484").text("归一化高风险占比");
    svg.selectAll("circle").data(data).join("circle").attr("cx",d=>x(d.x)).attr("cy",d=>y(d.y)).attr("r",d=>state.region===d.region?13:10).attr("fill",d=>d.cluster_color).attr("stroke",d=>state.region===d.region?"#08283a":"#fff").attr("stroke-width",d=>state.region===d.region?3:1.5).attr("opacity",.86)
      .on("click",(e,d)=>{d3.select("#region-select").property("value",d.region); Lab3State.set({region:d.region, selectedRegion:d.region});})
      .on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.region}</b><br/>聚类：${d.cluster}<br/>平均风险：${d.risk_mean}<br/>高风险占比：${(d.high_ratio*100).toFixed(1)}%`,e))
      .on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide);
    svg.selectAll("text.name").data(data).join("text").attr("class","name")
      .attr("x",d=>x(d.x) > w-m.r-90 ? x(d.x)-14 : x(d.x)+12)
      .attr("y",d=>y(d.y)-8)
      .attr("text-anchor",d=>x(d.x) > w-m.r-90 ? "end" : "start")
      .attr("font-size",12).attr("font-weight",700).attr("fill","#17384a").text(d=>d.region);
  }

  function renderContributions(state){
    const selector="#chart-contributions", svg=d3.select(selector), {w,h}=Lab3Utils.size(selector);
    svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear(selector);
    let data;
    if(state.region !== "全部海域" && window.LAB3_ANALYTICS.regional_contributions[state.region]){
      data = window.LAB3_ANALYTICS.regional_contributions[state.region].slice(0,7).map(d=>({metric:d.metric, value:d.score, text:d.direction}));
    } else {
      data = (window.LAB3_ANALYTICS.contributions || []).slice(0,7).map(d=>({metric:d.metric, value:d.abs_weight, text:`${d.direction} r=${d.correlation}`}));
    }
    const m={t:30,r:180,b:42,l:94}, x=d3.scaleLinear().domain([0,d3.max(data,d=>d.value)||1]).nice().range([m.l,w-m.r]), y=d3.scaleBand().domain(data.map(d=>d.metric)).range([m.t,h-m.b]).padding(.22);
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(5));
    svg.selectAll("rect").data(data).join("rect").attr("x",m.l).attr("y",d=>y(d.metric)).attr("width",d=>Math.max(1,x(d.value)-m.l)).attr("height",y.bandwidth()).attr("rx",8).attr("fill",(d,i)=>d3.interpolatePuBu(0.45+i*.06)).attr("stroke","#fff");
    svg.selectAll("text.value").data(data).join("text").attr("class","value").attr("x",d=>x(d.value)+8).attr("y",d=>y(d.metric)+y.bandwidth()/2+4).attr("font-size",12).attr("fill","#17384a").text(d=>`${d.value.toFixed(3)} · ${d.text}`);
    svg.append("text").attr("x",m.l).attr("y",18).attr("fill","#5b7484").attr("font-weight",700).text(state.region==="全部海域"?"全局相关贡献排序":"当前海域局部偏离贡献排序");
  }

  function renderDiagnosis(state){
    const rows=Lab3Utils.filtered(window.LAB3_DATA.records,state);
    const anomaly=scopedAnomaly(state).filter(d => state.month === "全部月份" || d.month === state.month);
    const top=anomaly.slice().sort((a,b)=>b.anomaly_score-a.anomaly_score)[0];
    const avg=Lab3Utils.mean(rows,d=>+d.risk_score).toFixed(3);
    const high=rows.filter(d=>d.risk_level==="高风险").length;
    const contrib = state.region !== "全部海域" && window.LAB3_ANALYTICS.regional_contributions[state.region]
      ? window.LAB3_ANALYTICS.regional_contributions[state.region][0]
      : window.LAB3_ANALYTICS.contributions[0];
    const cluster = (window.LAB3_ANALYTICS.clusters || []).find(d=>d.region===state.region);
    d3.select("#diagnosis-card").html(`
      <div class="diagnosis-kicker">一键研判 · ${state.region} / ${state.month} / ${state.depth}</div>
      <h4>${high>0?"存在需关注高风险记录":"当前筛选下高风险较少"}</h4>
      <p><b>风险水平：</b>筛选记录 ${Lab3Utils.fmt(rows.length)} 条，高风险 ${high} 条，平均风险 ${avg}。</p>
      <p><b>异常证据：</b>${top?`${top.region} ${top.month} ${top.depth} 为 ${top.anomaly_level}，残差 ${top.residual}。${top.anomaly_reason}`:"当前筛选未形成显著异常单元。"}</p>
      <p><b>空间解释：</b>${cluster?`${cluster.region} 属于 ${cluster.cluster}，高风险占比 ${(cluster.high_ratio*100).toFixed(1)}%。`:"请选择海域查看聚类分区。"}</p>
      <p><b>贡献指标：</b>${contrib?`${contrib.metric} 是当前最主要解释项（${contrib.direction || contrib.text || "相关贡献"}）。`:"贡献指标暂无。"}</p>
      <p><b>下一步：</b>点击异常热力条定位月份，再返回矩阵和 GeoJSON 地图核验空间位置。</p>
    `);
  }

  function render(state){
    renderAnomaly(state);
    renderSeasonality(state);
    renderClusters(state);
    renderContributions(state);
    renderDiagnosis(state);
  }
  return {render};
})();
