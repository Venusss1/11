
window.ChartRiskBar = (() => {
  function render(state){
    const svg = d3.select("#chart-risk-bar"), {w,h}=Lab3Utils.size("#chart-risk-bar"); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear("#chart-risk-bar");
    const records = Lab3Utils.filtered(window.LAB3_DATA.records, state);
    const data = window.LAB3_AGGREGATES.metadata.riskLevels.map(r => ({risk:r, count:records.filter(d=>d.risk_level===r).length}));
    const m={t:58,r:48,b:54,l:78}, x=d3.scaleBand().domain(data.map(d=>d.risk)).range([m.l,w-m.r]).padding(.38), y=d3.scaleLinear().domain([0,(d3.max(data,d=>d.count)||1)*1.12]).nice().range([h-m.b,m.t]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x));
    svg.append("g").attr("class","axis").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.selectAll("rect").data(data).join("rect").attr("x",d=>x(d.risk)).attr("y",d=>y(d.count)).attr("width",x.bandwidth()).attr("height",d=>h-m.b-y(d.count)).attr("rx",8).attr("fill",d=>Lab3Utils.riskColor[d.risk]).on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.risk}</b><br/>记录数：${Lab3Utils.fmt(d.count)}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide).on("click",(e,d)=>{d3.select("#risk-select").property("value",d.risk); Lab3State.set({riskLevel:d.risk});});
    svg.selectAll("text.value").data(data).join("text").attr("class","value").attr("x",d=>x(d.risk)+x.bandwidth()/2).attr("y",d=>Math.max(m.t-12,y(d.count)-12)).attr("text-anchor","middle").attr("font-weight",800).attr("font-size",16).attr("fill","#08283a").text(d=>Lab3Utils.fmt(d.count));
    svg.append("text").attr("x",m.l).attr("y",26).attr("fill","#5b7484").attr("font-size",13).text("长度编码记录数；风险等级使用有序语义色");
  }
  return {render};
})();
