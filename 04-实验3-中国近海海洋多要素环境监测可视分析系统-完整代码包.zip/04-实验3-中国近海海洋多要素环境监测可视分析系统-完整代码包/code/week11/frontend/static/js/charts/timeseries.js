
window.ChartTimeseries = (() => {
  function render(state){
    const svg=d3.select("#chart-timeseries"), {w,h}=Lab3Utils.size("#chart-timeseries"); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear("#chart-timeseries");
    const rec=Lab3Utils.filtered(window.LAB3_DATA.records,{...state,month:"全部月份"}), months=window.LAB3_AGGREGATES.metadata.months;
    const data=months.map(m=>{const rows=rec.filter(d=>d.month_label===m);return{month:m, risk:Lab3Utils.mean(rows,d=>+d.risk_score), high:rows.filter(d=>d.risk_level==="高风险").length}});
    const margin={t:26,r:38,b:58,l:58}, x=d3.scalePoint().domain(months).range([margin.l,w-margin.r]), y=d3.scaleLinear().domain([0,d3.max(data,d=>d.risk)||1]).nice().range([h-margin.b,margin.t]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${h-margin.b})`).call(d3.axisBottom(x).tickValues(months.filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("class","axis").attr("transform",`translate(${margin.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.append("path").datum(data).attr("fill","none").attr("stroke","#0077a8").attr("stroke-width",3).attr("d",d3.line().x(d=>x(d.month)).y(d=>y(d.risk)).curve(d3.curveMonotoneX));
    svg.selectAll("circle").data(data).join("circle").attr("cx",d=>x(d.month)).attr("cy",d=>y(d.risk)).attr("r",d=>state.month===d.month?6:3.5).attr("fill",d=>state.month===d.month?"#D95F02":"#19b7cf").on("mouseenter",(e,d)=>Lab3Tooltip.show(`<b>${d.month}</b><br/>平均风险：${d.risk.toFixed(3)}<br/>高风险：${d.high}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide).on("click",(e,d)=>{d3.select("#month-select").property("value",d.month); Lab3State.set({month:d.month});});
  }
  return {render};
})();
