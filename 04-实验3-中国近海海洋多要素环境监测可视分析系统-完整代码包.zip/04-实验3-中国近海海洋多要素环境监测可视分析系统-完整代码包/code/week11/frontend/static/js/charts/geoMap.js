
window.ChartGeoMap = (() => {
  function render(state){
    drawMap("#chart-geo-map", state, false); drawMap("#chart-geo-heat", state, true); detail(state);
  }
  function drawMap(selector,state,heat){
    const svg=d3.select(selector), {w,h}=Lab3Utils.size(selector); svg.attr("viewBox",`0 0 ${w} ${h}`); Lab3Utils.clear(selector);
    const features=window.LAB3_GEOJSON.features, records=Lab3Utils.filtered(window.LAB3_DATA.records,state);
    const lon=d3.scaleLinear().domain([108,128]).range([54,w-38]), lat=d3.scaleLinear().domain([18,42]).range([h-38,28]);
    for(let i=0;i<7;i++){ const y=lat(20+i*3); svg.append("path").attr("d",`M54 ${y} C${w*.35} ${y-50} ${w*.62} ${y+42} ${w-38} ${y-18}`).attr("fill","none").attr("stroke",i%2?"#d8b44c":"#83aab7").attr("stroke-dasharray",i%2?"5 7":"2 7").attr("opacity",.45); }
    features.forEach((f,i)=>{const pts=f.geometry.coordinates[0].map(p=>[lon(p[0]),lat(p[1])]); const risk=f.properties.risk_mean; svg.append("polygon").attr("points",pts.map(p=>p.join(",")).join(" ")).attr("fill",heat?d3.interpolatePuBu(Math.min(1,Math.max(0,risk))):Lab3Utils.regionPalette[i%7]).attr("stroke",f.properties.region===state.region?"#08283a":"#ffffff").attr("stroke-width",f.properties.region===state.region?3:1.5).attr("opacity",heat?.72:.36).on("click",()=>{d3.select("#region-select").property("value",f.properties.region); Lab3State.set({region:f.properties.region,selectedRegion:f.properties.region});}).on("mouseenter",(e)=>Lab3Tooltip.show(`<b>${f.properties.region}</b><br/>记录数：${f.properties.count}<br/>平均风险：${f.properties.risk_mean}<br/>高风险：${f.properties.high_count}`,e)).on("mousemove",Lab3Tooltip.move).on("mouseleave",Lab3Tooltip.hide); const c=f.properties.center; svg.append("text").attr("x",lon(c[0])).attr("y",lat(c[1])-10).attr("text-anchor","middle").attr("font-size",12).attr("font-weight",700).attr("fill","#17384a").text(f.properties.region);});
    const sample=records.filter((_,i)=>i%Math.max(1,Math.floor(records.length/500))===0).slice(0,700); svg.selectAll("circle.station").data(sample).join("circle").attr("class","station").attr("cx",d=>lon(+d.longitude)).attr("cy",d=>lat(+d.latitude)).attr("r",heat?3.2:2.5).attr("fill",d=>heat?Lab3Utils.riskColor[d.risk_level]:"#062c40").attr("opacity",heat?.62:.42);
    svg.append("text").attr("x",54).attr("y",18).attr("fill","#5b7484").text(heat?"地理热力：亮度/透明度辅助风险评分，位置编码经纬度":"GeoJSON 海域边界 + 观测站点 + 等深线隐喻");
  }
  function detail(state){ const rows=Lab3Utils.filtered(window.LAB3_DATA.records,state); const high=rows.filter(d=>d.risk_level==="高风险").length; d3.select("#region-detail").html(`<h4>${state.region==="全部海域"?"全海域":state.region}空间详情</h4><p>当前筛选记录：<b>${Lab3Utils.fmt(rows.length)}</b>；高风险记录：<b class="risk-high">${high}</b>；平均风险：<b>${Lab3Utils.mean(rows,d=>+d.risk_score).toFixed(3)}</b>。</p><p>交互：点击海域多边形写入全局 region；地图、矩阵、趋势线和平行坐标共享同一状态。</p>`); }
  return {render};
})();
