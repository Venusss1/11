
window.Lab3Tooltip = (() => {
  const tip = d3.select("#tooltip");
  function show(html, event){ tip.html(html).style("opacity",1); move(event); }
  function move(event){ const pad=16, rect=tip.node().getBoundingClientRect(); let x=event.clientX+pad, y=event.clientY+pad; if(x+rect.width>innerWidth) x=event.clientX-rect.width-pad; if(y+rect.height>innerHeight) y=event.clientY-rect.height-pad; tip.style("transform",`translate(${Math.max(8,x)}px,${Math.max(8,y)}px)`); }
  function hide(){ tip.style("opacity",0); }
  return {show, move, hide};
})();
