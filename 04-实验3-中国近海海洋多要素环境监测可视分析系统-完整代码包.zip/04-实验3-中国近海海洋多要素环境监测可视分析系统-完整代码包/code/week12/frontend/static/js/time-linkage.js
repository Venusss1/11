window.Week12TimeLinkage = (() => {
  function describe(state) {
    const meta = window.LAB3_AGGREGATES.metadata;
    const rows = Lab3Utils.filtered(window.LAB3_DATA.records, state);
    const monthRows = state.month === "全部月份" ? rows : rows.filter(d => d.month_label === state.month);
    const regionRows = state.region === "全部海域" ? monthRows : monthRows.filter(d => d.region_name === state.region);
    return {
      total: rows.length,
      monthCount: monthRows.length,
      regionMonthCount: regionRows.length,
      highRisk: regionRows.filter(d => d.risk_level === "高风险").length,
      meanRisk: Lab3Utils.mean(regionRows, d => +d.risk_score).toFixed(3),
      monthLabel: state.month === "全部月份" ? `${meta.months[0]} ~ ${meta.months.at(-1)}` : state.month,
      regionLabel: state.region === "全部海域" ? "全部海域" : state.region,
    };
  }

  function renderPanel(state) {
    const info = describe(state);
    d3.select("#linkage-panel").html(`
      <h4>时间-空间联动状态</h4>
      <p><b>当前海域：</b>${info.regionLabel}；<b>当前月份：</b>${info.monthLabel}</p>
      <p>筛选后记录 <b>${Lab3Utils.fmt(info.total)}</b>；当前月份子集 <b>${Lab3Utils.fmt(info.monthCount)}</b>；海域×月份 <b>${Lab3Utils.fmt(info.regionMonthCount)}</b></p>
      <p>高风险 <b class="risk-high">${info.highRisk}</b>；平均风险 <b>${info.meanRisk}</b></p>
      <p class="hint">播放时间轴时，矩阵高亮列、地图选中海域与详情卡同步刷新。</p>
    `);
  }

  function bindPlay(meta, onTick) {
    let timer = null;
    d3.select("#btn-play").on("click", () => {
      if (timer) {
        clearInterval(timer); timer = null;
        d3.select("#btn-play").text("播放");
        Lab3State.set({ playing: false });
        return;
      }
      d3.select("#btn-play").text("暂停");
      Lab3State.set({ playing: true });
      timer = setInterval(() => {
        const months = meta.months;
        const current = Lab3State.state.month === "全部月份" ? -1 : months.indexOf(Lab3State.state.month);
        const idx = (current + 1) % months.length;
        const month = months[idx];
        d3.select("#month-slider").property("value", idx);
        d3.select("#month-select").property("value", month);
        d3.select("#slider-label").text(month);
        Lab3State.set({ month, selectedCell: null });
        if (onTick) onTick(Lab3State.state);
      }, 1200);
    });
  }

  return { describe, renderPanel, bindPlay };
})();
