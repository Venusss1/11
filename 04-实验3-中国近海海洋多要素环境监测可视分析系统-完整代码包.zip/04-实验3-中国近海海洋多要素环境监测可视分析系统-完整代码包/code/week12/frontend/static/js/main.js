(() => {
  function renderAll(state) {
    Week12GeoMap.render(state);
    Week12Matrix.render(state);
    Week12TimeLinkage.renderPanel(state);
  }
  Week12Filters.init(renderAll);
  Lab3State.on(renderAll);
  renderAll(Lab3State.state);
})();
