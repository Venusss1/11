window.Lab3State = (() => {
  const meta = window.LAB3_AGGREGATES.metadata;
  const state = {
    region: "全部海域",
    month: "全部月份",
    depth: meta.depths[0] || "0-10m",
    riskLevel: "全部风险",
    selectedRegion: null,
    selectedCell: null,
    playing: false,
  };
  const listeners = [];
  const set = patch => { Object.assign(state, patch); listeners.forEach(fn => fn(state)); };
  const on = fn => listeners.push(fn);
  return { state, set, on };
})();
