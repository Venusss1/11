window.Week12GeoMap = (() => {
  const zoomState = { map: d3.zoomIdentity, heat: d3.zoomIdentity };

  function render(state) {
    drawMap("#chart-geo-map", state, false, "map");
    drawMap("#chart-geo-heat", state, true, "heat");
    detail(state);
  }

  function drawMap(selector, state, heat, key) {
    const svg = d3.select(selector);
    const { w, h } = Lab3Utils.size(selector);
    svg.attr("viewBox", `0 0 ${w} ${h}`);
    Lab3Utils.clear(selector);

    const features = window.LAB3_GEOJSON.features;
    const records = Lab3Utils.filtered(window.LAB3_DATA.records, state);
    const lon = d3.scaleLinear().domain([108, 128]).range([54, w - 38]);
    const lat = d3.scaleLinear().domain([18, 42]).range([h - 38, 28]);
    const root = svg.append("g").attr("class", "zoom-root");
    const zoom = d3.zoom().scaleExtent([0.8, 4]).on("zoom", event => {
      zoomState[key] = event.transform;
      root.attr("transform", event.transform);
    });
    svg.call(zoom);
    root.attr("transform", zoomState[key] || d3.zoomIdentity);

    for (let i = 0; i < 5; i++) {
      const y = lat(20 + i * 3);
      root.append("path")
        .attr("d", `M54 ${y} C${w * 0.35} ${y - 40} ${w * 0.62} ${y + 36} ${w - 38} ${y - 16}`)
        .attr("fill", "none").attr("stroke", "#83aab7").attr("stroke-dasharray", "4 6").attr("opacity", 0.45);
    }

    features.forEach((f, i) => {
      const pts = f.geometry.coordinates[0].map(p => [lon(p[0]), lat(p[1])]);
      const risk = f.properties.risk_mean;
      const selected = f.properties.region === state.region;
      root.append("polygon")
        .attr("points", pts.map(p => p.join(",")).join(" "))
        .attr("fill", heat ? d3.interpolatePuBu(Math.min(1, Math.max(0, risk))) : Lab3Utils.regionPalette[i % 7])
        .attr("stroke", selected ? "#08283a" : "#ffffff")
        .attr("stroke-width", selected ? 3 : 1.5)
        .attr("opacity", heat ? 0.78 : 0.42)
        .style("cursor", "pointer")
        .on("click", () => {
          d3.select("#region-select").property("value", f.properties.region);
          Lab3State.set({ region: f.properties.region, selectedRegion: f.properties.region });
        })
        .on("mouseenter", e => Lab3Tooltip.show(
          `<b>${f.properties.region}</b><br/>记录 ${f.properties.count}<br/>平均风险 ${f.properties.risk_mean}<br/>高风险 ${f.properties.high_count}`, e))
        .on("mousemove", Lab3Tooltip.move)
        .on("mouseleave", Lab3Tooltip.hide);
      const c = f.properties.center;
      root.append("circle").attr("cx", lon(c[0])).attr("cy", lat(c[1])).attr("r", 5)
        .attr("fill", "#fff").attr("stroke", "#08283a").attr("stroke-width", 1.5);
      root.append("text").attr("x", lon(c[0])).attr("y", lat(c[1]) - 10)
        .attr("text-anchor", "middle").attr("font-size", 12).attr("font-weight", 700).attr("fill", "#17384a")
        .text(f.properties.region);
    });

    const sample = records.filter((_, idx) => idx % Math.max(1, Math.floor(records.length / 400)) === 0).slice(0, 400);
    root.selectAll("circle.station").data(sample).join("circle")
      .attr("class", "station")
      .attr("cx", d => lon(+d.longitude)).attr("cy", d => lat(+d.latitude))
      .attr("r", heat ? 3 : 2.4)
      .attr("fill", d => Lab3Utils.riskColor[d.risk_level] || "#062c40")
      .attr("opacity", 0.55);

    svg.append("text").attr("x", 54).attr("y", 18).attr("fill", "#5b7484")
      .text(heat ? "热力图：亮度编码风险，支持滚轮缩放/拖拽平移" : "交互地图：点击筛选海域，滚轮缩放，拖拽平移");
    svg.append("text").attr("x", w - 180).attr("y", 18).attr("fill", "#0077a8")
      .text(state.month === "全部月份" ? "全部月份" : `月份 ${state.month}`);
  }

  function detail(state) {
    const rows = Lab3Utils.filtered(window.LAB3_DATA.records, state);
    const high = rows.filter(d => d.risk_level === "高风险").length;
    d3.select("#region-detail").html(`
      <h4>${state.region === "全部海域" ? "全海域" : state.region} · 空间详情</h4>
      <p>记录 <b>${Lab3Utils.fmt(rows.length)}</b>；高风险 <b class="risk-high">${high}</b>；平均风险 <b>${Lab3Utils.mean(rows, d => +d.risk_score).toFixed(3)}</b></p>
      <p>地图点击 → 写入 region；月份滑条/播放 → 同步矩阵列高亮与站点抽样。</p>
    `);
  }

  function resetView() {
    zoomState.map = d3.zoomIdentity;
    zoomState.heat = d3.zoomIdentity;
  }

  return { render, resetView };
})();
