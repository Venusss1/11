window.Week12Matrix = (() => {
  function render(state) {
    const svg = d3.select("#chart-matrix");
    const { w, h } = Lab3Utils.size("#chart-matrix");
    svg.attr("viewBox", `0 0 ${w} ${h}`);
    Lab3Utils.clear("#chart-matrix");

    const meta = window.LAB3_AGGREGATES.metadata;
    const depth = state.depth;
    const data = window.LAB3_AGGREGATES.matrix.filter(d => d.depth === depth);
    const regions = meta.regions;
    const months = meta.months;
    const m = { t: 48, r: 24, b: 72, l: 96 };
    const x = d3.scaleBand().domain(months).range([m.l, w - m.r]).padding(0.06);
    const y = d3.scaleBand().domain(regions).range([m.t, h - m.b]).padding(0.08);
    const color = d3.scaleSequential(d3.interpolateYlOrBr).domain([0, d3.max(data, d => d.risk_mean) || 1]);

    svg.append("text").attr("x", m.l).attr("y", 24).attr("fill", "#5b7484")
      .text(`深度层 ${depth}；亮度=平均风险；列高亮=当前月份`);

    svg.append("g").attr("transform", `translate(0,${h - m.b})`)
      .call(d3.axisBottom(x).tickValues(months.filter((_, i) => i % 3 === 0)))
      .selectAll("text").attr("transform", "rotate(-30)").style("text-anchor", "end");
    svg.append("g").attr("transform", `translate(${m.l},0)`).call(d3.axisLeft(y));

    if (state.month !== "全部月份" && x(state.month) !== undefined) {
      svg.append("rect").attr("class", "month-band")
        .attr("x", x(state.month) - 3).attr("y", m.t - 8)
        .attr("width", x.bandwidth() + 6).attr("height", h - m.b - m.t + 16)
        .attr("rx", 6).attr("fill", "rgba(25,183,207,0.12)").attr("stroke", "#19b7cf");
    }

    svg.selectAll("rect.cell").data(data).join("rect")
      .attr("x", d => x(d.month)).attr("y", d => y(d.region))
      .attr("width", x.bandwidth()).attr("height", y.bandwidth())
      .attr("fill", d => color(d.risk_mean))
      .attr("stroke", d => state.region === d.region && state.month === d.month ? "#08283a" : "#fff")
      .attr("stroke-width", d => state.region === d.region && state.month === d.month ? 2.5 : 0.6)
      .on("click", (_, d) => {
        d3.select("#region-select").property("value", d.region);
        d3.select("#month-select").property("value", d.month);
        d3.select("#depth-select").property("value", d.depth);
        Lab3State.set({ region: d.region, month: d.month, depth: d.depth, selectedCell: d, selectedRegion: d.region });
      })
      .on("mouseenter", (e, d) => Lab3Tooltip.show(`<b>${d.region}</b> · ${d.month}<br/>风险均值 ${d.risk_mean}<br/>记录 ${d.count}`, e))
      .on("mousemove", Lab3Tooltip.move)
      .on("mouseleave", Lab3Tooltip.hide);
  }
  return { render };
})();
