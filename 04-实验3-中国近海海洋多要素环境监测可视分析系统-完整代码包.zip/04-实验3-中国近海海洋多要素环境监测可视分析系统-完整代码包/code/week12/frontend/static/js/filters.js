window.Week12Filters = (() => {
  const meta = window.LAB3_AGGREGATES.metadata;

  function fillSelect(id, values, allLabel, selected) {
    const sel = d3.select(id);
    sel.selectAll("option").remove();
    [allLabel, ...values].forEach(v => sel.append("option").attr("value", v).text(v));
    sel.property("value", selected || allLabel);
  }

  function init(onChange) {
    const S = Lab3State.state;
    fillSelect("#region-select", meta.regions, "全部海域", S.region);
    fillSelect("#month-select", meta.months, "全部月份", S.month);
    fillSelect("#depth-select", meta.depths, "全部深度", S.depth);
    fillSelect("#risk-select", meta.riskLevels, "全部风险", S.riskLevel);
    d3.select("#month-slider").attr("max", meta.months.length - 1);

    d3.select("#region-select").on("change", e => Lab3State.set({ region: e.target.value, selectedRegion: e.target.value === "全部海域" ? null : e.target.value }));
    d3.select("#month-select").on("change", e => Lab3State.set({ month: e.target.value, selectedCell: null }));
    d3.select("#depth-select").on("change", e => Lab3State.set({ depth: e.target.value, selectedCell: null }));
    d3.select("#risk-select").on("change", e => Lab3State.set({ riskLevel: e.target.value }));
    d3.select("#month-slider").on("input", e => {
      const m = meta.months[+e.target.value];
      d3.select("#slider-label").text(m);
      d3.select("#month-select").property("value", m);
      Lab3State.set({ month: m, selectedCell: null });
    });
    d3.select("#btn-reset").on("click", () => {
      d3.select("#region-select").property("value", "全部海域");
      d3.select("#month-select").property("value", "全部月份");
      d3.select("#depth-select").property("value", meta.depths[0]);
      d3.select("#risk-select").property("value", "全部风险");
      d3.select("#slider-label").text("全部月份");
      Week12GeoMap.resetView();
      Lab3State.set({ region: "全部海域", month: "全部月份", depth: meta.depths[0], riskLevel: "全部风险", selectedCell: null, selectedRegion: null });
    });
    Week12TimeLinkage.bindPlay(meta, onChange);
  }

  return { init };
})();
