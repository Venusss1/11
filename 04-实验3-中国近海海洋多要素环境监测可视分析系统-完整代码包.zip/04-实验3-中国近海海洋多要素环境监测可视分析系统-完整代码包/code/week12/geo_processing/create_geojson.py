# -*- coding: utf-8 -*-
"""Week12: 从实验2 records 聚合生成实验3 GeoJSON FeatureCollection。

用法:
    python create_geojson.py
    python create_geojson.py --dataset ../../data/04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json \
                             --output ../../data/04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

PACKAGE = Path(__file__).resolve().parents[3]
DATA_DIR = PACKAGE / "data"
DEFAULT_DATASET = DATA_DIR / "04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json"
DEFAULT_OUTPUT = DATA_DIR / "04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON"

def discover_dataset(data_dir: Path) -> Path:
    """Locate the lab2 records JSON even when filenames are locale-mojibake."""
    preferred = data_dir / "04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json"
    if preferred.exists():
        return preferred
    candidates = []
    for path in data_dir.glob("*.json"):
        if path.stat().st_size < 1_000_000:
            continue
        head = path.read_text(encoding="utf-8", errors="ignore")[:4096]
        if '"records"' in head and '"region_name"' in head:
            candidates.append(path)
    if not candidates:
        raise FileNotFoundError("未找到实验2数据集 JSON")
    return max(candidates, key=lambda p: p.stat().st_size)


def discover_geojson(data_dir: Path) -> Path:
    preferred = data_dir / "04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON"
    if preferred.exists():
        return preferred
    for pattern in ("*.GeoJSON", "*.geojson"):
        matches = sorted(data_dir.glob(pattern))
        if matches:
            return matches[0]
    raise FileNotFoundError("未找到实验3 GeoJSON")


def bbox_polygon(lons, lats, pad=0.8):
    min_lon, max_lon = min(lons) - pad, max(lons) + pad
    min_lat, max_lat = min(lats) - pad, max(lats) + pad
    return [
        [min_lon, min_lat], [max_lon, min_lat], [max_lon, max_lat],
        [min_lon, max_lat], [min_lon, min_lat],
    ]


def build_feature_collection(records):
    grouped = defaultdict(list)
    for row in records:
        grouped[row.get("region_name") or row.get("region")].append(row)

    features = []
    for region in sorted(grouped.keys()):
        rows = grouped[region]
        lons = [float(r["longitude"]) for r in rows]
        lats = [float(r["latitude"]) for r in rows]
        risks = [float(r.get("risk_score", 0)) for r in rows]
        levels = Counter(r.get("risk_level", "低风险") for r in rows)
        features.append({
            "type": "Feature",
            "properties": {
                "region": region,
                "count": len(rows),
                "risk_mean": round(mean(risks), 4) if risks else 0,
                "high_count": levels.get("高风险", 0),
                "mid_count": levels.get("中风险", 0),
                "low_count": levels.get("低风险", 0),
                "center": [round(mean(lons), 3), round(mean(lats), 3)],
            },
            "geometry": {"type": "Polygon", "coordinates": [bbox_polygon(lons, lats)]},
        })
    return {"type": "FeatureCollection", "features": features}


def validate(collection):
    assert collection["type"] == "FeatureCollection"
    assert collection["features"]
    for feat in collection["features"]:
        assert feat["properties"]["region"]
        assert feat["properties"]["count"] > 0
        assert feat["geometry"]["type"] == "Polygon"


def main():
    parser = argparse.ArgumentParser(description="Week12 GeoJSON 转换脚本")
    parser.add_argument("--dataset", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()

    dataset_path = args.dataset if args.dataset and args.dataset.exists() else discover_dataset(DATA_DIR)
    records = json.loads(dataset_path.read_text(encoding="utf-8"))["records"]
    collection = build_feature_collection(records)
    validate(collection)

    output_path = args.output
    if output_path == DEFAULT_OUTPUT and not DEFAULT_OUTPUT.exists():
        output_path = discover_geojson(DATA_DIR)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(collection, ensure_ascii=False, indent=2 if args.pretty else None)
    output_path.write_text(text + "\n", encoding="utf-8")

    print(f"[week12] dataset: {dataset_path.name}")
    print(f"[week12] records: {len(records)}")
    print(f"[week12] features: {len(collection['features'])}")
    print(f"[week12] wrote: {output_path}")


if __name__ == "__main__":
    main()
