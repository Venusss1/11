# -*- coding: utf-8 -*-
"""Week12: GeoJSON 与 records 的空间统计校验工具。"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

PACKAGE = Path(__file__).resolve().parents[3]
DATA_DIR = PACKAGE / "data"

def discover_dataset(data_dir: Path) -> Path:
    """Locate the lab2 records JSON even when filenames are locale-mojibake."""
    preferred = data_dir / "04-中国近海海洋多要素环境监测可视分析系统-实验2数据集.json"
    if preferred.exists():
        return preferred
    candidates = []
    for path in data_dir.glob("*.json"):
        if path.stat().st_size < 1_000_000:
            continue
        head = path.read_text(encoding="utf-8", errors="ignore")[:4096]
        if '"records"' in head and '"region_name"' in head:
            candidates.append(path)
    if not candidates:
        raise FileNotFoundError("未找到实验2数据集 JSON")
    return max(candidates, key=lambda p: p.stat().st_size)


def discover_geojson(data_dir: Path) -> Path:
    preferred = data_dir / "04-中国近海海洋多要素环境监测可视分析系统-实验3-地理数据.GeoJSON"
    if preferred.exists():
        return preferred
    for pattern in ("*.GeoJSON", "*.geojson"):
        matches = sorted(data_dir.glob(pattern))
        if matches:
            return matches[0]
    raise FileNotFoundError("未找到实验3 GeoJSON")


def summarize_feature(feature):
    p = feature.get("properties", {})
    return {
        "region": p.get("region"),
        "records": p.get("count", 0),
        "mean_risk": p.get("risk_mean", 0),
        "high_risk": p.get("high_count", 0),
        "mid_risk": p.get("mid_count", 0),
        "low_risk": p.get("low_count", 0),
        "center": p.get("center"),
    }


def summarize_collection(collection):
    return [summarize_feature(f) for f in collection.get("features", [])]


def compare_with_records(collection, records):
    grouped = defaultdict(list)
    for row in records:
        grouped[row.get("region_name")].append(row)

    mismatches = []
    for feat in collection.get("features", []):
        region = feat["properties"]["region"]
        rows = grouped.get(region, [])
        props = feat["properties"]
        expected_mean = round(mean(float(r.get("risk_score", 0)) for r in rows), 4) if rows else 0
        if props["count"] != len(rows):
            mismatches.append({"region": region, "field": "count", "geojson": props["count"], "records": len(rows)})
        if abs(props["risk_mean"] - expected_mean) > 1e-3:
            mismatches.append({"region": region, "field": "risk_mean", "geojson": props["risk_mean"], "records": expected_mean})
        levels = Counter(r.get("risk_level") for r in rows)
        for label, field in [("高风险", "high_count"), ("中风险", "mid_count"), ("低风险", "low_count")]:
            if props.get(field, 0) != levels.get(label, 0):
                mismatches.append({"region": region, "field": field, "geojson": props.get(field), "records": levels.get(label, 0)})
    return mismatches


def main():
    dataset_path = discover_dataset(DATA_DIR)
    geo_path = discover_geojson(DATA_DIR)
    records = json.loads(dataset_path.read_text(encoding="utf-8"))["records"]
    collection = json.loads(geo_path.read_text(encoding="utf-8"))
    mismatches = compare_with_records(collection, records)

    print(f"[week12] dataset: {dataset_path.name}")
    print(f"[week12] spatial stats for {geo_path.name}")
    for row in summarize_collection(collection):
        print(f"  - {row['region']}: count={row['records']}, risk_mean={row['mean_risk']}, high={row['high_risk']}")
    if mismatches:
        print(f"[week12] mismatches: {len(mismatches)}")
        for m in mismatches[:10]:
            print("   ", m)
        raise SystemExit(1)
    print("[week12] PASS: GeoJSON 属性与 records 聚合一致")


if __name__ == "__main__":
    main()
