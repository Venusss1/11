(() => {
  const records = window.LAB3_DATA.records || [];
  const baseMeta = window.LAB3_AGGREGATES.metadata || {};
  const riskModels = window.LAB3_RISK_MODELS;
  const corrData = window.LAB3_CORRELATION;
  const spacetime = window.LAB3_SPACETIME;
  const analytics = window.LAB3_ANALYTICS || {};
  const geoJson = window.LAB3_GEOJSON || {features: []};
  const coast = window.LAB3_CHINA_COAST || {bbox:[106,18,126,42], land:[], coastlines:[]};
  const metrics = Object.keys(window.LAB3_DATA.metrics);
  const metricFields = window.LAB3_DATA.metrics;
  const metricUnits = {"海表温度":"°C","盐度":"PSU","溶解氧":"mmol/m³","叶绿素":"mg/m³","硝酸盐":"mmol/m³","磷酸盐":"mmol/m³","流速":"m/s"};
  const regions = geoJson.features.length ? geoJson.features.map(f => f.properties.region) : ["渤海","黄海北部","黄海南部","东海北部","东海东部","南海北部"];
  const depths = ["全部深度","0-10m","50-100m","200m"];
  const months = baseMeta.months || [...new Set(records.map(d => d.month_label))].sort();
  const riskLevels = ["全部风险","低风险","中风险","高风险"];
  const riskColor = {"低风险":"#1B9E77","中风险":"#D8A20F","高风险":"#D95F02"};
  const zoneToLevel = {"稳定区":"低风险","波动区":"中风险","高压区":"高风险"};
  const regionColor = d3.scaleOrdinal().domain(regions).range(["#4c78a8","#59a14f","#76b7b2","#edc949","#f28e2b","#e15759"]);
  const centers = Object.fromEntries(geoJson.features.map(f => [f.properties.region, f.properties.center]));
  regions.forEach(region => {
    if (!centers[region]) {
      const rows = records.filter(r => r.region_name === region);
      centers[region] = [d3.mean(rows, r => +r.longitude) || 118, d3.mean(rows, r => +r.latitude) || 30];
    }
  });
  const state = {stage:"overview", algorithm:"expert_rule", metric:metrics[0], region:"全部海域", depth:"全部深度", risk:"全部风险", monthIndex:months.length - 1, selectedRegion:regions[0], corrMethod:"pearson", playing:false};
  let playTimer = null;
  const params = new URLSearchParams(location.search);
  if (params.get("stage")) state.stage = params.get("stage");
  if (params.get("algorithm")) state.algorithm = params.get("algorithm");
  if (params.get("metric")) state.metric = params.get("metric");
  if (params.get("region")) { state.region = params.get("region"); state.selectedRegion = params.get("region"); }
  if (params.get("depth")) state.depth = params.get("depth");
  if (params.get("risk")) state.risk = params.get("risk");
  if (params.get("monthIndex")) state.monthIndex = Math.max(0, Math.min(months.length - 1, +params.get("monthIndex")));
  const scoreById = new Map(riskModels.record_scores.map(d => [d.record_id, d]));
  const tooltip = d3.select("#tooltip");

  function currentMonth(){ return months[state.monthIndex]; }
  function fmt(v){ return Number(v || 0).toLocaleString("zh-CN"); }
  function clear(svg){ svg.selectAll("*").remove(); }
  function showTip(event, html){ tooltip.html(html).style("opacity",1); moveTip(event); }
  function moveTip(event){ const pad=14, rect=tooltip.node().getBoundingClientRect(); let x=event.clientX+pad, y=event.clientY+pad; if(x+rect.width>innerWidth) x=event.clientX-rect.width-pad; if(y+rect.height>innerHeight) y=event.clientY-rect.height-pad; tooltip.style("transform",`translate(${Math.max(8,x)}px,${Math.max(8,y)}px)`); }
  function hideTip(){ tooltip.style("opacity",0); }
  function riskAgg(){ return riskModels.aggregates[state.algorithm]; }
  function levelOf(r, alg=state.algorithm){
    const row = scoreById.get(r.record_id);
    const v = row && row[alg];
    if (!v) return r.risk_level;
    return v.level || zoneToLevel[v.zone] || r.risk_level;
  }
  function scoreOf(r, alg=state.algorithm){
    const row = scoreById.get(r.record_id);
    return row && row[alg] ? +row[alg].score : +r.risk_score;
  }
  function filtered(opts={}){
    const alg = opts.algorithm || state.algorithm;
    const month = opts.month === undefined ? currentMonth() : opts.month;
    const region = opts.region === undefined ? state.region : opts.region;
    const depth = opts.depth === undefined ? state.depth : opts.depth;
    const risk = opts.risk === undefined ? state.risk : opts.risk;
    return records.filter(r =>
      (region === "全部海域" || r.region_name === region) &&
      (depth === "全部深度" || r.depth_group === depth) &&
      (month === "全部月份" || r.month_label === month) &&
      (risk === "全部风险" || levelOf(r, alg) === risk)
    );
  }
  function aggregateRegionRisk(rows, alg=state.algorithm){
    const byRegion = d3.group(rows, r => r.region_name);
    return regions.map(region => {
      const arr = byRegion.get(region) || [];
      const counts = d3.rollup(arr, v => v.length, r => levelOf(r, alg));
      const low = counts.get("低风险") || 0, mid = counts.get("中风险") || 0, high = counts.get("高风险") || 0;
      const score_mean = arr.length ? d3.mean(arr, r => scoreOf(r, alg)) : 0;
      const level = high >= mid && high >= low && high > 0 ? "高风险" : (mid >= low && mid > 0 ? "中风险" : "低风险");
      return {region, count:arr.length, low, mid, high, score_mean, level};
    });
  }
  function activeRegionRows({allMonths=false, ignoreRegion=true}={}){
    return filtered({
      month: allMonths ? "全部月份" : currentMonth(),
      region: ignoreRegion ? "全部海域" : state.region,
      depth: state.depth,
      risk: state.risk
    });
  }
  function buildMatrixData(){
    const rows = filtered({region:"全部海域", month:"全部月份", depth:"全部深度"});
    const groups = d3.group(rows, r => r.region_name, r => r.depth_group, r => r.month_label);
    const out = [];
    regions.forEach(region => depths.slice(1).forEach(depth => months.forEach(month => {
      const arr = (((groups.get(region) || new Map()).get(depth) || new Map()).get(month)) || [];
      const counts = d3.rollup(arr, v => v.length, r => levelOf(r));
      const low = counts.get("低风险") || 0, mid = counts.get("中风险") || 0, high = counts.get("高风险") || 0;
      const level = high >= mid && high >= low && high > 0 ? "高风险" : (mid >= low && mid > 0 ? "中风险" : "低风险");
      out.push({region, depth, month, count:arr.length, low, mid, high, score_mean:arr.length ? d3.mean(arr, r => scoreOf(r)) : 0, dominant_level:level});
    })));
    return out;
  }
  function matrixCell(matrix, region, month, depth){
    const rows = matrix.filter(d => d.region === region && d.month === month && (depth === "全部深度" || d.depth === depth));
    if (!rows.length) return {count:0, high:0, score_mean:0, dominant_level:"低风险"};
    const high = d3.sum(rows, d => d.high), count = d3.sum(rows, d => d.count);
    return {count, high, score_mean:d3.mean(rows, d => d.score_mean) || 0, dominant_level:rows.sort((a,b)=>b.count-a.count)[0].dominant_level};
  }
  function algorithmLevelsFor(region, month, depth){
    const scopeRows = records.filter(r => r.region_name === region && r.month_label === month && (depth === "全部深度" || r.depth_group === depth));
    const result = {};
    riskModels.meta.algorithms.forEach(alg => {
      const counts = d3.rollup(scopeRows, v => v.length, r => levelOf(r, alg.id));
      const level = [...counts.entries()].sort((a,b)=>b[1]-a[1])[0]?.[0] || "低风险";
      result[alg.short] = level;
    });
    return result;
  }
  function agreementFor(region, month=currentMonth(), depth=state.depth){
    const levels = Object.values(algorithmLevelsFor(region, month, depth));
    const top = d3.max(Array.from(d3.rollup(levels, v => v.length, d => d).values())) || 0;
    return levels.length ? top / levels.length : 0;
  }

  function setStage(stage){ state.stage = stage; syncStageClasses(); render(); }
  function syncStageClasses(){
    d3.selectAll(".stage-btn").classed("active", function(){return this.dataset.stage===state.stage});
    d3.selectAll(".stage").classed("active", function(){return this.id === `stage-${state.stage}`});
  }
  function setRegion(region){ state.region = region; if(region !== "全部海域") state.selectedRegion = region; syncControls(); render(); }
  function startPlay(){
    if (playTimer) clearInterval(playTimer);
    state.playing = true;
    d3.select("#btn-play").text("暂停");
    playTimer = setInterval(() => {
      state.monthIndex = (state.monthIndex + 1) % months.length;
      render();
    }, 900);
  }
  function stopPlay(){
    state.playing = false;
    if (playTimer) clearInterval(playTimer);
    playTimer = null;
    d3.select("#btn-play").text("播放");
  }

  function initControls(){
    d3.select("#algorithm-select").selectAll("option").data(riskModels.meta.algorithms).join("option").attr("value",d=>d.id).text(d=>d.name);
    d3.select("#metric-select").selectAll("option").data(metrics).join("option").attr("value",d=>d).text(d=>d);
    d3.select("#region-select").selectAll("option").data(["全部海域",...regions]).join("option").attr("value",d=>d).text(d=>d);
    d3.select("#depth-select").selectAll("option").data(depths).join("option").attr("value",d=>d).text(d=>d);
    d3.select("#risk-select").selectAll("option").data(riskLevels).join("option").attr("value",d=>d).text(d=>d);
    d3.select("#month-slider").attr("max", months.length - 1).on("input", e => { state.monthIndex = +e.target.value; render(); });
    d3.select("#algorithm-select").on("change", e => { state.algorithm=e.target.value; render(); });
    d3.select("#metric-select").on("change", e => { state.metric=e.target.value; render(); });
    d3.select("#region-select").on("change", e => setRegion(e.target.value));
    d3.select("#depth-select").on("change", e => { state.depth=e.target.value; render(); });
    d3.select("#risk-select").on("change", e => { state.risk=e.target.value; render(); });
    d3.selectAll(".stage-btn").on("click", function(){ setStage(this.dataset.stage); });
    d3.select("#btn-reset").on("click", () => { stopPlay(); Object.assign(state,{algorithm:"expert_rule",metric:metrics[0],region:"全部海域",depth:"全部深度",risk:"全部风险",monthIndex:months.length-1,selectedRegion:regions[0],corrMethod:"pearson"}); syncControls(); render(); });
    d3.select("#btn-focus").on("click", () => document.body.classList.toggle("focus-mode"));
    d3.select("#btn-fullscreen").on("click", () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen());
    d3.select("#btn-evidence").on("click", () => document.querySelector("#evidence-dialog").showModal());
    d3.select("#btn-play").on("click", () => state.playing ? stopPlay() : startPlay());
    d3.select("#corr-tabs").selectAll("button").data(["pearson","spearman","kendall"]).join("button").text(d=>({pearson:"Pearson",spearman:"Spearman",kendall:"Kendall"}[d])).on("click", (_,d)=>{state.corrMethod=d; renderCorrelation();});
    syncStageClasses();
    syncControls();
  }
  function syncControls(){
    d3.select("#algorithm-select").property("value", state.algorithm);
    d3.select("#metric-select").property("value", state.metric);
    d3.select("#region-select").property("value", state.region);
    d3.select("#depth-select").property("value", state.depth);
    d3.select("#risk-select").property("value", state.risk);
    d3.select("#month-slider").property("value", state.monthIndex);
    d3.select("#month-label").text(currentMonth());
  }
  function renderSummary(){
    syncControls();
    const rows = filtered();
    const high = rows.filter(r => levelOf(r) === "高风险").length;
    const algName = riskModels.meta.algorithms.find(a=>a.id===state.algorithm).short;
    const cards = [
      ["当前算法", algName, "可切换"],
      ["筛选记录", fmt(rows.length), "records"],
      ["当前月份", currentMonth(), "播放同步"],
      ["高风险", fmt(high), "算法结果"],
      ["选中海域", state.selectedRegion, state.depth]
    ];
    d3.select("#summary").selectAll(".summary-card").data(cards).join("div").attr("class","summary-card").html(d=>`<span>${d[0]}</span><b>${d[1]}</b><em>${d[2]}</em>`);
  }

  function projectionFor(w,h){
    const bbox = coast.bbox || [106,18,126,42];
    const x = d3.scaleLinear().domain([bbox[0], bbox[2]]).range([18, w-18]);
    const y = d3.scaleLinear().domain([bbox[1], bbox[3]]).range([h-26, 24]);
    return ([lon, lat]) => [x(lon), y(lat)];
  }
  function linePath(coords, projection){
    return coords.map((p,i)=>`${i ? "L" : "M"}${projection(p)[0].toFixed(2)},${projection(p)[1].toFixed(2)}`).join(" ");
  }
  function geometryPath(geom, projection){
    if(!geom) return "";
    if(geom.type === "LineString") return linePath(geom.coordinates, projection);
    if(geom.type === "MultiLineString") return geom.coordinates.map(line=>linePath(line, projection)).join(" ");
    if(geom.type === "Polygon") return geom.coordinates.map(ring=>linePath(ring, projection)+"Z").join(" ");
    if(geom.type === "MultiPolygon") return geom.coordinates.map(poly=>poly.map(ring=>linePath(ring, projection)+"Z").join(" ")).join(" ");
    if(geom.type === "GeometryCollection") return (geom.geometries||[]).map(g=>geometryPath(g, projection)).join(" ");
    return "";
  }
  function drawChinaBase(sel){
    const svg = d3.select(sel); clear(svg);
    const w = svg.node().clientWidth || 680, h = svg.node().clientHeight || 430;
    const defs = svg.append("defs");
    const grad = defs.append("linearGradient").attr("id",`${sel.replace("#","")}-sea`).attr("x1","0%").attr("x2","100%").attr("y1","0%").attr("y2","100%");
    grad.append("stop").attr("offset","0%").attr("stop-color","#e9fbff");
    grad.append("stop").attr("offset","100%").attr("stop-color","#bdebf3");
    svg.append("rect").attr("width",w).attr("height",h).attr("rx",16).attr("fill",`url(${sel}-sea)`);
    const projection = projectionFor(w,h);
    const g = svg.append("g");
    const bbox = coast.bbox || [106,18,126,42];
    d3.range(Math.ceil(bbox[0]/5)*5, bbox[2]+1, 5).forEach(lon => {
      const p1=projection([lon,bbox[1]]), p2=projection([lon,bbox[3]]);
      g.append("line").attr("x1",p1[0]).attr("y1",p1[1]).attr("x2",p2[0]).attr("y2",p2[1]).attr("stroke","#c9e5ec").attr("stroke-width",0.8).attr("opacity",.7);
      g.append("text").attr("x",p1[0]+2).attr("y",h-6).attr("font-size",9).attr("fill","#6b8794").text(`${lon}°E`);
    });
    d3.range(20, 43, 5).forEach(lat => {
      const p1=projection([bbox[0],lat]), p2=projection([bbox[2],lat]);
      g.append("line").attr("x1",p1[0]).attr("y1",p1[1]).attr("x2",p2[0]).attr("y2",p2[1]).attr("stroke","#c9e5ec").attr("stroke-width",0.8).attr("opacity",.7);
      g.append("text").attr("x",6).attr("y",p1[1]+3).attr("font-size",9).attr("fill","#6b8794").text(`${lat}°N`);
    });
    const land = coast.land || [];
    if (land.length) {
      g.selectAll("path.land").data(land).join("path").attr("class","land").attr("d",d=>geometryPath(d.geometry, projection)).attr("fill","#e9efe9").attr("stroke","#9aa98d").attr("stroke-width",1.05).attr("fill-rule","evenodd");
    }
    const lines = coast.coastlines || [];
    g.selectAll("path.coast").data(lines).join("path").attr("class","coast").attr("d",d=>geometryPath(d.geometry, projection)).attr("fill","none").attr("stroke","#5e7f72").attr("stroke-width",1.25).attr("opacity",.95);
    [[112,21,124,27],[114,24,123,34],[118,31,124,39]].forEach((line,i) => {
      const pts = d3.range(0,60).map(t => {
        const lon = line[0] + (line[2]-line[0]) * t/59;
        const lat = line[1] + (line[3]-line[1]) * t/59 + Math.sin(t/8)*0.35;
        return projection([lon,lat]);
      });
      g.append("path").attr("d",d3.line()(pts)).attr("fill","none").attr("stroke",i===0?"#78b7c7":"#96c1ce").attr("stroke-dasharray",i===0?"7 5":"3 5").attr("opacity",.48);
    });
    g.append("text").attr("x",18).attr("y",22).attr("fill","#326273").attr("font-size",12).attr("font-weight",700).text("中国近海底图 · Natural Earth 海岸线裁剪 · 非测绘边界");
    return {svg,g,projection,w,h};
  }
  function drawNearshoreMap(sel, options={}){
    const {g,projection,w,h} = drawChinaBase(sel);
    const rows = options.rows || activeRegionRows({allMonths:!!options.allMonths, ignoreRegion:true});
    const data = aggregateRegionRisk(rows);
    const maxCount = d3.max(data,d=>d.count) || 1;
    const rScale = d3.scaleSqrt().domain([0,maxCount]).range([12,30]);
    const labelOffset = {"渤海":[-16,-24],"黄海北部":[20,-8],"黄海南部":[20,14],"东海北部":[18,10],"东海南部":[18,20],"南海北部":[18,24]};
    const nodes = g.selectAll(".region-node").data(data).join("g")
      .attr("class","region-node")
      .attr("transform",d=>`translate(${projection(centers[d.region])[0]},${projection(centers[d.region])[1]})`)
      .style("cursor","pointer")
      .style("opacity",d=>state.region==="全部海域"||state.region===d.region?1:.38)
      .on("click",(_,d)=>setRegion(d.region));
    nodes.append("circle").attr("r",d=>rScale(d.count)+7).attr("fill","none").attr("stroke",d=>{
      const a=agreementFor(d.region,currentMonth(),state.depth); return a>=.9?"#075073":a>=.7?"#18b8c9":"#d95f02";
    }).attr("stroke-width",4).attr("opacity",.88);
    nodes.append("circle").attr("r",d=>rScale(d.count)).attr("fill",d=>riskColor[d.level]).attr("opacity",.9).attr("stroke","#fff").attr("stroke-width",2.2).classed("selected-node",d=>d.region===state.selectedRegion);
    nodes.append("text").attr("text-anchor","middle").attr("dy",5).attr("fill","#fff").attr("font-weight",900).attr("font-size",12).text(d=>d.high);
    nodes.append("text").attr("x",d=>(labelOffset[d.region]||[18,-18])[0]).attr("y",d=>(labelOffset[d.region]||[18,-18])[1]).attr("text-anchor",d=>(labelOffset[d.region]||[18,-18])[0]<0?"end":"start").attr("fill","#062335").attr("font-size",12).attr("font-weight",900).text(d=>d.region);
    nodes.on("mouseenter",(e,d)=>showTip(e,`<b>${d.region}</b><br>${currentMonth()} / ${state.depth}<br>算法等级：${d.level}<br>记录：${d.count} 条；高风险：${d.high} 条<br>多算法一致性：${Math.round(agreementFor(d.region,currentMonth(),state.depth)*100)}%`)).on("mousemove",moveTip).on("mouseleave",hideTip);
    const legend = g.append("g").attr("transform",`translate(36,${Math.max(48,h-104)})`);
    legend.append("rect").attr("x",-16).attr("y",-28).attr("width",112).attr("height",96).attr("rx",10).attr("fill","rgba(255,255,255,.78)").attr("stroke","#b7dce6");
    RISK_LEVELS().forEach((lv,i)=>{ legend.append("circle").attr("cx",0).attr("cy",i*22).attr("r",6.5).attr("fill",riskColor[lv]); legend.append("text").attr("x",13).attr("y",i*22+4).attr("font-size",11).attr("fill","#254456").text(lv); });
    legend.append("text").attr("x",-4).attr("y",-15).attr("font-size",11).attr("font-weight",800).text("当前风险等级");
  }

  function renderOverview(){
    drawNearshoreMap("#overview-map");
    const rows = filtered();
    const grid = d3.select("#indicator-grid").selectAll(".indicator").data(metrics).join("div").attr("class","indicator");
    grid.html(label => {
      const field = metricFields[label];
      const vals = rows.map(r=>+r[field]).filter(Number.isFinite);
      const all = records.map(r=>+r[field]).filter(Number.isFinite);
      const value = vals.length ? d3.mean(vals) : 0, lo=d3.min(all), hi=d3.max(all), pct=(value-lo)/(hi-lo||1)*100;
      return `<b>${label}</b><div class="bar"><i style="width:${Math.max(4,Math.min(100,pct))}%"></i></div><small>${currentMonth()} 均值 ${value.toFixed(2)} ${metricUnits[label]||""}</small>`;
    });
    drawTrend("#overview-trend", trendData(), "score_mean");
  }
  function trendData(){
    const rows = filtered({month:"全部月份"});
    return months.map(month => {
      const arr = rows.filter(r=>r.month_label===month);
      return {month,count:arr.length,score_mean:arr.length?d3.mean(arr,r=>scoreOf(r)):0,high:arr.filter(r=>levelOf(r)==="高风险").length};
    });
  }
  function drawTrend(sel, data, field){
    const svg=d3.select(sel); clear(svg); const w=svg.node().clientWidth||520,h=svg.node().clientHeight||260, m={t:20,r:28,b:36,l:48};
    const x=d3.scalePoint().domain(data.map(d=>d.month)).range([m.l,w-m.r]); const y=d3.scaleLinear().domain([0,d3.max(data,d=>+d[field])||1]).nice().range([h-m.b,m.t]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(data.map(d=>d.month).filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4));
    svg.append("path").datum(data).attr("fill","none").attr("stroke","#0077a8").attr("stroke-width",3).attr("d",d3.line().x(d=>x(d.month)).y(d=>y(+d[field])).curve(d3.curveMonotoneX));
    svg.selectAll("circle.pt").data(data).join("circle").attr("class","pt").attr("cx",d=>x(d.month)).attr("cy",d=>y(+d[field])).attr("r",d=>d.month===currentMonth()?5:2.6).attr("fill",d=>d.month===currentMonth()?"#D95F02":"#0077a8").attr("opacity",.9);
    if(x(currentMonth())!==undefined) {
      svg.append("line").attr("x1",x(currentMonth())).attr("x2",x(currentMonth())).attr("y1",m.t).attr("y2",h-m.b).attr("stroke","#D95F02").attr("stroke-width",2).attr("stroke-dasharray","5 4");
      svg.append("text").attr("x",x(currentMonth())).attr("y",m.t+12).attr("text-anchor","middle").attr("fill","#D95F02").attr("font-weight",800).attr("font-size",11).text(currentMonth());
    }
  }
  function renderRisk(){
    drawAlgorithmBars();
    drawRegionRank();
    const alg = riskModels.meta.algorithms.find(a=>a.id===state.algorithm);
    const rows = filtered();
    const counts = d3.rollup(rows, v=>v.length, r=>levelOf(r));
    d3.select("#risk-evidence").html(`
      <p><span class="pill">当前算法</span>${alg.name}</p>
      <p>${alg.basis}</p>
      <p><b>分级规则：</b>${alg.classification}</p>
      <p><b>当前筛选：</b>${state.region} / ${state.depth} / ${currentMonth()}，低风险 ${counts.get("低风险")||0} 条，中风险 ${counts.get("中风险")||0} 条，高风险 ${counts.get("高风险")||0} 条。</p>
      <p><b>课堂要求回应：</b>风险由可解释算法给出，用户可以切换算法；相关性页面只解释变量关系，不参与风险分级。</p>`);
  }
  function drawAlgorithmBars(){
    const svg=d3.select("#risk-algorithm-bars"); clear(svg); const w=svg.node().clientWidth||520,h=svg.node().clientHeight||260,m={t:20,r:18,b:42,l:55};
    const algs=riskModels.meta.algorithms.map(a=>a.id), names=Object.fromEntries(riskModels.meta.algorithms.map(a=>[a.id,a.short]));
    const data=[]; algs.forEach(a=>RISK_LEVELS().forEach(lv=>data.push({alg:a,level:lv,count:filtered({algorithm:a,risk:"全部风险"}).filter(r=>levelOf(r,a)===lv).length})));
    const x0=d3.scaleBand().domain(algs).range([m.l,w-m.r]).padding(.22), x1=d3.scaleBand().domain(RISK_LEVELS()).range([0,x0.bandwidth()]).padding(.06), y=d3.scaleLinear().domain([0,d3.max(data,d=>d.count)||1]).nice().range([h-m.b,m.t]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x0).tickFormat(d=>names[d]));
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.selectAll("rect").data(data).join("rect").attr("x",d=>x0(d.alg)+x1(d.level)).attr("y",d=>y(d.count)).attr("width",x1.bandwidth()).attr("height",d=>h-m.b-y(d.count)).attr("fill",d=>riskColor[d.level]).attr("opacity",d=>d.alg===state.algorithm?1:.58);
    svg.selectAll(".lab").data(data.filter(d=>d.level==="高风险")).join("text").attr("x",d=>x0(d.alg)+x0.bandwidth()/2).attr("y",d=>y(d.count)-5).attr("text-anchor","middle").attr("font-size",11).attr("font-weight",800).text(d=>d.count);
  }
  function RISK_LEVELS(){return ["低风险","中风险","高风险"];}
  function drawRegionRank(){
    const svg=d3.select("#risk-region-rank"); clear(svg); const w=svg.node().clientWidth||520,h=svg.node().clientHeight||260,m={t:18,r:34,b:28,l:76};
    const data=aggregateRegionRisk(activeRegionRows({ignoreRegion:true})).sort((a,b)=>b.score_mean-a.score_mean);
    const x=d3.scaleLinear().domain([0,d3.max(data,d=>d.score_mean)||1]).nice().range([m.l,w-m.r]), y=d3.scaleBand().domain(data.map(d=>d.region)).range([m.t,h-m.b]).padding(.22);
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(4));
    svg.selectAll("rect").data(data).join("rect").attr("x",m.l).attr("y",d=>y(d.region)).attr("width",d=>Math.max(2,x(d.score_mean)-m.l)).attr("height",y.bandwidth()).attr("rx",6).attr("fill",d=>riskColor[d.level]).on("click",(_,d)=>setRegion(d.region));
    svg.selectAll(".v").data(data).join("text").attr("x",d=>x(d.score_mean)+5).attr("y",d=>y(d.region)+y.bandwidth()/2+4).attr("font-size",11).text(d=>d.score_mean.toFixed(2));
  }
  function drawMatrix(sel, matrix, options={}){
    const svg=d3.select(sel); clear(svg); const w=svg.node().clientWidth||720,h=svg.node().clientHeight||420,m={t:30,r:12,b:48,l:78};
    const ms=months, rs=options.regionOnly ? [state.selectedRegion] : regions;
    const data=matrix.filter(d=>(!options.depth || options.depth==="全部深度" || d.depth===options.depth) && rs.includes(d.region));
    const grouped=[];
    rs.forEach(r=>ms.forEach(mo=>{
      const rows=data.filter(d=>d.region===r && d.month===mo);
      grouped.push({region:r,month:mo,count:d3.sum(rows,d=>d.count),score_mean:rows.length?d3.mean(rows,d=>d.score_mean):0,high:d3.sum(rows,d=>d.high||0),dominant_level:rows.length?rows.sort((a,b)=>b.count-a.count)[0].dominant_level:"低风险"});
    }));
    const x=d3.scaleBand().domain(ms).range([m.l,w-m.r]).padding(.05), y=d3.scaleBand().domain(rs).range([m.t,h-m.b]).padding(.08);
    const max=d3.max(grouped,d=>d.score_mean)||1; const color=d3.scaleLinear().domain([0,max*.5,max]).range(["#e9f7f4","#70c7ad","#d95f02"]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(ms.filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    if(x(currentMonth())!==undefined) svg.append("rect").attr("class","month-highlight").attr("x",x(currentMonth())).attr("y",m.t).attr("width",x.bandwidth()).attr("height",h-m.t-m.b);
    if(y(state.selectedRegion)!==undefined) svg.append("rect").attr("class","row-highlight").attr("x",m.l).attr("y",y(state.selectedRegion)).attr("width",w-m.l-m.r).attr("height",y.bandwidth());
    svg.selectAll("rect.cell").data(grouped).join("rect").attr("class","cell").attr("x",d=>x(d.month)).attr("y",d=>y(d.region)).attr("width",x.bandwidth()).attr("height",y.bandwidth()).attr("rx",3).attr("fill",d=>color(d.score_mean)).attr("stroke",d=>d.month===currentMonth()&&d.region===state.selectedRegion?"#062335":"#fff").attr("stroke-width",d=>d.month===currentMonth()&&d.region===state.selectedRegion?3:1).on("click",(_,d)=>{state.selectedRegion=d.region; state.region=d.region; state.monthIndex=months.indexOf(d.month); syncControls(); render();}).on("mouseenter",(e,d)=>showTip(e,`<b>${d.region} ${d.month}</b><br>风险均值：${d.score_mean.toFixed(2)}<br>高风险：${d.high} 条<br>记录：${d.count} 条`)).on("mousemove",moveTip).on("mouseleave",hideTip);
  }
  function renderSpacetime(){
    drawMatrix("#spacetime-matrix", buildMatrixData(), {depth:state.depth});
    drawMetricMomentMap();
    drawDepthProfile();
  }
  function drawMetricMomentMap(){
    const {g,projection} = drawChinaBase("#metric-moment-map");
    const field=metricFields[state.metric];
    const rows=filtered({region:"全部海域"});
    const byReg=d3.rollup(rows,v=>d3.mean(v,d=>+d[field]),d=>d.region_name); const vals=[...byReg.values()].filter(Number.isFinite);
    const color=d3.scaleLinear().domain([d3.min(vals)||0,d3.max(vals)||1]).range(["#e6f7fb","#0077a8"]);
    g.selectAll(".metric-node").data(regions).join("circle").attr("class","metric-node").attr("cx",d=>projection(centers[d])[0]).attr("cy",d=>projection(centers[d])[1]).attr("r",12).attr("fill",d=>color(byReg.get(d)||0)).attr("stroke","#fff").attr("stroke-width",2).on("click",(_,d)=>setRegion(d));
    g.selectAll(".metric-label").data(regions).join("text").attr("class","metric-label").attr("x",d=>projection(centers[d])[0]+14).attr("y",d=>projection(centers[d])[1]+4).attr("font-size",10).attr("font-weight",800).text(d=>d);
  }
  function drawDepthProfile(){
    const svg=d3.select("#depth-profile"); clear(svg); const w=svg.node().clientWidth||420,h=svg.node().clientHeight||260,m={t:18,r:20,b:42,l:60};
    const field=metricFields[state.metric];
    const rows=filtered({depth:"全部深度"});
    const data=depths.slice(1).map(depth=>{const arr=rows.filter(r=>r.depth_group===depth); return {depth,value:arr.length?d3.mean(arr,r=>+r[field]):0};});
    const x=d3.scaleBand().domain(depths.slice(1)).range([m.l,w-m.r]).padding(.3), y=d3.scaleLinear().domain([0,d3.max(data,d=>d.value)||1]).nice().range([h-m.b,m.t]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x));
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
    svg.selectAll("rect").data(data).join("rect").attr("x",d=>x(d.depth)).attr("y",d=>y(d.value)).attr("width",x.bandwidth()).attr("height",d=>h-m.b-y(d.value)).attr("rx",7).attr("fill","#18b8c9");
    svg.selectAll(".dv").data(data).join("text").attr("x",d=>x(d.depth)+x.bandwidth()/2).attr("y",d=>y(d.value)-6).attr("text-anchor","middle").attr("font-size",11).text(d=>d.value.toFixed(2));
  }
  function renderCorrelation(){
    d3.selectAll("#corr-tabs button").classed("active",function(){return this.textContent.toLowerCase().includes(state.corrMethod==="pearson"?"pearson":state.corrMethod==="spearman"?"spearman":"kendall")});
    drawCorrMatrix(); drawLagHeatmap(); drawMoran(); drawParallel();
  }
  function drawCorrMatrix(){
    const svg=d3.select("#corr-matrix"); clear(svg); const w=svg.node().clientWidth||620,h=svg.node().clientHeight||320,m={t:24,r:10,b:64,l:78};
    const labs=corrData.metrics, matrix=corrData.matrices[state.corrMethod]; const x=d3.scaleBand().domain(labs).range([m.l,w-m.r]).padding(.04), y=d3.scaleBand().domain(labs).range([m.t,h-m.b]).padding(.04);
    const color=d3.scaleLinear().domain([-1,0,1]).range(["#2166ac","#f7fbff","#b2182b"]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x)).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    const cells=[]; labs.forEach((a,i)=>labs.forEach((b,j)=>cells.push({a,b,v:matrix[i][j]})));
    svg.selectAll("rect").data(cells).join("rect").attr("x",d=>x(d.b)).attr("y",d=>y(d.a)).attr("width",x.bandwidth()).attr("height",y.bandwidth()).attr("fill",d=>color(d.v)).attr("stroke","#fff");
    svg.selectAll(".ct").data(cells.filter(d=>Math.abs(d.v)>.55 || d.a===d.b)).join("text").attr("x",d=>x(d.b)+x.bandwidth()/2).attr("y",d=>y(d.a)+y.bandwidth()/2+4).attr("text-anchor","middle").attr("font-size",10).attr("fill",d=>Math.abs(d.v)>.7?"#fff":"#15384a").text(d=>d.v.toFixed(2));
  }
  function drawLagHeatmap(){
    const svg=d3.select("#lag-heatmap"); clear(svg); const w=svg.node().clientWidth||420,h=svg.node().clientHeight||260,m={t:18,r:12,b:42,l:68};
    const labs=corrData.metrics, lags=d3.range(-6,7); const x=d3.scaleBand().domain(lags).range([m.l,w-m.r]).padding(.04), y=d3.scaleBand().domain(labs).range([m.t,h-m.b]).padding(.04), color=d3.scaleLinear().domain([-1,0,1]).range(["#2166ac","#f7fbff","#b2182b"]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues([-6,-3,0,3,6]));
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    svg.selectAll("rect").data(corrData.time_lag).join("rect").attr("x",d=>x(d.lag)).attr("y",d=>y(d.metric)).attr("width",x.bandwidth()).attr("height",y.bandwidth()).attr("fill",d=>color(d.corr)).attr("stroke","#fff");
  }
  function drawMoran(){
    const svg=d3.select("#moran-chart"); clear(svg); const w=svg.node().clientWidth||420,h=svg.node().clientHeight||260,m={t:20,r:24,b:50,l:58};
    const data=corrData.spatial_moran; const x=d3.scaleBand().domain(data.map(d=>d.metric)).range([m.l,w-m.r]).padding(.28), y=d3.scaleLinear().domain([Math.min(-.6,d3.min(data,d=>d.moran_i)),Math.max(.6,d3.max(data,d=>d.moran_i))]).nice().range([h-m.b,m.t]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x)).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5)); svg.append("line").attr("x1",m.l).attr("x2",w-m.r).attr("y1",y(0)).attr("y2",y(0)).attr("stroke","#8098a4");
    svg.selectAll("rect").data(data).join("rect").attr("x",d=>x(d.metric)).attr("y",d=>y(Math.max(0,d.moran_i))).attr("width",x.bandwidth()).attr("height",d=>Math.abs(y(d.moran_i)-y(0))).attr("fill",d=>d.moran_i>=0?"#0077a8":"#D95F02");
  }
  function drawParallel(){
    const svg=d3.select("#parallel-chart"); clear(svg); const w=svg.node().clientWidth||900,h=svg.node().clientHeight||170,m={t:14,r:30,b:28,l:55}; const dims=["risk_score",...corrData.metrics];
    const data=corrData.parallel; const x=d3.scalePoint().domain(dims).range([m.l,w-m.r]); const y=d3.scaleLinear().domain([0,1]).range([h-m.b,m.t]);
    const extent={}; dims.forEach(dim=>{ const vals=data.map(d=>+d[dim]); extent[dim]=[d3.min(vals),d3.max(vals)]; });
    const norm=(row,dim)=>{ const [lo,hi]=extent[dim]; return (row[dim]-lo)/(hi-lo || 1); };
    dims.forEach(dim=>{ svg.append("line").attr("x1",x(dim)).attr("x2",x(dim)).attr("y1",m.t).attr("y2",h-m.b).attr("stroke","#a9c8d2"); svg.append("text").attr("x",x(dim)).attr("y",h-5).attr("text-anchor","middle").attr("font-size",10).text(dim==="risk_score"?"风险":dim); });
    const line=d3.line().x(d=>x(d.dim)).y(d=>y(d.value)).curve(d3.curveLinear);
    svg.selectAll("path.line").data(data).join("path").attr("fill","none").attr("stroke",d=>regionColor(d.region)).attr("stroke-width",d=>d.region===state.selectedRegion?4:2.6).attr("opacity",d=>d.region===state.selectedRegion?1:.55).attr("d",row=>line(dims.map(dim=>({dim,value:norm(row,dim)}))));
    data.forEach(row=>svg.selectAll(`circle-${row.region}`).data(dims.map(dim=>({dim,value:norm(row,dim),region:row.region}))).join("circle").attr("cx",d=>x(d.dim)).attr("cy",d=>y(d.value)).attr("r",3.2).attr("fill",regionColor(row.region)).attr("stroke","#fff").attr("stroke-width",1));
    const legend=svg.append("g").attr("transform",`translate(${m.l},${m.t})`);
    data.forEach((row,i)=>{ legend.append("circle").attr("cx",i*92).attr("cy",0).attr("r",4).attr("fill",regionColor(row.region)); legend.append("text").attr("x",i*92+8).attr("y",4).attr("font-size",10).text(row.region); });
  }
  function renderNovel(){
    drawNearshoreMap("#novel-map");
    const matrix = buildMatrixData();
    drawMatrix("#novel-matrix", matrix, {depth:state.depth, regionOnly:false});
    const cell = matrixCell(matrix, state.selectedRegion, currentMonth(), state.depth);
    const levels = algorithmLevelsFor(state.selectedRegion, currentMonth(), state.depth);
    const agreement = agreementFor(state.selectedRegion, currentMonth(), state.depth);
    d3.select("#novel-detail").html(`<p><span class="pill">新颖图表</span>多算法风险共识地图-海域月份深度预警矩阵</p>
      <p><b>选中：</b>${state.selectedRegion} / ${currentMonth()} / ${state.depth}</p>
      <p><b>四算法判定：</b>${Object.entries(levels).map(([k,v])=>`${k}:${v}`).join("，")}；一致性 ${Math.round(agreement*100)}%。</p>
      <p><b>矩阵单元：</b>记录 ${cell.count} 条，高风险 ${cell.high} 条，风险均值 ${cell.score_mean.toFixed(2)}。</p>
      <p><b>创新性：</b>一张图同时编码空间位置、时间月份、深度层、多算法结果与算法分歧；点击后给出指标证据链，解决普通地图和普通热力图无法同时解释“在哪里、何时、何深度、凭什么判定”的问题。</p>`);
  }
  function renderSmart(){ drawAnomaly(); drawContrib(); renderDiagnosis(); }
  function drawAnomaly(){
    const svg=d3.select("#anomaly-strip"); clear(svg); const w=svg.node().clientWidth||520,h=svg.node().clientHeight||260,m={t:18,r:15,b:42,l:74};
    const rows=(analytics.anomaly||[]).filter(d=>d.region===state.selectedRegion); const agg=months.map(mo=>({month:mo,score:d3.mean(rows.filter(d=>d.month===mo),d=>d.anomaly_score)||0}));
    const x=d3.scaleBand().domain(months).range([m.l,w-m.r]).padding(.04), y=d3.scaleLinear().domain([0,d3.max(agg,d=>d.score)||1]).range([h-m.b,m.t]), color=d3.scaleLinear().domain([0,1.5,3]).range(["#e9f7f4","#70c7ad","#d95f02"]);
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).tickValues(months.filter((_,i)=>i%3===0))).selectAll("text").attr("transform","rotate(-28)").style("text-anchor","end");
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4));
    svg.selectAll("rect").data(agg).join("rect").attr("x",d=>x(d.month)).attr("y",d=>y(d.score)).attr("width",x.bandwidth()).attr("height",d=>h-m.b-y(d.score)).attr("fill",d=>color(d.score)).attr("stroke",d=>d.month===currentMonth()?"#062335":"none").attr("stroke-width",d=>d.month===currentMonth()?2:0);
  }
  function drawContrib(){
    const svg=d3.select("#contribution-bars"); clear(svg); const w=svg.node().clientWidth||520,h=svg.node().clientHeight||260,m={t:24,r:118,b:34,l:88};
    const regional=(analytics.regional_contributions&&analytics.regional_contributions[state.selectedRegion]) || null;
    const source=regional || analytics.contributions || [];
    const rows=source.slice(0,7).map(d=>{ const signed = d.signed_score !== undefined ? +d.signed_score : +(d.correlation || d.value || d.weight || 0); const strength = d.score !== undefined ? +d.score : (d.abs_weight !== undefined ? +d.abs_weight : Math.abs(signed)); const direction = d.direction || (signed >= 0 ? "推高风险" : "缓释风险"); return {metric:d.metric||d.label, strength, signed: signed < 0 ? -strength : strength, direction}; });
    const maxv=d3.max(rows,d=>Math.abs(d.signed))||1;
    const x=d3.scaleLinear().domain([-maxv,maxv]).nice().range([m.l,w-m.r]), y=d3.scaleBand().domain(rows.map(d=>d.metric)).range([m.t,h-m.b]).padding(.25);
    svg.append("g").attr("transform",`translate(${m.l},0)`).call(d3.axisLeft(y));
    svg.append("g").attr("transform",`translate(0,${h-m.b})`).call(d3.axisBottom(x).ticks(5));
    svg.append("line").attr("x1",x(0)).attr("x2",x(0)).attr("y1",m.t-8).attr("y2",h-m.b).attr("stroke","#506b78").attr("stroke-width",1.2);
    svg.selectAll("rect").data(rows).join("rect").attr("x",d=>x(Math.min(0,d.signed))).attr("y",d=>y(d.metric)).attr("width",d=>Math.abs(x(d.signed)-x(0))).attr("height",y.bandwidth()).attr("rx",6).attr("fill",d=>d.signed>=0?"#D95F02":"#0077a8");
    svg.selectAll(".cv").data(rows).join("text").attr("x",d=>d.signed>=0?x(d.signed)+5:x(d.signed)-5).attr("y",d=>y(d.metric)+y.bandwidth()/2+4).attr("text-anchor",d=>d.signed>=0?"start":"end").attr("font-size",11).attr("fill","#17384a").text(d=>`${d.direction} ${d.strength.toFixed(2)}`);
    svg.append("text").attr("x",x(-maxv*.72)).attr("y",14).attr("text-anchor","middle").attr("font-size",11).attr("fill","#0077a8").text("缓释风险");
    svg.append("text").attr("x",x(maxv*.72)).attr("y",14).attr("text-anchor","middle").attr("font-size",11).attr("fill","#D95F02").text("推高风险");
  }
  function renderDiagnosis(){
    const rows = filtered();
    const high = rows.filter(r=>levelOf(r)==="高风险").length;
    const alg = riskModels.meta.algorithms.find(a=>a.id===state.algorithm);
    const regContrib = (analytics.regional_contributions&&analytics.regional_contributions[state.selectedRegion]) || [];
    const topMetric = regContrib.find(d=>d.direction==="推高风险") || regContrib[0] || (analytics.contributions || [])[0];
    d3.select("#diagnosis-card").html(`<p><span class="pill">智能研判</span>${state.selectedRegion} · ${currentMonth()} · ${alg.short}</p>
      <p><b>风险状态：</b>当前筛选 ${rows.length} 条，其中高风险 ${high} 条；算法依据为 ${alg.name}。</p>
      <p><b>建议关注指标：</b>${topMetric ? topMetric.metric : "溶解氧/营养盐"}。贡献图按区域 score / signed_score / direction 解释推高或缓释因素，不作为风险分级本身。</p>
      <p><b>下一步路径：</b>先在新颖图表中定位海域与月份，再进入相关性页查看指标关系，最后用时空特征页检查单指标在深度层的变化。</p>`);
  }
  function renderAll(){
    renderSummary();
    if(state.stage==="overview") renderOverview();
    if(state.stage==="risk") renderRisk();
    if(state.stage==="spacetime") renderSpacetime();
    if(state.stage==="correlation") renderCorrelation();
    if(state.stage==="novel") renderNovel();
    if(state.stage==="smart") renderSmart();
  }
  function render(){ renderAll(); }
  initControls();
  render();
})();
