// smartAnalysis: retained for experiment directory structure; final Lab3 runtime is orchestrated by js/main.js.
window.smartAnalysis = window.smartAnalysis || {};
