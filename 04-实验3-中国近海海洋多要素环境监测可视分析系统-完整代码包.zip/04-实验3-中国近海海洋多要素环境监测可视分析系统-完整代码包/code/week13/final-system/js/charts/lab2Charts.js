// lab2Charts: retained for experiment directory structure; final Lab3 runtime is orchestrated by js/main.js.
window.lab2Charts = window.lab2Charts || {};
