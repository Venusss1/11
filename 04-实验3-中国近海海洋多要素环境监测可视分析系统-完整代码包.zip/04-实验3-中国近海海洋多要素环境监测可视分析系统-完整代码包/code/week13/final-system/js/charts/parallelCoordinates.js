// parallelCoordinates: retained for experiment directory structure; final Lab3 runtime is orchestrated by js/main.js.
window.parallelCoordinates = window.parallelCoordinates || {};
