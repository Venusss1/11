/* VADITA-Ocean · 人类活动对中国近海影响
 * 严格借鉴 VADITA (IEEE VAST 2024, 复旦 Shan et al.) 的六面板协同设计与
 * “总览→聚合+聚焦→细节”逐级下钻工作流。
 * 数据 window.VADITA：真实港口/海岸线(Natural Earth) + 基于真实港口的可信活动建模。
 */
(function () {
  const D = window.VADITA;
  const META = D.meta, PORTS = D.ports, VESSELS = D.vessels, MONTHS = META.months;
  const VTYPES = META.vtypes;
  const portByName = {}; PORTS.forEach(p => portByName[p.name] = p);
  const LTYPE_COLOR = { "商业港": "#4e79a7", "渔港": "#f28e2b", "生态保护区": "#e15759", "锚地": "#76b7b2" };

  // ---- 全局协同状态 ----
  const S = {
    selected: VESSELS.map(v => v.id),  // 框选/筛选得到的船只集合（聚合）
    focus: null,                       // 聚焦的单船 id
    analyticsOpen: false,              // 框选或聚焦后展开时间线与统计视图
    step: "overview",
    filters: { act: new Set(), vtype: new Set(), sea: new Set(), onlyAnom: false, t0: 0, t1: 11 },
  };
  const tip = d3.select("#tooltip");
  const showTip = (e, html) => tip.html(html).style("opacity", 1).style("left", (e.pageX + 14) + "px").style("top", (e.pageY + 12) + "px");
  const hideTip = () => tip.style("opacity", 0);
  const dims = sel => { const r = d3.select(sel).node().getBoundingClientRect(); return { w: Math.max(220, r.width), h: Math.max(160, r.height) }; };
  const monthOfDay = day => Math.max(0, Math.min(11, Math.floor((day - 1) / 30)));
  const inTimeWindow = vis => {
    const m = monthOfDay(vis.day);
    return m >= S.filters.t0 && m <= S.filters.t1;
  };
  const timeRangeLabel = () => S.filters.t0 === 0 && S.filters.t1 === 11
    ? "全年"
    : `${MONTHS[S.filters.t0]} ~ ${MONTHS[S.filters.t1]}`;

  // ===== 筛选逻辑 =====
  function passFilter(v) {
    const f = S.filters;
    if (f.act.size && !f.act.has(v.act)) return false;
    if (f.vtype.size && !f.vtype.has(v.vtype)) return false;
    if (f.sea.size && !f.sea.has(v.sea)) return false;
    if (f.onlyAnom && !v.anomalous) return false;
    return true;
  }
  function applyFilter() {
    S.selected = VESSELS.filter(passFilter).map(v => v.id);
    if (S.focus && !S.selected.includes(S.focus)) S.focus = null;
    setStep(S.focus ? "focus" : "overview");
    renderAll();
  }
  const selVessels = () => VESSELS.filter(v => S.selected.includes(v.id));
  const focusV = () => S.focus ? VESSELS.find(v => v.id === S.focus) : null;

  // ===== 工作流步骤 =====
  function setAnalyticsOpen(open) {
    S.analyticsOpen = open;
    d3.select(".layout").classed("analytics-open", open);
  }

  function setStep(step) {
    if (step === "detail" && !S.focus) step = S.selected.length ? "focus" : "overview";
    S.step = step;
    d3.selectAll(".wf-step")
      .classed("active", function () { return this.dataset.step === step; })
      .classed("disabled", function () { return this.dataset.step === "detail" && !S.focus; });
    renderDetailDrawer();
  }

  function buildWorkflow() {
    d3.selectAll(".wf-step").on("click", function () {
      const step = this.dataset.step;
      if (step === "overview") {
        S.focus = null;
        S.selected = VESSELS.filter(passFilter).map(v => v.id);
        setAnalyticsOpen(false);
        setStep("overview");
        renderAll();
        return;
      }
      if (step === "focus") {
        if (!S.selected.length) S.selected = VESSELS.filter(passFilter).map(v => v.id);
        setAnalyticsOpen(true);
        setStep("focus");
        renderAll();
        d3.select("#clusterHint").text(S.focus
          ? "\u5df2\u8fdb\u5165\u805a\u7126\u5206\u6790\uff1a\u4e0b\u65b9\u65f6\u95f4\u7ebf\u548c\u7edf\u8ba1\u89c6\u56fe\u5c55\u793a\u5f53\u524d\u5355\u8239\u4e0e\u7fa4\u4f53\u5bf9\u6bd4"
          : "\u5df2\u5c55\u5f00\u805a\u5408\u5206\u6790\uff1a\u4e0b\u65b9\u65f6\u95f4\u7ebf\u548c\u7edf\u8ba1\u89c6\u56fe\u5c55\u793a\u5f53\u524d\u7b5b\u9009\u8239\u53ea\u7fa4\u4f53");
        return;
      }
      if (step === "detail" && !S.focus) {
        setAnalyticsOpen(true);
        setStep("focus");
        renderAll();
        d3.select("#clusterHint").text("\u8bf7\u5148\u5728\u201c\u8239\u53ea\u884c\u4e3a\u76f8\u4f3c\u5ea6\u5206\u5e03\u201d\u4e2d\u70b9\u51fb\u4e00\u8258\u8239\uff0c\u518d\u8fdb\u5165\u7ec6\u8282\u9636\u6bb5");
        return;
      }
      if (step === "detail") setAnalyticsOpen(true);
      setStep(step);
    });
    d3.select("#detailClose").on("click", () => setStep(S.focus ? "focus" : "overview"));
    d3.select("#detailMask").on("click", () => setStep(S.focus ? "focus" : "overview"));
    d3.select(document).on("keydown.detail", e => {
      if (e.key === "Escape" && S.step === "detail") setStep(S.focus ? "focus" : "overview");
    });
  }

  // ===== 地图投影 =====
  const bbox = META.bbox;
  function projector(w, h, pad = 16) {
    const bounds = {
      type: "MultiPoint",
      coordinates: [
        [bbox[0], bbox[1]], [bbox[2], bbox[1]],
        [bbox[2], bbox[3]], [bbox[0], bbox[3]]
      ]
    };
    const projection = d3.geoMercator().fitExtent([[pad, pad], [w - pad, h - pad]], bounds);
    const centerLon = (bbox[0] + bbox[2]) / 2;
    const centerLat = (bbox[1] + bbox[3]) / 2;
    const x = lon => projection([lon, centerLat])[0];
    const y = lat => projection([centerLon, lat])[1];
    return { x, y };
  }

  // ============ A 过滤面板 + B 图例 ============
  function buildFilters() {
    const acts = [...new Set(VESSELS.map(v => v.act))];
    const vts = Object.keys(VTYPES);
    const seas = META.seas;
    const mk = (host, items, key, colorFn) => {
      const sel = d3.select(host).selectAll("span").data(items).enter().append("span")
        .attr("class", "chip").text(d => d)
        .style("border-left", d => colorFn ? `10px solid ${colorFn(d)}` : null)
        .on("click", function (e, d) {
          const set = S.filters[key];
          set.has(d) ? set.delete(d) : set.add(d);
          d3.select(this).classed("on", set.has(d));
          applyFilter();
        });
    };
    mk("#actFilter", acts, "act", null);
    mk("#vtypeFilter", vts, "vtype", d => VTYPES[d].color);
    mk("#seaFilter", seas, "sea", null);

    d3.select("#onlyAnom").on("change", function () { S.filters.onlyAnom = this.checked; applyFilter(); });
    d3.select("#resetBtn").on("click", () => {
      S.filters = { act: new Set(), vtype: new Set(), sea: new Set(), onlyAnom: false, t0: 0, t1: 11 };
      d3.selectAll(".chip").classed("on", false);
      d3.select("#onlyAnom").property("checked", false);
      d3.select("#timeStart").property("value", 0); d3.select("#timeEnd").property("value", 11);
      syncRangeUI(0, 11);
      S.focus = null; applyFilter();
    });
    const syncRangeUI = (a, b) => {
      d3.select(".dual-range")
        .style("--range-start", `${a / 11 * 100}%`)
        .style("--range-end", `${b / 11 * 100}%`);
    };
    const upT = source => {
      let a = +d3.select("#timeStart").property("value"), b = +d3.select("#timeEnd").property("value");
      if (source === "start" && a > b) {
        a = b;
        d3.select("#timeStart").property("value", a);
      } else if (source === "end" && b < a) {
        b = a;
        d3.select("#timeEnd").property("value", b);
      }
      S.filters.t0 = a; S.filters.t1 = b;
      syncRangeUI(a, b);
      renderAll();
    };
    d3.select("#timeStart").on("input", () => upT("start"));
    d3.select("#timeEnd").on("input", () => upT("end"));
    syncRangeUI(S.filters.t0, S.filters.t1);
  }
  function buildLegend() {
    const host = d3.select("#legend"); host.selectAll("*").remove();
    host.append("div").attr("class", "lg-sec").text("船只类型 / 主导活动");
    Object.entries(VTYPES).forEach(([k, m]) => {
      const r = host.append("div").attr("class", "lg-item");
      r.append("i").style("background", m.color);
      r.append("span").text(`${k} · ${m.act}（${m.stress}）`);
    });
    host.append("div").attr("class", "lg-sec").text("活动地点类型");
    Object.entries(LTYPE_COLOR).forEach(([k, c]) => {
      const r = host.append("div").attr("class", "lg-item");
      r.append("i").style("background", c).style("border-radius", "50%");
      r.append("span").text(k);
    });
    const r2 = host.append("div").attr("class", "lg-item");
    r2.append("i").style("background", "none").style("border", "2px solid #ff7f0e").style("border-radius", "50%");
    r2.append("span").text("可疑船只(描边)");
  }

  // ============ C 聚类视图（散点 + 框选 + 点击聚焦）============
  function drawCluster() {
    const sel = "#clusterView"; d3.select(sel).selectAll("*").remove();
    const { w, h } = dims(sel); const m = 14;
    const svg = d3.select(sel).append("svg").attr("width", w).attr("height", h);
    const xs = d3.extent(VESSELS, v => v.tsne[0]), ys = d3.extent(VESSELS, v => v.tsne[1]);
    const x = d3.scaleLinear().domain(xs).range([m, w - m]);
    const y = d3.scaleLinear().domain(ys).range([h - m, m]);
    // 坐标轴提示
    svg.append("text").attr("x", w - 6).attr("y", h - 4).attr("text-anchor", "end").attr("class", "axhint").text("活跃度 →");
    svg.append("text").attr("x", 4).attr("y", 12).attr("class", "axhint").text("↑ 可疑度(保护区停留)");

    // 框选
    const brush = d3.brush().extent([[0, 0], [w, h]]).on("end", brushed);
    svg.append("g").attr("class", "brush").call(brush);

    const pts = svg.append("g").selectAll("circle").data(VESSELS).enter().append("circle")
      .attr("cx", d => x(d.tsne[0])).attr("cy", d => y(d.tsne[1]))
      .attr("r", d => S.focus === d.id ? 8 : 5)
      .attr("fill", d => VTYPES[d.vtype].color)
      .attr("stroke", d => d.anomalous ? "#ff7f0e" : "#1b2a3a")
      .attr("stroke-width", d => d.anomalous ? 2 : 0.6)
      .attr("opacity", d => S.selected.includes(d.id) ? 1 : 0.12)
      .style("cursor", "pointer")
      .on("mousemove", (e, d) => showTip(e, `<b>${d.name}</b> (${d.vtype})<br>母港：${d.home} · ${d.sea}<br>活动：${d.act}（压力：${d.stress}）${d.anomalous ? "<br><span style='color:#ffb86b'>⚠ 可疑行为</span>" : ""}<br><i>点击聚焦</i>`))
      .on("mouseout", hideTip)
      .on("click", (e, d) => {
        S.focus = (S.focus === d.id ? null : d.id);
        if (S.focus) setAnalyticsOpen(true);
        setStep(S.focus ? "detail" : (S.analyticsOpen ? "focus" : "overview"));
        renderAll();
      });

    pts.transition().duration(500).attr("opacity", d => S.selected.includes(d.id) ? 1 : 0.12);

    function brushed(ev) {
      if (!ev.selection) return;
      const [[x0, y0], [x1, y1]] = ev.selection;
      const hit = VESSELS.filter(d => { const cx = x(d.tsne[0]), cy = y(d.tsne[1]); return cx >= x0 && cx <= x1 && cy >= y0 && cy <= y1 && passFilter(d); });
      if (hit.length) {
        S.selected = hit.map(d => d.id);
        S.focus = null;
        setAnalyticsOpen(true);
        setStep("focus");
        renderAll();
      }
    }
  }

  // ============ D 地图视图（d1聚合航线 + d2聚焦单船）============
  function drawMap() {
    const sel = "#mapView";
    const host = d3.select(sel); host.selectAll("*").remove(); host.classed("map-dashboard", true);
    const sv = selVessels(), fv = focusV();
    const anomalousCount = sv.filter(v => v.anomalous).length;
    const activityCounts = d3.rollups(sv, v => v.length, v => v.act).sort((a, b) => b[1] - a[1]);
    const portDwell = {};
    sv.forEach(v => v.visits.filter(inTimeWindow).forEach(vis => {
      portDwell[vis.port] = (portDwell[vis.port] || 0) + vis.dwell;
    }));
    const topPorts = Object.entries(portDwell).sort((a, b) => b[1] - a[1]).slice(0, 5);

    const addBars = (side, rows, max, colorFn) => {
      const bar = side.selectAll("div.map-bar-row").data(rows).enter().append("div").attr("class", "map-bar-row");
      const head = bar.append("div").attr("class", "map-bar-head");
      head.append("span").text(d => d[0]);
      head.append("b").text(d => d[1]);
      bar.append("div").attr("class", "map-bar-track").append("div").attr("class", "map-bar-fill")
        .style("width", d => `${100 * d[1] / (max || 1)}%`)
        .style("background", colorFn ? d => colorFn(d[0]) : null);
    };

    const left = host.append("div").attr("class", "map-side map-side-left");
    left.append("div").attr("class", "map-side-title").text(fv ? "当前聚焦" : "当前选择");
    const metric = left.append("div").attr("class", "map-metric");
    metric.append("b").text(fv ? fv.name : `${sv.length} 艘`);
    metric.append("span").text(fv ? `${fv.vtype} · ${fv.sea}` : `可疑船只 ${anomalousCount} 艘`);
    left.append("div").attr("class", "map-mini-title").text("活动构成");
    addBars(left, activityCounts, d3.max(activityCounts, d => d[1]), act => {
      const vessel = sv.find(v => v.act === act);
      return vessel ? vessel.color : "#5b9bd5";
    });

    const canvas = host.append("div").attr("class", "map-canvas");
    const right = host.append("div").attr("class", "map-side map-side-right");
    right.append("div").attr("class", "map-side-title").text("高频活动地点");
    if (S.filters.t0 !== 0 || S.filters.t1 !== 11) {
      right.append("div").attr("class", "map-side-note").text(`${MONTHS[S.filters.t0]} ~ ${MONTHS[S.filters.t1]}`);
    }
    addBars(right, topPorts, d3.max(topPorts, d => d[1]));
    if (!topPorts.length) right.append("div").attr("class", "map-side-note").text("当前时间窗口无访问记录");

    const rect = canvas.node().getBoundingClientRect();
    const w = Math.max(190, rect.width), h = Math.max(160, rect.height);
    const { x, y } = projector(w, h);
    const svg = canvas.append("svg").attr("width", w).attr("height", h);

    // 陆地
    D.geo.land.forEach(ring => {
      svg.append("path").attr("d", "M" + ring.map(p => `${x(p[0])},${y(p[1])}`).join("L") + "Z")
        .attr("fill", "#172b36").attr("stroke", "#5f8ea8").attr("stroke-width", 0.9)
        .attr("stroke-opacity", 0.8).attr("pointer-events", "none");
    });
    // 海岸线
    D.geo.coastlines.forEach(ln => {
      svg.append("path").attr("d", "M" + ln.map(p => `${x(p[0])},${y(p[1])}`).join("L"))
        .attr("fill", "none").attr("stroke", "#79aeca").attr("stroke-width", 1.15)
        .attr("stroke-opacity", 0.95).attr("pointer-events", "none");
    });

    // d1：聚合航线（所选船只 OD 累加）
    const agg = {};
    sv.forEach(v => Object.entries(v.od).forEach(([k, c]) => agg[k] = (agg[k] || 0) + c));
    const maxC = d3.max(Object.values(agg)) || 1;
    const lg = svg.append("g");
    Object.entries(agg).forEach(([k, c]) => {
      const [a, b] = k.split("->"); const pa = portByName[a], pb = portByName[b];
      if (!pa || !pb) return;
      lg.append("line").attr("x1", x(pa.lon)).attr("y1", y(pa.lat)).attr("x2", x(pb.lon)).attr("y2", y(pb.lat))
        .attr("stroke", "#5b9bd5").attr("stroke-width", 0.4 + 2.5 * c / maxC).attr("opacity", 0.18 + 0.5 * c / maxC);
    });

    // d2：聚焦单船航线（橙，带方向动画）
    if (fv) {
      const fg = svg.append("g");
      Object.keys(fv.od).forEach(k => {
        const [a, b] = k.split("->"); const pa = portByName[a], pb = portByName[b];
        if (!pa || !pb) return;
        const path = fg.append("line").attr("x1", x(pa.lon)).attr("y1", y(pa.lat)).attr("x2", x(pa.lon)).attr("y2", y(pa.lat))
          .attr("stroke", "#ff7f0e").attr("stroke-width", 2).attr("opacity", 0.9);
        path.transition().duration(600).attr("x2", x(pb.lon)).attr("y2", y(pb.lat));
      });
    }

    // 港口节点
    svg.append("g").selectAll("circle").data(PORTS).enter().append("circle")
      .attr("cx", p => x(p.lon)).attr("cy", p => y(p.lat))
      .attr("r", p => p.ltype === "生态保护区" ? 5 : 3.5)
      .attr("fill", p => LTYPE_COLOR[p.ltype]).attr("stroke", "#0b141c").attr("stroke-width", 0.6)
      .style("cursor", "pointer")
      .on("mousemove", (e, p) => showTip(e, `<b>${p.name}</b><br>${p.ltype} · ${p.sea}<br>(${p.lon}, ${p.lat})`))
      .on("mouseout", hideTip);
  }

  // ============ 时间线视图（聚合停留 + 可选单船聚焦 + 活动压力 + 监测强度）============
  function drawTimeline() {
    const sel = "#timelineView"; d3.select(sel).selectAll("*").remove();
    const { w, h } = dims(sel);
    const m = { l: 92, r: 12, t: 6, b: 18 };
    const svg = d3.select(sel).append("svg").attr("width", w).attr("height", h);
    const x = d3.scaleLinear().domain([0, 12]).range([m.l, w - m.r]);
    const sv = selVessels(), fv = focusV();
    const sub = [
      { id: "e1", label: "群体停留热度", f: drawE1 },
      ...(fv ? [{ id: "e2", label: "单船停留轨迹", f: drawE2 }] : []),
      { id: "e3", label: "活动压力关系", f: drawE3 },
      { id: "e4", label: "监测上报强度", f: drawE4 },
    ];
    const rowH = (h - m.t - m.b) / sub.length;
    // 月份网格 + x 轴
    svg.append("g").selectAll("line.grid").data(d3.range(13)).enter().append("line")
      .attr("x1", d => x(d)).attr("x2", d => x(d)).attr("y1", m.t).attr("y2", h - m.b)
      .attr("stroke", "#1c2c3a").attr("stroke-width", 0.5);
    svg.append("g").selectAll("text.mx").data(d3.range(12)).enter().append("text").attr("class", "mx")
      .attr("x", d => x(d + 0.5)).attr("y", h - 6).attr("text-anchor", "middle").text(d => d + 1);

    sub.forEach((s, i) => {
      const gy = m.t + i * rowH;
      svg.append("text").attr("x", 6).attr("y", gy + rowH / 2).attr("class", "elabel").text(s.label);
      svg.append("line").attr("x1", m.l).attr("x2", w - m.r).attr("y1", gy).attr("y2", gy).attr("stroke", "#243748").attr("stroke-width", 0.5);
      s.f(svg, x, gy, rowH - 4, sv, fv);
    });

    function cellColor(c, max) { return d3.interpolateYlOrRd(0.15 + 0.8 * c / (max || 1)); }
    // e1 聚合月度停留热度条
    function drawE1(svg, x, gy, rh, sv) {
      const mon = Array(12).fill(0); sv.forEach(v => v.monthly.forEach((d, k) => mon[k] += d));
      const max = d3.max(mon) || 1;
      svg.append("g").selectAll("rect").data(mon).enter().append("rect")
        .attr("x", (d, k) => x(k) + 1).attr("y", gy + 4).attr("width", (d, k) => x(k + 1) - x(k) - 2).attr("height", rh - 6)
        .attr("fill", d => cellColor(d, max))
        .on("mousemove", (e, d) => showTip(e, `聚合停留：${d} 船·天`)).on("mouseout", hideTip)
        .attr("opacity", 0).transition().duration(400).delay((d, k) => k * 20).attr("opacity", 1);
    }
    // e2 仅显示当前聚焦单船；未聚焦时整行不创建
    function drawE2(svg, x, gy, rh, sv, fv) {
      const maxF = d3.max(fv.monthly) || 1;
      svg.append("g").selectAll("rect").data(fv.monthly).enter().append("rect")
        .attr("x", (d, k) => x(k) + 1).attr("y", gy + 4).attr("width", (d, k) => x(k + 1) - x(k) - 2).attr("height", rh - 6)
        .attr("fill", d => d3.interpolateBlues(0.2 + 0.8 * d / maxF))
        .on("mousemove", (e, d) => showTip(e, `${fv.name} 停留：${d} 天`)).on("mouseout", hideTip);
    }
    // e3 活动-压力关联（按船只类型分层的月度强度小方块）
    function drawE3(svg, x, gy, rh, sv, fv) {
      const src = fv ? [fv] : sv;
      const stresses = [...new Set(src.map(v => v.stress))];
      const sh = (rh - 4) / Math.max(1, stresses.length);
      stresses.forEach((st, si) => {
        const mon = Array(12).fill(0);
        src.filter(v => v.stress === st).forEach(v => v.monthly.forEach((d, k) => mon[k] += d));
        const max = d3.max(mon) || 1;
        mon.forEach((d, k) => {
          svg.append("rect").attr("x", x(k) + 1).attr("y", gy + 2 + si * sh).attr("width", x(k + 1) - x(k) - 2).attr("height", sh - 1)
            .attr("fill", d3.interpolatePuRd(0.1 + 0.85 * d / max))
            .on("mousemove", (e) => showTip(e, `${st} · ${MONTHS[k]}：强度 ${d}`)).on("mouseout", hideTip);
        });
        svg.append("text").attr("x", m.l + 2).attr("y", gy + 2 + si * sh + sh - 1).attr("class", "stxt").text(st);
      });
    }
    // e4 监测强度（全局交易/上报，折线）
    function drawE4(svg, x, gy, rh) {
      const tr = D.transactions;
      const [minC, maxC] = d3.extent(tr, d => d.count);
      const span = Math.max(1, maxC - minC);
      const pad = span * 0.12;
      // 使用局部区间放缩而非从 0 起始，突出月份之间的相对波动。
      const y = d3.scaleLinear()
        .domain([minC - pad, maxC + pad])
        .range([gy + rh - 4, gy + 4]);
      const yy = c => y(c);
      const line = d3.line().x((d, k) => x(k + 0.5)).y(d => yy(d.count)).curve(d3.curveMonotoneX);
      const p = svg.append("path").datum(tr).attr("fill", "none").attr("stroke", "#7fd1c1").attr("stroke-width", 2).attr("d", line);
      const len = p.node().getTotalLength();
      p.attr("stroke-dasharray", len).attr("stroke-dashoffset", len).transition().duration(900).attr("stroke-dashoffset", 0);
      svg.append("g").selectAll("circle").data(tr).enter().append("circle")
        .attr("cx", (d, k) => x(k + 0.5)).attr("cy", d => yy(d.count)).attr("r", 2.5).attr("fill", "#7fd1c1")
        .on("mousemove", (e, d) => showTip(e, `${d.month} 监测事件：${d.count}<br><i>纵轴采用局部区间放缩</i>`)).on("mouseout", hideTip);
    }
  }

  // ============ F 统计视图 ============
  // f1 各地点类型平均停留（堆叠柱：左=聚合 右=聚焦）
  function drawF1() {
    const sel = "#f1View"; d3.select(sel).selectAll("*").remove();
    const { w, h } = dims(sel); const m = { t: 8, r: 8, b: 18, l: 24 };
    const svg = d3.select(sel).append("svg").attr("width", w).attr("height", h);
    const ltypes = Object.keys(LTYPE_COLOR);
    const calc = list => {
      const o = Object.fromEntries(ltypes.map(t => [t, 0]));
      const n = list.length || 1;
      list.forEach(v => v.visits.filter(inTimeWindow).forEach(vis => o[vis.ltype] += vis.dwell));
      ltypes.forEach(t => o[t] /= n);
      return o;
    };
    const agg = calc(selVessels()); const fv = focusV(); const foc = fv ? calc([fv]) : null;
    const cols = foc ? ["聚合", "聚焦"] : ["聚合"];
    const data = { "聚合": agg }; if (foc) data["聚焦"] = foc;
    const x = d3.scaleBand().domain(cols).range([m.l, w - m.r]).padding(0.4);
    const maxV = d3.max(cols, c => d3.sum(ltypes, t => data[c][t])) || 1;
    const y = d3.scaleLinear().domain([0, maxV]).range([h - m.b, m.t]);
    cols.forEach(c => {
      let yo = 0;
      ltypes.forEach(t => {
        const val = data[c][t]; if (val <= 0) return;
        svg.append("rect").attr("x", x(c)).attr("width", x.bandwidth())
          .attr("y", y(yo + val)).attr("height", y(yo) - y(yo + val))
          .attr("fill", LTYPE_COLOR[t]).attr("stroke", "#0b141c").attr("stroke-width", 0.5)
          .attr("stroke-dasharray", c === "聚合" ? "3,2" : null)
          .on("mousemove", (e) => showTip(e, `${c} · ${t}<br>平均停留 ${val.toFixed(1)} 天`)).on("mouseout", hideTip);
        yo += val;
      });
      svg.append("text").attr("x", x(c) + x.bandwidth() / 2).attr("y", h - 5)
        .attr("text-anchor", "middle").attr("class", "axhint").text(c);
    });
  }

  // f2/f3 OD 弦图（VADITA 原文：chord diagram 表示 OD 流动）
  function drawChord(sel, vessels, title) {
    d3.select(sel).selectAll("*").remove();
    const { w, h } = dims(sel);
    const size = Math.min(w, h);
    const labelPad = 38;
    const R = Math.max(34, size / 2 - labelPad);
    const ir = Math.max(22, R - 10);
    const svg = d3.select(sel).append("svg").attr("width", w).attr("height", h)
      .append("g").attr("transform", `translate(${w / 2},${h / 2})`);
    if (!vessels.length) { svg.append("text").attr("text-anchor", "middle").attr("class", "hintxt").text("无数据"); return; }
    // 聚合 OD 到“地点类型”级别（端口太多，按 ltype 聚合，弦图更可读，符合 OD 行为占比语义）
    const cats = Object.keys(LTYPE_COLOR);
    const labelName = { "商业港": "商业港", "渔港": "渔港", "生态保护区": "保护区", "锚地": "锚地" };
    const idx = Object.fromEntries(cats.map((c, i) => [c, i]));
    const mat = cats.map(() => cats.map(() => 0));
    vessels.forEach(v => Object.entries(v.od).forEach(([k, c]) => {
      const [a, b] = k.split("->"); const pa = portByName[a], pb = portByName[b];
      if (!pa || !pb) return; mat[idx[pa.ltype]][idx[pb.ltype]] += c;
    }));
    const total = d3.sum(mat.flat());
    if (!total) { svg.append("text").attr("text-anchor", "middle").attr("class", "hintxt").text("无OD流"); return; }
    const chord = d3.chord().padAngle(0.06).sortSubgroups(d3.descending)(mat);
    const arc = d3.arc().innerRadius(ir).outerRadius(R);
    const ribbon = d3.ribbon().radius(ir);
    // 弧（地点类型）
    svg.append("g").selectAll("path").data(chord.groups).enter().append("path")
      .attr("d", arc).attr("fill", d => LTYPE_COLOR[cats[d.index]]).attr("stroke", "#0b141c")
      .on("mousemove", (e, d) => showTip(e, `${cats[d.index]}<br>OD流量 ${d.value}`)).on("mouseout", hideTip);
    // 飘带（OD 流）
    svg.append("g").attr("fill-opacity", 0.66).selectAll("path").data(chord).enter().append("path")
      .attr("d", ribbon).attr("fill", d => LTYPE_COLOR[cats[d.source.index]]).attr("stroke", "#0b141c").attr("stroke-width", 0.3)
      .on("mousemove", (e, d) => showTip(e, `${cats[d.source.index]} → ${cats[d.target.index]}<br>流量 ${d.source.value}`)).on("mouseout", hideTip)
      .attr("opacity", 0).transition().duration(500).attr("opacity", 1);
    // 标签
    svg.append("g").selectAll("text").data(chord.groups).enter().append("text").each(d => { d.ang = (d.startAngle + d.endAngle) / 2; })
      .attr("class", "chordlb")
      .attr("transform", d => `rotate(${d.ang * 180 / Math.PI - 90}) translate(${R + 8}) ${d.ang > Math.PI ? "rotate(180)" : ""}`)
      .attr("text-anchor", d => d.ang > Math.PI ? "end" : "start")
      .text(d => labelName[cats[d.index]] || cats[d.index]);
  }

  // ============ ③ 细节阶段：聚焦单船行为明细 ============
  function routeCountsFromVisits(visits) {
    const od = {};
    const sorted = visits.slice().sort((a, b) => a.day - b.day);
    for (let i = 0; i < sorted.length - 1; i++) {
      const a = sorted[i], b = sorted[i + 1];
      if (a.port === b.port) continue;
      const k = `${a.port}->${b.port}`;
      od[k] = (od[k] || 0) + 1;
    }
    return od;
  }

  function appendMetric(host, value, label) {
    const box = host.append("div").attr("class", "detail-metric");
    box.append("b").text(value);
    box.append("span").text(label);
  }

  function appendTag(host, text, hot = false) {
    host.append("span").attr("class", hot ? "detail-tag hot" : "detail-tag").text(text);
  }

  function renderDetailDrawer() {
    const drawer = d3.select("#detailDrawer");
    if (drawer.empty()) return;
    const fv = focusV();
    const open = S.step === "detail" && !!fv;
    d3.select("#detailMask").classed("show", open);
    drawer.classed("show", open).attr("aria-hidden", open ? "false" : "true");
    d3.selectAll(".wf-step").classed("disabled", function () { return this.dataset.step === "detail" && !fv; });
    if (open) renderVesselDetail(fv);
  }

  function renderVesselDetail(v) {
    const body = d3.select("#detailBody"); body.selectAll("*").remove();
    d3.select("#detailTitle").text(`${v.name} · ${v.vtype}`);

    const rangeLabel = `${MONTHS[S.filters.t0]} ~ ${MONTHS[S.filters.t1]}`;
    const visits = v.visits.filter(inTimeWindow).sort((a, b) => a.day - b.day);
    const totalDwell = d3.sum(visits, d => d.dwell);
    const protectDwell = d3.sum(visits.filter(d => d.ltype === "生态保护区"), d => d.dwell);
    const uniquePorts = new Set(visits.map(d => d.port)).size;
    const routeCounts = routeCountsFromVisits(visits);
    const routePairs = Object.entries(routeCounts).sort((a, b) => b[1] - a[1]);
    let peakIdx = S.filters.t0, peakVal = -1;
    v.monthly.forEach((d, i) => {
      if (i >= S.filters.t0 && i <= S.filters.t1 && d > peakVal) { peakIdx = i; peakVal = d; }
    });

    const summary = body.append("div").attr("class", "detail-section");
    summary.append("h3").text(`当前时间窗口：${rangeLabel}`);
    const grid = summary.append("div").attr("class", "detail-summary");
    appendMetric(grid, `${visits.length}`, "访问记录数");
    appendMetric(grid, `${uniquePorts}`, "涉及地点数");
    appendMetric(grid, `${totalDwell} 天`, "累计停留");
    appendMetric(grid, `${protectDwell} 天`, "生态保护区停留");

    const basic = body.append("div").attr("class", "detail-section");
    basic.append("h3").text("基本信息");
    const tags = basic.append("div").attr("class", "detail-tags");
    appendTag(tags, `编号 ${v.id}`);
    appendTag(tags, `母港 ${v.home}`);
    appendTag(tags, `海区 ${v.sea}`);
    appendTag(tags, `主导活动 ${v.act}`);
    appendTag(tags, `环境压力 ${v.stress}`);
    appendTag(tags, `峰值月份 ${MONTHS[peakIdx]} (${peakVal} 天)`);
    appendTag(tags, v.anomalous ? "可疑船只" : "未标记可疑", v.anomalous);

    const reason = body.append("div").attr("class", "detail-section");
    reason.append("h3").text("可疑行为解释");
    const reasonTags = reason.append("div").attr("class", "detail-tags");
    if (v.anomalous) {
      appendTag(reasonTags, "系统已标记为可疑", true);
      if (protectDwell > 0) appendTag(reasonTags, `当前窗口在生态保护区停留 ${protectDwell} 天`, true);
      else {
        const allProtect = d3.sum(v.visits.filter(d => d.ltype === "生态保护区"), d => d.dwell);
        appendTag(reasonTags, `全年生态保护区停留 ${allProtect} 天`, allProtect > 0);
      }
      appendTag(reasonTags, `关联压力：${v.stress}`);
    } else {
      appendTag(reasonTags, "当前船只未被异常规则标记");
      if (protectDwell > 0) appendTag(reasonTags, `当前窗口仍有生态保护区停留 ${protectDwell} 天`);
    }

    const byType = Object.fromEntries(Object.keys(LTYPE_COLOR).map(t => [t, 0]));
    visits.forEach(vis => byType[vis.ltype] += vis.dwell);
    const loc = body.append("div").attr("class", "detail-section");
    loc.append("h3").text("地点类型停留构成");
    const locTags = loc.append("div").attr("class", "detail-tags");
    Object.entries(byType).forEach(([type, days]) => {
      if (!days) return;
      const pct = totalDwell ? Math.round(days * 100 / totalDwell) : 0;
      const tag = locTags.append("span").attr("class", "detail-tag");
      tag.append("i").attr("class", "detail-swatch").style("background", LTYPE_COLOR[type]);
      tag.append("span").text(`${type} ${days} 天 (${pct}%)`);
    });
    if (!totalDwell) loc.append("div").attr("class", "detail-empty").text("当前时间窗口内没有访问记录。");

    const routeSec = body.append("div").attr("class", "detail-section");
    routeSec.append("h3").text("主要移动路径");
    if (!routePairs.length) {
      routeSec.append("div").attr("class", "detail-empty").text("当前时间窗口内没有可计算的 OD 路径。");
    } else {
      const table = routeSec.append("table").attr("class", "detail-table");
      table.append("thead").append("tr").selectAll("th").data(["路径", "次数", "地点类型"]).enter().append("th").text(d => d);
      const rows = table.append("tbody").selectAll("tr").data(routePairs.slice(0, 8)).enter().append("tr");
      rows.append("td").text(d => d[0].replace("->", " → "));
      rows.append("td").text(d => d[1]);
      rows.append("td").text(d => {
        const [a, b] = d[0].split("->");
        const pa = portByName[a], pb = portByName[b];
        return pa && pb ? `${pa.ltype} → ${pb.ltype}` : "未知";
      });
    }

    const visitSec = body.append("div").attr("class", "detail-section");
    visitSec.append("h3").text("访问记录明细");
    if (!visits.length) {
      visitSec.append("div").attr("class", "detail-empty").text("当前时间窗口内没有访问记录。");
    } else {
      const table = visitSec.append("table").attr("class", "detail-table");
      table.append("thead").append("tr").selectAll("th").data(["日期", "月份", "地点", "类型", "停留"]).enter().append("th").text(d => d);
      const rows = table.append("tbody").selectAll("tr").data(visits.slice(0, 30)).enter().append("tr");
      rows.append("td").text(d => `第 ${d.day} 天`);
      rows.append("td").text(d => MONTHS[monthOfDay(d.day)]);
      rows.append("td").text(d => d.port);
      rows.append("td").each(function (d) {
        const td = d3.select(this);
        td.append("i").attr("class", "detail-swatch").style("background", LTYPE_COLOR[d.ltype]);
        td.append("span").text(d.ltype);
      });
      rows.append("td").text(d => `${d.dwell} 天`);
      if (visits.length > 30) visitSec.append("div").attr("class", "detail-empty").text(`仅显示前 30 条，共 ${visits.length} 条。`);
    }
  }

  // ============ 渲染总控 ============
  function renderAll() {
    setAnalyticsOpen(S.analyticsOpen);
    drawCluster(); drawMap();
    const fv = focusV();
    if (S.analyticsOpen) {
      drawTimeline(); drawF1();
      drawChord("#f2View", selVessels(), "f2");
      drawChord("#f3View", fv ? [fv] : [], "f3");
    }
    d3.select("#clusterHint").text(
      S.focus ? `聚焦：${fv.name}（再点取消）`
        : S.analyticsOpen ? `已框选 ${S.selected.length} 艘 · 可继续框选或点击单船`
          : "框选相似船只群体展开时间线与统计 · 点击单船查看个体轨迹"
    );
    renderDetailDrawer();
  }

  function init() {
    buildFilters(); buildLegend(); buildWorkflow(); renderAll();
    window.addEventListener("resize", () => renderAll());
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
