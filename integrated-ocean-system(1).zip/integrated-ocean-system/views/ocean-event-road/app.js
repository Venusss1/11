(() => {
  "use strict";

  const records = (window.LAB3_DATA && window.LAB3_DATA.records) || [];
  const geo = window.CHI_DATA || {};

  const regionNames = {
    R1: "渤海",
    R2: "黄海北部",
    R3: "黄海南部",
    R4: "东海北部",
    R5: "东海南部",
    R6: "南海北部"
  };

  const regionShort = {
    R1: "渤海", R2: "黄北", R3: "黄南", R4: "东北", R5: "东南", R6: "南海"
  };

  const typeDefs = [
    { id: "cold", name: "冷水团", en: "Cold pool", color: "#55a7ff", metric: "温度距平", weight: .85 },
    { id: "warm", name: "暖水入侵", en: "Warm intrusion", color: "#ff9850", metric: "温度距平", weight: 1.20 },
    { id: "fresh", name: "沿岸低盐水", en: "Coastal plume", color: "#55d7d0", metric: "盐度", weight: .95 },
    { id: "productive", name: "高生产力水团", en: "Productive water", color: "#f1c75b", metric: "叶绿素", weight: .75 }
  ];
  const typeMap = Object.fromEntries(typeDefs.map(d => [d.id, d]));
  const allMonths = d3.timeMonth.range(new Date(2023, 0, 1), new Date(2026, 0, 1))
    .map(d3.timeFormat("%Y-%m"));

  const state = {
    view: "timeline",
    year: "all",
    depth: "all",
    activeTypes: new Set(typeDefs.map(d => d.id)),
    selectedEventId: null,
    selectedRegionId: null,
    selectedMonth: null,
    playing: false,
    timer: null
  };

  const els = {
    mainSvg: d3.select("#main-svg"),
    overviewSvg: d3.select("#overview-svg"),
    visualStage: document.querySelector("#visual-stage"),
    eventList: document.querySelector("#event-list"),
    typeFilters: document.querySelector("#type-filters"),
    eventCard: document.querySelector("#event-card"),
    tooltip: document.querySelector("#tooltip"),
    empty: document.querySelector("#empty-state"),
    year: document.querySelector("#year-select"),
    depth: document.querySelector("#depth-select"),
    play: document.querySelector("#play-btn")
  };

  let derivedEvents = [];
  let visibleEvents = [];
  let renderFrame = null;
  let chinaCoast = window.CHINA_COASTLINE_DATA || null;
  let chinaFull = window.CHINA_FULL_MAP || null;

  const mean = (arr, key) => d3.mean(arr, d => +d[key]) || 0;
  const clamp = v => Math.max(0, Math.min(1, Number.isFinite(v) ? v : 0));
  const fmt1 = d3.format(".1f");
  const monthDate = value => d3.timeParse("%Y-%m")(value);
  const monthCn = value => value ? `${value.slice(0, 4)}年${+value.slice(5)}月` : "全部月份";
  const quantile = (values, q) => d3.quantile(values.filter(Number.isFinite).sort(d3.ascending), q) || 0;

  function scoreBetween(value, start, end, inverse = false) {
    const span = Math.abs(end - start) || 1;
    return inverse ? clamp((start - value) / span) : clamp((value - start) / span);
  }

  function getFilteredRecords(ignoreYear = false) {
    return records.filter(d => {
      const depthOK = state.depth === "all" || d.depth_group === state.depth;
      const yearOK = ignoreYear || state.year === "all" || String(d.year) === state.year;
      return depthOK && yearOK;
    });
  }

  function buildEvents(source) {
    if (!source.length) return [];

    const depthBase = getFilteredRecords(true);
    const climatology = new Map(
      d3.rollups(depthBase, v => mean(v, "phy_thetao"), d => `${d.region_id}|${d.month}`)
    );
    const summaries = d3.groups(source, d => `${d.region_id}|${d.month_label}`).map(([key, values]) => {
      const [regionId, month] = key.split("|");
      const temperature = mean(values, "phy_thetao");
      return {
        regionId,
        region: regionNames[regionId] || values[0].region_name,
        month,
        date: monthDate(month),
        rows: values,
        count: values.length,
        lon: d3.mean(values, d => +d.longitude),
        lat: d3.mean(values, d => +d.latitude),
        o2: mean(values, "bgc_o2"),
        ph: mean(values, "bgc_ph"),
        chl: mean(values, "bgc_chl"),
        salinity: mean(values, "phy_so"),
        temp: temperature,
        tempAnom: temperature - (climatology.get(`${regionId}|${values[0].month}`) || temperature),
        current: mean(values, "current_speed")
      };
    });

    const chl = summaries.map(d => d.chl);
    const salinity = summaries.map(d => d.salinity);
    const temp = summaries.map(d => d.tempAnom);
    const thresholds = {
      coldStart: quantile(temp, .38), coldEnd: quantile(temp, .01),
      warmStart: quantile(temp, .62), warmEnd: quantile(temp, .99),
      freshStart: quantile(salinity, .38), freshEnd: quantile(salinity, .01),
      chlStart: quantile(chl, .62), chlEnd: quantile(chl, .99),
    };

    const events = [];
    summaries.forEach(s => {
      const candidates = [
        { type: "cold", score: scoreBetween(s.tempAnom, thresholds.coldStart, thresholds.coldEnd, true), value: s.tempAnom, unit: "°C" },
        { type: "warm", score: scoreBetween(s.tempAnom, thresholds.warmStart, thresholds.warmEnd), value: s.tempAnom, unit: "°C" },
        { type: "fresh", score: scoreBetween(s.salinity, thresholds.freshStart, thresholds.freshEnd, true), value: s.salinity, unit: "PSU" },
        { type: "productive", score: scoreBetween(s.chl, thresholds.chlStart, thresholds.chlEnd), value: s.chl, unit: "mg/m³" }
      ];

      candidates.forEach(c => {
        if (c.score < .28) return;
        events.push({
          id: `${c.type}-${s.regionId}-${s.month}`,
          ...s,
          type: c.type,
          value: c.value,
          unit: c.unit,
          score: c.score,
          strength: Math.round(35 + c.score * 65)
        });
      });
    });

    return events.sort((a, b) => d3.ascending(a.date, b.date) || d3.descending(a.strength, b.strength));
  }

  function updateDerived() {
    derivedEvents = buildEvents(getFilteredRecords());
    if (state.selectedEventId && !derivedEvents.some(d => d.id === state.selectedEventId)) {
      state.selectedEventId = null;
    }
  }

  function getVisibleEvents() {
    return derivedEvents.filter(d =>
      state.activeTypes.has(d.type) &&
      (!state.selectedMonth || d.month === state.selectedMonth)
    );
  }

  function selectedEvent() {
    return derivedEvents.find(d => d.id === state.selectedEventId) || null;
  }

  function typeCounts() {
    return new Map(d3.rollups(derivedEvents, v => v.length, d => d.type));
  }

  function renderTypeFilters() {
    const counts = typeCounts();
    els.typeFilters.innerHTML = "";
    typeDefs.forEach(def => {
      const button = document.createElement("button");
      button.className = `type-filter${state.activeTypes.has(def.id) ? " active" : ""}`;
      button.style.setProperty("--type-color", def.color);
      button.innerHTML = `<i></i><b>${def.name}</b><small>${def.en} · W${def.weight.toFixed(2)}</small><em>${counts.get(def.id) || 0}</em>`;
      button.addEventListener("click", () => {
        if (state.activeTypes.has(def.id) && state.activeTypes.size > 1) state.activeTypes.delete(def.id);
        else state.activeTypes.add(def.id);
        state.selectedEventId = null;
        render();
      });
      els.typeFilters.append(button);
    });
    document.querySelector("#event-total").textContent = `${derivedEvents.length} EVENTS`;
  }

  function renderEventList() {
    const note = document.querySelector("#event-list-note");
    const list = state.selectedRegionId
      ? derivedEvents
        .filter(d => d.regionId === state.selectedRegionId && state.activeTypes.has(d.type))
        .sort((a, b) => d3.ascending(a.date, b.date) || d3.descending(a.strength, b.strength))
      : visibleEvents.slice().sort((a, b) => d3.descending(a.strength, b.strength)).slice(0, 14);
    const current = selectedEvent();
    note.textContent = state.selectedRegionId
      ? `${state.year === "all" ? "2023–2025" : state.year}年${regionNames[state.selectedRegionId]}事件 · ${list.length}个`
      : state.selectedMonth ? `${monthCn(state.selectedMonth)}重点事件` : "全海域重点事件";
    els.eventList.innerHTML = "";
    list.forEach(event => {
      const def = typeMap[event.type];
      const button = document.createElement("button");
      button.className = `event-item${current && current.id === event.id ? " active" : ""}`;
      button.style.setProperty("--event-color", def.color);
      button.innerHTML = `
        <i></i>
        <div><b>${event.region} · ${def.name}</b><span>${event.month} · ${formatEventValue(event)}</span></div>
        <strong>${event.strength}<small>/100</small></strong>`;
      button.addEventListener("click", () => selectEvent(event, true));
      els.eventList.append(button);
    });
    if (!list.length) els.eventList.innerHTML = `<div style="padding:24px 8px;color:var(--faint);font-size:9px">该海域当前没有符合条件的事件</div>`;
  }

  function formatEventValue(event) {
    if (event.type === "cold" || event.type === "warm") return `${event.value >= 0 ? "+" : ""}${event.value.toFixed(2)} °C`;
    if (event.type === "fresh") return `${event.value.toFixed(2)} PSU`;
    return `${event.value.toFixed(1)} ${event.unit}`;
  }

  function renderEventCard() {
    const event = selectedEvent();
    if (!event) {
      els.eventCard.style.display = "none";
      return;
    }
    const def = typeMap[event.type];
    const regionEvents = derivedEvents
      .filter(d => d.regionId === event.regionId && state.activeTypes.has(d.type))
      .sort((a, b) => d3.descending(a.strength, b.strength));
    const rank = regionEvents.findIndex(d => d.id === event.id) + 1;
    const contribution = def.weight * (.4 + .6 * event.strength / 100);
    const sameMonthType = derivedEvents.filter(d => d.month === event.month && d.type === event.type);
    const eventMonthIndex = allMonths.indexOf(event.month);
    const nearbySameType = derivedEvents.filter(d =>
      d.regionId === event.regionId &&
      d.type === event.type &&
      Math.abs(allMonths.indexOf(d.month) - eventMonthIndex) <= 2
    );
    const regionalTypeCount = regionEvents.filter(d => d.type === event.type).length;
    const peerRegions = sameMonthType.map(d => d.region).filter((name, index, arr) => arr.indexOf(name) === index);
    const profileRows = [
      ["海温", `${event.temp.toFixed(2)} °C`, clamp((event.temp + 2) / 32) * 100, "#ff9850"],
      ["盐度", `${event.salinity.toFixed(2)} PSU`, clamp((event.salinity - 25) / 12) * 100, "#55d7d0"],
      ["溶解氧", `${event.o2.toFixed(1)} mmol/m³`, clamp((event.o2 - 150) / 220) * 100, "#55a7ff"],
      ["叶绿素", `${event.chl.toFixed(2)} mg/m³`, clamp(event.chl / 2) * 100, "#f1c75b"]
    ];
    els.eventCard.style.display = "";
    els.eventCard.style.setProperty("--event-color", def.color);
    els.eventCard.innerHTML = `
      <div class="card-kicker"><span>SELECTED EVENT</span><span>${event.strength}/100</span></div>
      <h3>${event.region} · ${def.name}</h3>
      <div class="card-subtitle">${monthCn(event.month)} · ${state.depth === "all" ? "全部水层" : state.depth} · ${event.count} 条样本</div>
      <div class="card-grid">
        <div><span>${def.metric}</span><b>${formatEventValue(event)}</b></div>
        <div><span>事件权重</span><b>W ${def.weight.toFixed(2)}</b></div>
        <div><span>溶解氧</span><b>${event.o2.toFixed(1)} mmol/m³</b></div>
        <div><span>pH</span><b>${event.ph.toFixed(3)}</b></div>
        <div><span>${event.type === "productive" ? "海温" : "叶绿素"}</span><b>${event.type === "productive" ? `${event.temp.toFixed(2)} °C` : `${event.chl.toFixed(2)} mg/m³`}</b></div>
        <div><span>平均流速</span><b>${event.current.toFixed(3)} m/s</b></div>
      </div>
      <div class="detail-strip">
        <div><span>海域内强度排名</span><b>${rank || "—"} / ${regionEvents.length}</b></div>
        <div><span>WESI 单次贡献</span><b>${contribution.toFixed(2)}</b></div>
        <div><span>盐度</span><b>${event.salinity.toFixed(2)} PSU</b></div>
      </div>
      <section class="context-section">
        <h4>时空关联</h4>
        <div class="context-grid">
          <div><span>同月同类海域</span><b>${peerRegions.length} 个</b><small>${peerRegions.join("、") || "仅本海域"}</small></div>
          <div><span>前后两月连续事件</span><b>${nearbySameType.length} 次</b><small>用于判断事件持续性</small></div>
          <div><span>本海域同类事件</span><b>${regionalTypeCount} 次</b><small>2023–2025 年累计</small></div>
          <div><span>观测中心</span><b>${event.lon.toFixed(1)}°E</b><small>${event.lat.toFixed(1)}°N · ${event.count}条样本</small></div>
        </div>
      </section>
      <section class="profile-section">
        <h4>环境指标画像</h4>
        ${profileRows.map(row => `
          <div class="profile-row">
            <span>${row[0]}</span>
            <i><em style="width:${row[2].toFixed(1)}%;background:${row[3]}"></em></i>
            <b>${row[1]}</b>
          </div>`).join("")}
      </section>
      <section class="detail-copy">
        <h4>事件解释</h4>
        <p>${eventNarrative(event)}</p>
        <h4>判读建议</h4>
        <p>${eventAdvice(event)}</p>
      </section>`;
  }

  function eventNarrative(event) {
    const phrases = {
      cold: `该月温度距平为 ${event.value.toFixed(2)} °C，低于该海域同月份季节基准。该事件反映冷水团信号，不等同于单个站点的瞬时低温。`,
      warm: `该月温度距平达到 +${Math.abs(event.value).toFixed(2)} °C，暖水信号高于该海域季节基准。较高流速可能增强暖水输运与空间扩展。`,
      fresh: `该月平均盐度为 ${event.salinity.toFixed(2)} PSU，处于该海域同期低值区间，表现为沿岸低盐水扩展或淡水输入增强。`,
      productive: `该月叶绿素达到 ${event.chl.toFixed(2)} mg/m³，表明水体生产力较高。溶解氧和 pH 在此作为环境背景共同解释。`
    };
    return phrases[event.type];
  }

  function eventAdvice(event) {
    const advice = {
      cold: "结合前后月份的时间线判断冷水团是短时出现还是持续维持，并比较中、深水层是否同步响应。",
      warm: "建议对比相邻海域同月事件和流速指标；若多个海域连续出现，可视为暖水沿岸迁移的候选过程。",
      fresh: "可结合流速、叶绿素与相邻月份判断低盐水边界是否外扩，以及是否伴随高生产力水体。",
      productive: "重点比较叶绿素、流速和温盐条件的同步变化，判断高生产力事件是局地形成还是随水团输运。"
    };
    return advice[event.type];
  }

  function updateHeaderStats() {
    const regionCount = new Set(visibleEvents.map(d => d.regionId)).size;
    const peak = d3.rollups(visibleEvents, v => d3.sum(v, d => d.strength), d => d.month)
      .sort((a, b) => d3.descending(a[1], b[1]))[0];
    document.querySelector("#stat-events").textContent = visibleEvents.length;
    document.querySelector("#stat-regions").textContent = regionCount;
    document.querySelector("#stat-month").textContent = peak ? peak[0].slice(2).replace("-", "/") : "—";
    document.querySelector("#current-month").textContent = state.selectedMonth ? state.selectedMonth.replace("-", "/") : "全部月份";
  }

  function renderMain() {
    els.mainSvg.selectAll("*").remove();
    const bounds = els.visualStage.getBoundingClientRect();
    const width = Math.max(600, bounds.width);
    const height = Math.max(360, bounds.height);
    els.mainSvg.attr("viewBox", `0 0 ${width} ${height}`);
    els.empty.hidden = visibleEvents.length > 0;
    if (!visibleEvents.length) return;

    const root = els.mainSvg.append("g");
    const mapWidth = Math.round(width * .64);
    renderGeoGlyphMap(root.append("g"), mapWidth, height);
    root.append("line")
      .attr("x1", mapWidth).attr("x2", mapWidth).attr("y1", 10).attr("y2", height - 10)
      .attr("stroke", "rgba(139,207,225,.24)");
    const side = root.append("g").attr("transform", `translate(${mapWidth},0)`);
    if (selectedEvent()) {
      side.append("rect").attr("x", 8).attr("y", 8).attr("width", width - mapWidth - 16).attr("height", height - 16)
        .attr("fill", "rgba(5,22,34,.72)").attr("stroke", "rgba(139,207,225,.18)");
    } else if (state.selectedMonth) {
      renderSideMonthAnalysis(side, width - mapWidth, height);
    } else {
      const sideHeight = height;
      const timelineHeight = Math.round(sideHeight * .57);
      renderSideTimeline(side.append("g"), width - mapWidth, timelineHeight);
      renderSideGraph(side.append("g").attr("transform", `translate(0,${timelineHeight})`), width - mapWidth, sideHeight - timelineHeight);
    }
  }

  function renderGeoGlyphMap(root, width, height) {
    const chinaFeatures = (chinaCoast?.land || []).filter(feature => feature?.geometry);
    const fallbackFeatures = (chinaFull?.features || []).filter(feature => {
      const center = feature.properties?.center;
      return feature.properties?.name && (!center || center[0] >= 104);
    });
    const baseMap = {
      type: "FeatureCollection",
      features: chinaFeatures.length ? chinaFeatures : fallbackFeatures
    };
    if (!baseMap.features.length) {
      root.append("text").attr("x", 30).attr("y", 50).attr("class", "svg-label").text("中国地图数据未载入");
      return;
    }

    const projection = d3.geoIdentity().reflectY(true)
      .fitExtent([[20, 26], [width - 22, height - 28]], baseMap);
    const path = d3.geoPath(projection);
    const severity = regionSeverityData();
    const severityColor = d3.scaleLinear()
      .domain([25, 50, 75, 100])
      .range(["#1d6b8a", "#3bb9b0", "#efbd58", "#ff604e"])
      .clamp(true);

    root.append("rect").attr("x", 8).attr("y", 8).attr("width", width - 16).attr("height", height - 16)
      .attr("fill", "rgba(7,27,41,.48)").attr("stroke", "rgba(139,207,225,.12)");
    root.append("g").attr("class", "china-full-map").selectAll("path")
      .data(baseMap.features).join("path")
      .attr("d", path).attr("fill", "rgba(45,67,73,.88)")
      .attr("stroke", "rgba(168,210,207,.38)").attr("stroke-width", .58);
    if (chinaCoast?.coastlines?.length) {
      root.append("g").attr("class", "coast-detail").selectAll("path")
        .data(chinaCoast.coastlines).join("path")
        .attr("d", path).attr("fill", "none")
        .attr("stroke", "rgba(157,220,222,.72)").attr("stroke-width", .8);
    }

    const regionCenters = new Map((geo.regions || []).map(d => [d.region_id, projection(d.center)]));
    const glyphLayout = {
      R1: [.73, .18], R2: [.84, .30], R3: [.76, .42],
      R4: [.85, .55], R5: [.77, .68], R6: [.67, .83]
    };
    const maxTypeCount = d3.max(severity, d => d3.max(typeDefs, t => d.typeCounts.get(t.id) || 0)) || 1;
    const sectorArc = d3.arc().cornerRadius(1.8).padAngle(.035);
    const bandCount = 5;
    const hasRegionFocus = Boolean(state.selectedRegionId);

    const glyphs = root.append("g").selectAll(".water-glyph").data(severity).join("g")
      .attr("class", d => `water-glyph${hasRegionFocus ? (d.regionId === state.selectedRegionId ? " focused" : " dimmed") : ""}`)
      .attr("opacity", d => hasRegionFocus ? (d.regionId === state.selectedRegionId ? 1 : .17) : 0)
      .attr("transform", d => {
        const p = regionCenters.get(d.regionId) || [0, 0];
        const layout = glyphLayout[d.regionId] || [.8, .5];
        d._anchor = p;
        d._display = [width * layout[0], height * layout[1]];
        const scale = hasRegionFocus ? (d.regionId === state.selectedRegionId ? .78 : .94) : .18;
        return `translate(${d._display[0]},${d._display[1]}) scale(${scale})`;
      })
      .style("cursor", "pointer")
      .on("click", (_, d) => selectRegion(d.regionId))
      .on("mousemove", (event, d) => {
        const lines = typeDefs.map(t => `${t.name} ${d.typeCounts.get(t.id) || 0} 次`).join("<br>");
        const period = state.selectedMonth ? monthCn(state.selectedMonth) : (state.year === "all" ? "2023–2025年" : `${state.year}年`);
        showTooltip(event, `<b>${d.region}</b><br>${period}事件 ${d.count} 次<br>${lines}<br>相对频率 ${d.relativeFrequency}/100<br>综合严重性 ${d.score}/100`);
      })
      .on("mouseleave", hideTooltip);

    if (hasRegionFocus) {
      glyphs.filter(d => d.regionId === state.selectedRegionId)
        .transition().duration(520).ease(d3.easeBackOut)
        .attr("opacity", 1)
        .attr("transform", d => `translate(${d._display[0]},${d._display[1]}) scale(1.08)`);
    } else {
      glyphs.transition().delay((_, i) => i * 130).duration(760).ease(d3.easeBackOut)
        .attr("opacity", 1)
        .attr("transform", d => `translate(${d._display[0]},${d._display[1]}) scale(1)`);
    }

    root.append("g").attr("class", "glyph-leaders").selectAll("line").data(severity).join("line")
      .attr("x1", d => d._anchor[0]).attr("y1", d => d._anchor[1])
      .attr("x2", d => d._display[0]).attr("y2", d => d._display[1])
      .attr("stroke", "rgba(171,223,225,.35)").attr("stroke-dasharray", "2 3")
      .attr("opacity", d => hasRegionFocus ? (d.regionId === state.selectedRegionId ? .78 : .08) : 1);

    const pulsingGlyph = glyphs.filter(d => hasRegionFocus && d.regionId === state.selectedRegionId);
    pulsingGlyph.append("circle").attr("class", "diffusion-ring ring-a").attr("r", 39).attr("fill", "none")
      .attr("stroke", d => severityColor(d.colorScore)).attr("stroke-width", 1.2);
    pulsingGlyph.append("circle").attr("class", "diffusion-ring ring-b").attr("r", 39).attr("fill", "none")
      .attr("stroke", d => severityColor(d.colorScore)).attr("stroke-width", 1);

    glyphs.each(function(d) {
      const container = d3.select(this);
      const sectors = typeDefs.map((type, index) => {
        const count = d.typeCounts.get(type.id) || 0;
        return {
          type, index, count,
          level: Math.max(0, Math.min(bandCount, Math.ceil(count / maxTypeCount * bandCount)))
        };
      });
      container.selectAll(".sector-base").data(sectors).join("path")
        .attr("class", "sector-base")
        .attr("d", item => sectorArc({
          innerRadius: 11, outerRadius: 33,
          startAngle: item.index * Math.PI / 2 - Math.PI / 4,
          endAngle: item.index * Math.PI / 2 + Math.PI / 4
        }))
        .attr("fill", item => item.type.color).attr("fill-opacity", .09)
        .attr("stroke", item => item.type.color).attr("stroke-opacity", .4).attr("stroke-width", .7);

      const bands = sectors.flatMap(item => d3.range(bandCount).map(band => ({ ...item, band })));
      const activeBands = container.selectAll(".frequency-band").data(bands).join("path")
        .attr("class", "frequency-band")
        .attr("d", item => sectorArc({
          innerRadius: 12 + item.band * 4.1,
          outerRadius: 15.2 + item.band * 4.1,
          startAngle: item.index * Math.PI / 2 - Math.PI / 4 + .025,
          endAngle: item.index * Math.PI / 2 + Math.PI / 4 - .025
        }))
        .attr("fill", item => item.type.color)
        .attr("opacity", 0);
      if (hasRegionFocus) {
        activeBands.attr("opacity", item => item.band < item.level ? .92 : .08);
      } else {
        activeBands.transition().delay(item => 420 + item.index * 90 + item.band * 55).duration(380)
          .attr("opacity", item => item.band < item.level ? .92 : .08);
      }

      container.selectAll(".glyph-count").data(sectors).join("text")
        .attr("class", "glyph-count")
        .attr("x", item => Math.sin(item.index * Math.PI / 2) * 23)
        .attr("y", item => -Math.cos(item.index * Math.PI / 2) * 23 + 2.5)
        .attr("text-anchor", "middle").attr("fill", "#f4ffff")
        .attr("font-size", 6.5).attr("font-weight", 800).text(item => item.count);
    });

    glyphs.append("circle").attr("class", "region-halo").attr("r", 37).attr("fill", "none")
      .attr("stroke", d => severityColor(d.colorScore))
      .attr("stroke-width", 3.4)
      .attr("stroke-opacity", .92)
      .attr("filter", d => d.regionId === state.selectedRegionId ? "drop-shadow(0 0 7px rgba(85,215,255,.95))" : null);
    glyphs.filter(d => d.regionId === state.selectedRegionId).append("circle")
      .attr("r", 43).attr("fill", "none").attr("stroke", "#eaffff")
      .attr("stroke-width", 1.4).attr("stroke-dasharray", "4 3");
    glyphs.append("circle").attr("r", 10).attr("fill", "#071722").attr("stroke", "rgba(255,255,255,.65)");
    glyphs.append("text").attr("text-anchor", "middle").attr("y", 2.6)
      .attr("class", "glyph-center-value")
      .attr("fill", "#eaffff").attr("font-size", 8.5).attr("font-weight", 800)
      .text(d => state.selectedMonth ? d.count : d.relativeFrequency);
    glyphs.append("text").attr("x", 44).attr("y", -2).attr("class", "svg-title").text(d => d.region);
    glyphs.append("text").attr("x", 44).attr("y", 11).attr("class", "svg-small").text(d => `${d.count}次 · WESI ${d.score}`);

    const legend = root.append("g").attr("transform", `translate(18,${height - 72})`);
    legend.append("rect").attr("width", 238).attr("height", 52).attr("fill", "rgba(4,19,30,.72)").attr("stroke", "rgba(139,207,225,.16)");
    typeDefs.forEach((type, index) => {
      const x = 12 + (index % 2) * 112;
      const y = 17 + Math.floor(index / 2) * 19;
      legend.append("circle").attr("cx", x).attr("cy", y - 3).attr("r", 4).attr("fill", type.color);
      legend.append("text").attr("x", x + 9).attr("y", y).attr("class", "svg-small").text(`${type.name} · W${type.weight.toFixed(2)}`);
    });
    root.append("text").attr("x", 18).attr("y", 24).attr("class", "svg-small")
      .text("中国近海海岸线 · 等面积四象限分段环 · 亮起环带数量表示事件频率");
  }

  function renderSideTimeline(root, width, height) {
    root.append("rect").attr("x", 8).attr("y", 8).attr("width", width - 16).attr("height", height - 16)
      .attr("fill", "rgba(5,22,34,.68)").attr("stroke", "rgba(139,207,225,.14)");
    root.append("text").attr("x", 18).attr("y", 27).attr("class", "svg-title").text("事件时间线");
    root.append("text").attr("x", width - 16).attr("y", 27).attr("text-anchor", "end").attr("class", "svg-small")
      .text(state.selectedRegionId ? regionNames[state.selectedRegionId] : "全部海域");

    const events = visibleEvents.filter(d => !state.selectedRegionId || d.regionId === state.selectedRegionId);
    const margin = { top: 43, right: 12, bottom: 30, left: 58 };
    const x = d3.scaleBand().domain(allMonths).range([margin.left, width - margin.right]).padding(.1);
    const y = d3.scaleBand().domain(typeDefs.map(d => d.id)).range([margin.top, height - margin.bottom]).padding(.28);
    const regionOffset = d3.scalePoint().domain(Object.keys(regionNames)).range([-y.bandwidth() * .25, y.bandwidth() * .25]);

    root.selectAll(".side-lane").data(typeDefs).join("rect")
      .attr("class", "side-lane").attr("x", margin.left).attr("y", d => y(d.id) - 4)
      .attr("width", width - margin.left - margin.right).attr("height", y.bandwidth() + 8)
      .attr("fill", (_, i) => i % 2 ? "rgba(255,255,255,.012)" : "rgba(85,215,255,.018)");
    root.selectAll(".side-type-label").data(typeDefs).join("text")
      .attr("class", "side-type-label").attr("x", margin.left - 8).attr("y", d => y(d.id) + y.bandwidth() / 2 + 3)
      .attr("text-anchor", "end").attr("fill", d => d.color).attr("font-size", 8).text(d => d.name.replace("水团", ""));
    root.selectAll(".year-line").data(allMonths.filter(m => m.endsWith("-01"))).join("line")
      .attr("x1", d => x(d)).attr("x2", d => x(d)).attr("y1", margin.top - 4).attr("y2", height - margin.bottom)
      .attr("stroke", "rgba(139,207,225,.22)");

    const sideDots = root.selectAll(".side-event").data(events).join("circle")
      .attr("class", "event-dot side-event")
      .attr("cx", d => x(d.month) + x.bandwidth() / 2)
      .attr("cy", d => y(d.type) + y.bandwidth() / 2 + regionOffset(d.regionId))
      .attr("r", 0)
      .attr("fill", d => typeMap[d.type].color).attr("fill-opacity", 0)
      .attr("stroke", d => d.id === state.selectedEventId ? "#fff" : "#071722")
      .attr("stroke-width", d => d.id === state.selectedEventId ? 1.6 : .7)
      .style("cursor", "pointer")
      .on("click", (_, d) => selectEvent(d, false))
      .on("mousemove", (event, d) => showTooltip(event, tooltipEvent(d)))
      .on("mouseleave", hideTooltip);
    sideDots.transition()
      .delay(d => Math.max(0, allMonths.indexOf(d.month)) * 16 + typeDefs.findIndex(t => t.id === d.type) * 45)
      .duration(520).ease(d3.easeCubicOut)
      .attr("r", d => 2 + d.score * 3.6)
      .attr("fill-opacity", .76);

    root.append("g").attr("class", "axis")
      .attr("transform", `translate(0,${height - margin.bottom + 5})`)
      .call(d3.axisBottom(x).tickValues(allMonths.filter((_, i) => i % 6 === 0)).tickFormat(d => d.slice(2).replace("-", "/")).tickSize(3));
  }

  function renderSideMonthAnalysis(root, width, height) {
    const monthEvents = derivedEvents.filter(d => d.month === state.selectedMonth && state.activeTypes.has(d.type));
    const affectedRegions = new Set(monthEvents.map(d => d.regionId)).size;
    const typeCounts = new Map(d3.rollups(monthEvents, values => values.length, d => d.type));
    const strongestType = typeDefs.slice().sort((a, b) =>
      d3.descending(typeCounts.get(a.id) || 0, typeCounts.get(b.id) || 0)
    )[0];

    root.append("rect").attr("x", 8).attr("y", 8).attr("width", width - 16).attr("height", height - 16)
      .attr("fill", "rgba(5,22,34,.72)").attr("stroke", "rgba(139,207,225,.16)");
    root.append("text").attr("x", 18).attr("y", 30).attr("class", "svg-title").style("font-size", "15px").text(`${monthCn(state.selectedMonth)}事件画像`);
    root.append("text").attr("x", width - 16).attr("y", 29).attr("text-anchor", "end").attr("class", "svg-small").attr("font-size", 9).text("MONTH PROFILE");

    const kpis = [
      ["事件总数", monthEvents.length],
      ["涉及海域", affectedRegions],
      ["主要类型", strongestType ? strongestType.name : "—"]
    ];
    const kpi = root.selectAll(".month-kpi").data(kpis).join("g")
      .attr("class", "month-kpi").attr("transform", (_, i) => `translate(${18 + i * (width - 36) / 3},43)`);
    kpi.append("rect").attr("width", (width - 48) / 3).attr("height", 41).attr("fill", "rgba(255,255,255,.025)").attr("stroke", "rgba(139,207,225,.12)");
    kpi.append("text").attr("x", 7).attr("y", 14).attr("fill", "#7ca7b6").style("font-size", "10px").text(d => d[0]);
    kpi.append("text").attr("x", 7).attr("y", 33).attr("fill", "#e8f8fc").style("font-size", d => typeof d[1] === "number" ? "18px" : "12px").attr("font-weight", 800).text(d => d[1]);

    root.append("text").attr("x", 18).attr("y", 105).attr("class", "svg-title").attr("font-size", 12).text("事件类型构成");
    const maxCount = d3.max(typeDefs, d => typeCounts.get(d.id) || 0) || 1;
    const barScale = d3.scaleLinear().domain([0, maxCount]).range([0, width - 124]);
    const typeRow = root.selectAll(".month-type-row").data(typeDefs).join("g")
      .attr("class", "month-type-row").attr("transform", (_, i) => `translate(18,${121 + i * 18})`);
    typeRow.append("text").attr("y", 9).attr("fill", d => d.color).attr("font-size", 10).attr("font-weight", 700).text(d => d.name);
    typeRow.append("rect").attr("x", 78).attr("y", 0).attr("width", width - 124).attr("height", 10).attr("rx", 5).attr("fill", "rgba(255,255,255,.06)");
    typeRow.append("rect").attr("class", "month-type-value").attr("x", 78).attr("y", 0).attr("width", 0).attr("height", 10).attr("rx", 5).attr("fill", d => d.color)
      .transition().delay((_, i) => 120 + i * 110).duration(720).ease(d3.easeCubicOut)
      .attr("width", d => barScale(typeCounts.get(d.id) || 0));
    typeRow.append("text").attr("x", width - 30).attr("y", 9).attr("text-anchor", "end").attr("class", "svg-small").attr("font-size", 10).text(d => typeCounts.get(d.id) || 0);

    const matrixTop = 231;
    root.append("text").attr("x", 18).attr("y", matrixTop - 14).attr("class", "svg-title").attr("font-size", 12).text("海域 × 事件类型");
    const matrixLeft = 72;
    const col = d3.scalePoint().domain(typeDefs.map(d => d.id)).range([matrixLeft + 18, width - 26]);
    const row = d3.scaleBand().domain(Object.keys(regionNames)).range([matrixTop + 28, height - 18]).padding(.28);
    root.selectAll(".matrix-col-label").data(typeDefs).join("text")
      .attr("class", "matrix-col-label").attr("x", d => col(d.id)).attr("y", matrixTop + 5)
      .attr("text-anchor", "middle").attr("fill", d => d.color).attr("font-size", 9.5).attr("font-weight", 700).text(d => d.name.slice(0, 2));
    root.selectAll(".matrix-row-label").data(Object.keys(regionNames)).join("text")
      .attr("class", "matrix-row-label").attr("x", matrixLeft - 8).attr("y", d => row(d) + row.bandwidth() / 2 + 3)
      .attr("text-anchor", "end").attr("fill", "#7ca7b6").attr("font-size", 10).text(d => regionShort[d]);

    const cells = [];
    Object.keys(regionNames).forEach(regionId => typeDefs.forEach(type => {
      const event = monthEvents.find(d => d.regionId === regionId && d.type === type.id);
      cells.push({ regionId, type, event });
    }));
    root.selectAll(".month-cell").data(cells).join("circle")
      .attr("class", "month-cell")
      .attr("cx", d => col(d.type.id)).attr("cy", d => row(d.regionId) + row.bandwidth() / 2)
      .attr("r", d => d.event ? 3 + d.event.score * 6 : 1.8)
      .attr("fill", d => d.event ? d.type.color : "rgba(139,207,225,.12)")
      .attr("fill-opacity", d => d.event ? .82 : .45)
      .attr("stroke", d => d.event ? "#06131f" : "none")
      .style("cursor", d => d.event ? "pointer" : "default")
      .on("click", (_, d) => { if (d.event) selectEvent(d.event, false); })
      .on("mousemove", (event, d) => {
        if (d.event) showTooltip(event, tooltipEvent(d.event));
      })
      .on("mouseleave", hideTooltip);
  }

  function renderSideGraph(root, width, height) {
    root.append("rect").attr("x", 8).attr("y", 8).attr("width", width - 16).attr("height", height - 16)
      .attr("fill", "rgba(5,22,34,.68)").attr("stroke", "rgba(139,207,225,.14)");
    root.append("text").attr("x", 18).attr("y", 27).attr("class", "svg-title").text("海域同期关系");
    root.append("text").attr("x", width - 16).attr("y", 27).attr("text-anchor", "end").attr("class", "svg-small").text("连线宽度 = 同期共现");

    const severity = regionSeverityData();
    const severityById = new Map(severity.map(d => [d.regionId, d]));
    const cx = width / 2, cy = height / 2 + 7;
    const rx = Math.max(68, width * .29), ry = Math.max(50, height * .27);
    const nodes = severity.map((d, i) => ({
      ...d,
      x: cx + Math.cos(-Math.PI / 2 + i * Math.PI / 3) * rx,
      y: cy + Math.sin(-Math.PI / 2 + i * Math.PI / 3) * ry
    }));
    const nodeById = new Map(nodes.map(d => [d.regionId, d]));
    const pairCounts = new Map();
    d3.groups(visibleEvents, d => `${d.month}|${d.type}`).forEach(([, values]) => {
      const ids = [...new Set(values.map(d => d.regionId))];
      for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
        const key = [ids[i], ids[j]].sort().join("|");
        pairCounts.set(key, (pairCounts.get(key) || 0) + 1);
      }
    });
    const links = [...pairCounts].map(([key, count]) => {
      const [a, b] = key.split("|");
      return { source: nodeById.get(a), target: nodeById.get(b), count };
    }).filter(d => d.source && d.target);
    const maxLink = d3.max(links, d => d.count) || 1;
    const hasFocus = Boolean(state.selectedRegionId);
    const neighborIds = new Set();
    if (hasFocus) {
      links.forEach(link => {
        if (link.source.regionId === state.selectedRegionId) neighborIds.add(link.target.regionId);
        if (link.target.regionId === state.selectedRegionId) neighborIds.add(link.source.regionId);
      });
    }
    const linkSelection = root.selectAll(".side-link").data(links).join("line")
      .attr("class", "side-link")
      .attr("x1", d => d.source.x).attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x).attr("y2", d => d.target.y)
      .attr("stroke", d => {
        const incident = d.source.regionId === state.selectedRegionId || d.target.regionId === state.selectedRegionId;
        return hasFocus && incident ? "rgba(85,215,255,.88)" : "rgba(85,215,255,.26)";
      })
      .attr("stroke-width", d => {
        const incident = d.source.regionId === state.selectedRegionId || d.target.regionId === state.selectedRegionId;
        return .5 + 3 * d.count / maxLink + (hasFocus && incident ? 1 : 0);
      })
      .attr("stroke-dasharray", d => {
        d._length = Math.hypot(d.target.x - d.source.x, d.target.y - d.source.y);
        return `${d._length} ${d._length}`;
      })
      .attr("stroke-dashoffset", d => d._length)
      .attr("opacity", d => {
        if (!hasFocus) return 0;
        return d.source.regionId === state.selectedRegionId || d.target.regionId === state.selectedRegionId ? 0 : .025;
      });

    linkSelection.filter(d => !hasFocus || d.source.regionId === state.selectedRegionId || d.target.regionId === state.selectedRegionId)
      .transition()
      .delay((_, i) => (hasFocus ? 340 : 660) + i * 48)
      .duration(650).ease(d3.easeCubicOut)
      .attr("stroke-dashoffset", 0)
      .attr("opacity", hasFocus ? .82 : .58);

    const node = root.selectAll(".side-node").data(nodes).join("g")
      .attr("class", d => `side-node${d.regionId === state.selectedRegionId ? " focused" : ""}`)
      .attr("opacity", d => {
        if (!hasFocus) return 0;
        return d.regionId === state.selectedRegionId ? 0 : .1;
      })
      .attr("transform", d => `translate(${d.x},${d.y}) scale(${hasFocus && d.regionId !== state.selectedRegionId ? .92 : .25})`)
      .style("cursor", "pointer").on("click", (_, d) => selectRegion(d.regionId, false));
    node.append("circle").attr("r", d => 14 + Math.sqrt(d.count))
      .attr("fill", "rgba(18,59,76,.92)")
      .attr("stroke", d => d.regionId === state.selectedRegionId ? "#fff" : typeDefs[d.score % typeDefs.length].color)
      .attr("stroke-width", d => d.regionId === state.selectedRegionId ? 2.8 : 1.2)
      .attr("filter", d => d.regionId === state.selectedRegionId ? "drop-shadow(0 0 6px rgba(85,215,255,.9))" : null);
    node.append("text").attr("text-anchor", "middle").attr("y", -1).attr("class", "svg-title").attr("font-size", 9).text(d => regionShort[d.regionId]);
    node.append("text").attr("text-anchor", "middle").attr("y", 11).attr("class", "svg-small").attr("font-size", 8.5).text(d => d.count);

    if (hasFocus) {
      node.filter(d => d.regionId === state.selectedRegionId)
        .transition().duration(430).ease(d3.easeBackOut)
        .attr("opacity", 1)
        .attr("transform", d => `translate(${d.x},${d.y}) scale(1.1)`);
      node.filter(d => neighborIds.has(d.regionId))
        .transition().delay((_, i) => 1030 + i * 90).duration(430).ease(d3.easeCubicOut)
        .attr("opacity", .84)
        .attr("transform", d => `translate(${d.x},${d.y}) scale(1)`);
    } else {
      node.transition().delay((_, i) => i * 90).duration(470).ease(d3.easeBackOut)
        .attr("opacity", 1)
        .attr("transform", d => `translate(${d.x},${d.y}) scale(1)`);
    }
  }

  function renderGraph(root, width, height) {
    const contentRight = width - 248;
    const positions = {
      R1: [.20, .19], R2: [.59, .20], R3: [.38, .46],
      R4: [.78, .48], R5: [.64, .76], R6: [.20, .79]
    };
    const regionGroups = d3.groups(visibleEvents, d => d.regionId)
      .map(([id, events]) => ({
        id, name: regionNames[id], events,
        count: events.length,
        strength: d3.mean(events, d => d.strength)
      }));

    const nodes = regionGroups.map(d => ({
      ...d,
      x: 36 + positions[d.id][0] * (contentRight - 64),
      y: 24 + positions[d.id][1] * (height - 48)
    }));
    const nodeById = new Map(nodes.map(d => [d.id, d]));

    const pairCounts = new Map();
    d3.groups(visibleEvents, d => `${d.month}|${d.type}`).forEach(([, events]) => {
      const ids = [...new Set(events.map(d => d.regionId))];
      for (let i = 0; i < ids.length; i++) {
        for (let j = i + 1; j < ids.length; j++) {
          const key = [ids[i], ids[j]].sort().join("|");
          pairCounts.set(key, (pairCounts.get(key) || 0) + 1);
        }
      }
    });
    const links = [...pairCounts].map(([key, value]) => {
      const [a, b] = key.split("|");
      return { source: nodeById.get(a), target: nodeById.get(b), value };
    }).filter(d => d.source && d.target);

    const maxLink = d3.max(links, d => d.value) || 1;
    root.append("g").selectAll("path").data(links).join("path")
      .attr("d", d => {
        const mx = (d.source.x + d.target.x) / 2;
        const my = (d.source.y + d.target.y) / 2 - Math.abs(d.source.x - d.target.x) * .16;
        return `M${d.source.x},${d.source.y} Q${mx},${my} ${d.target.x},${d.target.y}`;
      })
      .attr("fill", "none")
      .attr("stroke", "rgba(121,190,211,.24)")
      .attr("stroke-width", d => .6 + 4 * d.value / maxLink);

    const maxCount = d3.max(nodes, d => d.count) || 1;
    const node = root.append("g").selectAll("g").data(nodes).join("g")
      .attr("class", "region-node")
      .attr("transform", d => `translate(${d.x},${d.y})`)
      .on("click", (_, d) => selectRegion(d.id, false))
      .on("mousemove", (event, d) => showTooltip(event, `<b>${d.name}</b><br>${d.count} 个事件 · 平均强度 ${fmt1(d.strength)}`))
      .on("mouseleave", hideTooltip);

    node.append("circle")
      .attr("r", d => 30 + 19 * Math.sqrt(d.count / maxCount))
      .attr("fill", "rgba(12,40,56,.94)")
      .attr("stroke", "rgba(139,207,225,.35)")
      .attr("stroke-width", 1.2);
    node.append("circle")
      .attr("r", d => 23 + 15 * Math.sqrt(d.count / maxCount))
      .attr("fill", "rgba(85,215,255,.08)")
      .attr("stroke", "rgba(85,215,255,.24)")
      .attr("stroke-dasharray", "2 3");
    node.append("text").attr("text-anchor", "middle").attr("y", -2).attr("class", "svg-title").text(d => d.name);
    node.append("text").attr("text-anchor", "middle").attr("y", 13).attr("class", "svg-small").text(d => `${d.count} EVENTS`);

    node.each(function(d) {
      const typeCounts = new Map(d3.rollups(d.events, v => v.length, e => e.type));
      const satellites = typeDefs.filter(t => typeCounts.has(t.id));
      d3.select(this).selectAll(".satellite").data(satellites).join("circle")
        .attr("class", "satellite")
        .attr("cx", (_, i) => Math.cos(-Math.PI / 2 + i * Math.PI * 2 / satellites.length) * 50)
        .attr("cy", (_, i) => Math.sin(-Math.PI / 2 + i * Math.PI * 2 / satellites.length) * 50)
        .attr("r", t => 4 + Math.sqrt(typeCounts.get(t.id)) * 1.3)
        .attr("fill", t => t.color)
        .attr("fill-opacity", .78)
        .attr("stroke", "#071722")
        .attr("stroke-width", 2);
    });

    const current = selectedEvent();
    if (current && nodeById.has(current.regionId)) {
      const n = nodeById.get(current.regionId);
      root.append("circle").attr("cx", n.x).attr("cy", n.y)
        .attr("r", 62).attr("fill", "none")
        .attr("stroke", typeMap[current.type].color).attr("stroke-width", 1.4)
        .attr("stroke-dasharray", "4 5").attr("opacity", .8);
    }

    root.append("text").attr("x", 18).attr("y", 24).attr("class", "svg-small")
      .text("海域节点大小 = 水团事件数量 · 彩色卫星 = 水团类型 · 连线宽度 = 同期共现次数");
  }

  function renderTimeline(root, width, height) {
    const margin = { top: 36, right: 260, bottom: 34, left: 94 };
    const chartW = width - margin.left - margin.right;
    const chartH = height - margin.top - margin.bottom;
    const months = state.year === "all" ? allMonths : allMonths.filter(m => m.startsWith(state.year));
    const x = d3.scaleBand().domain(months).range([margin.left, margin.left + chartW]).padding(.18);
    const y = d3.scaleBand().domain(typeDefs.map(d => d.id)).range([margin.top, margin.top + chartH]).padding(.28);

    root.append("g").selectAll("rect").data(typeDefs).join("rect")
      .attr("x", margin.left).attr("y", d => y(d.id) - 6)
      .attr("width", chartW).attr("height", y.bandwidth() + 12)
      .attr("fill", (_, i) => i % 2 ? "rgba(255,255,255,.012)" : "rgba(85,215,255,.018)");

    root.append("g").selectAll("line").data(months).join("line")
      .attr("x1", d => x(d) + x.bandwidth() / 2).attr("x2", d => x(d) + x.bandwidth() / 2)
      .attr("y1", margin.top - 12).attr("y2", margin.top + chartH + 8)
      .attr("stroke", d => d.endsWith("-01") ? "rgba(139,207,225,.28)" : "rgba(139,207,225,.07)");

    root.append("g").selectAll("text").data(typeDefs).join("text")
      .attr("x", margin.left - 15).attr("y", d => y(d.id) + y.bandwidth() / 2 + 4)
      .attr("text-anchor", "end").attr("fill", d => d.color).attr("font-size", 10).attr("font-weight", 700)
      .text(d => d.name);

    const eventData = visibleEvents.filter(d => months.includes(d.month));
    const regionOffset = d3.scalePoint().domain(Object.keys(regionNames)).range([-y.bandwidth() * .28, y.bandwidth() * .28]);

    const lines = d3.groups(eventData, d => `${d.type}|${d.regionId}`);
    root.append("g").selectAll("path").data(lines).join("path")
      .attr("d", ([, values]) => d3.line()
        .x(d => x(d.month) + x.bandwidth() / 2)
        .y(d => y(d.type) + y.bandwidth() / 2 + regionOffset(d.regionId))
        .curve(d3.curveMonotoneX)(values.slice().sort((a, b) => d3.ascending(a.date, b.date))))
      .attr("fill", "none").attr("stroke", ([key]) => typeMap[key.split("|")[0]].color)
      .attr("stroke-opacity", .18).attr("stroke-width", 1);

    const dots = root.append("g").selectAll("g").data(eventData).join("g")
      .attr("class", "event-dot")
      .attr("transform", d => `translate(${x(d.month) + x.bandwidth() / 2},${y(d.type) + y.bandwidth() / 2 + regionOffset(d.regionId)})`)
      .on("click", (_, d) => selectEvent(d, false))
      .on("mousemove", (event, d) => showTooltip(event, tooltipEvent(d)))
      .on("mouseleave", hideTooltip);

    dots.append("circle")
      .attr("r", d => 3 + d.score * 7)
      .attr("fill", d => typeMap[d.type].color)
      .attr("fill-opacity", .75)
      .attr("stroke", "#06131f").attr("stroke-width", 1.4);

    const current = selectedEvent();
    dots.filter(d => current && d.id === current.id).insert("circle", ":first-child")
      .attr("r", d => 10 + d.score * 7).attr("fill", "none")
      .attr("stroke", d => typeMap[d.type].color).attr("stroke-width", 1.4).attr("opacity", .9);

    root.append("g").attr("class", "axis")
      .attr("transform", `translate(0,${margin.top + chartH + 10})`)
      .call(d3.axisBottom(x).tickValues(months.filter((_, i) => i % (months.length > 18 ? 3 : 1) === 0)).tickFormat(d => d.slice(2).replace("-", "/")).tickSize(4));

    root.append("text").attr("x", margin.left).attr("y", 20).attr("class", "svg-small")
      .text("每条泳道代表一种异常 · 纵向错位对应不同海域 · 圆点大小表示事件强度");
  }

  function regionSeverityData() {
    const activeEvents = derivedEvents.filter(d =>
      state.activeTypes.has(d.type) &&
      (!state.selectedMonth || d.month === state.selectedMonth)
    );
    const rows = Object.keys(regionNames).map(regionId => {
      const events = activeEvents.filter(d => d.regionId === regionId);
      const weighted = d3.sum(events, event => {
        const weight = typeMap[event.type].weight;
        return weight * (.4 + .6 * event.strength / 100);
      });
      return {
        regionId,
        region: regionNames[regionId],
        count: events.length,
        typeCounts: new Map(d3.rollups(events, values => values.length, event => event.type)),
        weighted,
        meanStrength: d3.mean(events, d => d.strength) || 0
      };
    });
    const extent = d3.extent(rows, d => d.weighted);
    const maxCount = d3.max(rows, d => d.count) || 1;
    rows.forEach(d => {
      const ratio = extent[1] === extent[0] ? .5 : (d.weighted - extent[0]) / (extent[1] - extent[0]);
      d.score = Math.round(25 + ratio * 75);
      d.relativeFrequency = Math.round(100 * Math.log1p(d.count) / Math.log1p(maxCount));
    });
    rows.slice().sort((a, b) => d3.ascending(a.weighted, b.weighted)).forEach((d, index) => {
      d.colorScore = Math.round(18 + index * 80 / Math.max(1, rows.length - 1));
    });
    return rows;
  }

  function renderMap(root, width, height) {
    const featureCollection = geo.geojson;
    if (!featureCollection || !featureCollection.features) {
      root.append("text").attr("x", 40).attr("y", 50).attr("class", "svg-label").text("地图数据不可用");
      return;
    }

    const panelWidth = 244;
    const mapRight = width - panelWidth;
    const chinaFeatures = (chinaFull?.features || []).filter(feature => feature.properties?.name);
    const baseMap = chinaFeatures.length ? {
      type: "FeatureCollection",
      features: chinaFeatures
    } : {
      type: "FeatureCollection",
      features: Array.isArray(chinaCoast?.land) ? chinaCoast.land : []
    };
    const projection = d3.geoIdentity()
      .reflectY(true)
      .fitExtent([[24, 24], [mapRight - 12, height - 24]], baseMap.features.length ? baseMap : featureCollection);
    const path = d3.geoPath(projection);
    const severity = regionSeverityData();
    const severityById = new Map(severity.map(d => [d.regionId, d]));
    const severityColor = d3.scaleLinear()
      .domain([25, 50, 75, 100])
      .range(["#1d6b8a", "#3bb9b0", "#efbd58", "#ff604e"])
      .clamp(true);

    root.append("rect")
      .attr("x", 8).attr("y", 8).attr("width", mapRight - 16).attr("height", height - 16)
      .attr("fill", "rgba(8,31,46,.55)").attr("stroke", "rgba(139,207,225,.12)");

    if (chinaFeatures.length) {
      root.append("g").attr("class", "china-full-map").selectAll("path")
        .data(chinaFeatures).join("path")
        .attr("d", path)
        .attr("fill", "rgba(48,68,73,.86)")
        .attr("stroke", "rgba(171,207,205,.36)")
        .attr("stroke-width", .55);
    } else if (chinaCoast) {
      root.append("g").attr("class", "china-land").selectAll("path")
        .data(chinaCoast.land || []).join("path")
        .attr("d", path)
        .attr("fill", "rgba(48,68,73,.86)")
        .attr("stroke", "rgba(171,207,205,.36)")
        .attr("stroke-width", .7);
    }

    if (chinaCoast) {
      root.append("g").attr("class", "china-coastline").selectAll("path")
        .data(chinaCoast.coastlines || []).join("path")
        .attr("d", path).attr("fill", "none")
        .attr("stroke", "rgba(213,240,235,.66)").attr("stroke-width", .9);
    }

    const seaRegions = root.append("g").attr("class", "severity-regions")
      .selectAll("path").data(featureCollection.features).join("path")
      .attr("d", path)
      .attr("fill", d => severityColor(severityById.get(d.properties?.region_id)?.score || 25))
      .attr("fill-opacity", .72)
      .attr("stroke", d => state.selectedRegionId === d.properties?.region_id ? "#f4ffff" : "rgba(117,224,246,.76)")
      .attr("stroke-width", d => state.selectedRegionId === d.properties?.region_id ? 2.4 : 1.1)
      .style("cursor", "pointer")
      .on("click", (_, d) => selectRegion(d.properties?.region_id))
      .on("mousemove", (event, d) => {
        const item = severityById.get(d.properties?.region_id);
        showTooltip(event, `<b>${item.region}</b><br>事件次数 ${item.count} 次<br>加权严重性 ${item.score}/100`);
      })
      .on("mouseleave", hideTooltip);

    seaRegions.filter(d => state.selectedRegionId === d.properties?.region_id)
      .attr("filter", "drop-shadow(0 0 7px rgba(85,215,255,.8))");

    const centers = new Map((geo.regions || []).map(d => [d.region_id, projection(d.center)]));
    const labels = root.append("g").selectAll("g").data(severity).join("g")
      .attr("transform", d => {
        const p = centers.get(d.regionId);
        return `translate(${p?.[0] || 0},${p?.[1] || 0})`;
      })
      .style("cursor", "pointer")
      .on("click", (_, d) => selectRegion(d.regionId))
      .on("mousemove", (event, d) => showTooltip(event, `<b>${d.region}</b><br>${d.count} 次事件 · 严重性 ${d.score}/100`))
      .on("mouseleave", hideTooltip);
    labels.append("circle")
      .attr("r", d => 8 + Math.sqrt(d.count) * .55)
      .attr("fill", d => severityColor(d.score))
      .attr("stroke", "#eaffff").attr("stroke-width", 1.3);
    labels.append("text").attr("x", 12).attr("y", -2).attr("class", "svg-title").text(d => d.region);
    labels.append("text").attr("x", 12).attr("y", 11).attr("class", "svg-small").text(d => `${d.count}次 · ${d.score}分`);

    const event = selectedEvent();
    if (event) {
      const sourceRows = getFilteredRecords().filter(d => d.month_label === event.month && d.region_id === event.regionId);
      const pointValues = sourceRows.map(d => rawMetric(d, event.type));
      const low = quantile(pointValues, .1);
      const high = quantile(pointValues, .9);
      root.append("g").selectAll("circle").data(sourceRows).join("circle")
        .attr("cx", d => projection([+d.longitude, +d.latitude])[0])
        .attr("cy", d => projection([+d.longitude, +d.latitude])[1])
        .attr("r", d => 2.5 + rawSeverity(rawMetric(d, event.type), low, high, event.type) * 5)
        .attr("fill", typeMap[event.type].color).attr("fill-opacity", .78)
        .attr("stroke", "#fff").attr("stroke-width", .55)
        .on("mousemove", (ev, d) => showTooltip(ev, `<b>${event.region} · ${event.month}</b><br>${typeMap[event.type].metric} ${formatRaw(d, event.type)}`))
        .on("mouseleave", hideTooltip);
    }

    const panelY = event ? 190 : 16;
    const panel = root.append("g").attr("transform", `translate(${width - panelWidth + 10},${panelY})`);
    panel.append("rect").attr("width", panelWidth - 20).attr("height", Math.min(254, height - panelY - 12))
      .attr("fill", "rgba(5,22,34,.82)").attr("stroke", "rgba(139,207,225,.22)");
    panel.append("text").attr("x", 12).attr("y", 20).attr("class", "svg-title").text("综合严重性 WESI");
    panel.append("text").attr("x", 12).attr("y", 35).attr("class", "svg-small").text("Σ 权重 × (0.4 + 0.6 × 强度)");

    const ranked = severity.slice().sort((a, b) => d3.descending(a.score, b.score));
    const rank = panel.selectAll(".rank-row").data(ranked).join("g")
      .attr("class", "rank-row")
      .attr("transform", (_, i) => `translate(12,${55 + i * 30})`)
      .style("cursor", "pointer")
      .on("click", (_, d) => selectRegion(d.regionId));
    rank.append("text").attr("y", 8).attr("class", "svg-small").text((d, i) => `${i + 1}  ${d.region}`);
    rank.append("rect").attr("x", 78).attr("y", 0).attr("width", 100).attr("height", 8).attr("rx", 4).attr("fill", "rgba(255,255,255,.07)");
    rank.append("rect").attr("x", 78).attr("y", 0).attr("width", d => d.score).attr("height", 8).attr("rx", 4).attr("fill", d => severityColor(d.score));
    rank.append("text").attr("x", 190).attr("y", 8).attr("fill", d => severityColor(d.score)).attr("font-size", 9).attr("font-weight", 800).text(d => d.score);

    root.append("text").attr("x", 18).attr("y", 23).attr("class", "svg-small")
      .text("中国省级轮廓 · 六海域全部着色 · 点击海域查看 2023–2025 全部事件");
  }

  function rawMetric(d, type) {
    if (type === "fresh") return +d.phy_so;
    if (type === "productive") return +d.bgc_chl;
    return +d.phy_thetao;
  }

  function rawSeverity(value, low, high, type) {
    if (type === "cold" || type === "fresh") return clamp((high - value) / ((high - low) || 1));
    return clamp((value - low) / ((high - low) || 1));
  }

  function formatRaw(d, type) {
    if (type === "fresh") return `${(+d.phy_so).toFixed(2)} PSU`;
    if (type === "productive") return `${(+d.bgc_chl).toFixed(2)} mg/m³`;
    return `${(+d.phy_thetao).toFixed(1)} °C`;
  }

  function renderOverview() {
    els.overviewSvg.selectAll("*").remove();
    const node = els.overviewSvg.node();
    const width = Math.max(680, node.getBoundingClientRect().width);
    const height = 78;
    els.overviewSvg.attr("viewBox", `0 0 ${width} ${height}`);
    const x = d3.scaleBand().domain(allMonths).range([10, width - 10]).padding(.22);
    const monthEvents = new Map(d3.groups(
      derivedEvents.filter(d => state.activeTypes.has(d.type)),
      d => d.month
    ));

    if (state.year !== "all") {
      const yearMonths = allMonths.filter(month => month.startsWith(state.year));
      const firstMonth = yearMonths[0];
      const lastMonth = yearMonths[yearMonths.length - 1];
      const focusX = x(firstMonth) - (x.step() - x.bandwidth()) / 2;
      const focusWidth = x(lastMonth) + x.bandwidth() + (x.step() - x.bandwidth()) / 2 - focusX;
      const perimeter = 2 * (focusWidth + 58);
      const focus = els.overviewSvg.append("g").attr("class", "overview-year-focus");

      focus.append("rect")
        .attr("class", "overview-year-focus-fill")
        .attr("x", focusX).attr("y", 4).attr("width", focusWidth).attr("height", 58).attr("rx", 4)
        .attr("fill", "rgba(85,215,255,.02)").attr("opacity", 0)
        .transition().duration(620).ease(d3.easeCubicOut)
        .attr("fill", "rgba(85,215,255,.10)").attr("opacity", 1);

      focus.append("rect")
        .attr("class", "overview-year-focus-box")
        .attr("x", focusX).attr("y", 4).attr("width", focusWidth).attr("height", 58).attr("rx", 4)
        .attr("fill", "none").attr("stroke", "rgba(85,215,255,.92)").attr("stroke-width", 1.2)
        .attr("stroke-dasharray", `${perimeter} ${perimeter}`).attr("stroke-dashoffset", perimeter)
        .transition().duration(860).ease(d3.easeCubicOut)
        .attr("stroke-dashoffset", 0);
    }

    els.overviewSvg.append("line")
      .attr("x1", 10).attr("x2", width - 10).attr("y1", 46).attr("y2", 46)
      .attr("stroke", "rgba(139,207,225,.28)");

    const groups = els.overviewSvg.append("g").selectAll("g").data(allMonths).join("g")
      .attr("class", "overview-month")
      .attr("transform", d => `translate(${x(d) + x.bandwidth() / 2},0)`)
      .style("cursor", "pointer")
      .on("click", (_, month) => {
        state.selectedMonth = state.selectedMonth === month ? null : month;
        state.selectedEventId = null;
        state.selectedRegionId = null;
        hideTooltip();
        render();
      });

    groups.append("rect")
      .attr("x", -x.step() / 2 + 1).attr("width", x.step() - 2).attr("y", 5).attr("height", 57)
      .attr("fill", d => state.selectedMonth === d ? "rgba(85,215,255,.1)" : "transparent")
      .attr("stroke", d => state.selectedMonth === d ? "rgba(85,215,255,.48)" : "transparent");

    groups.each(function(month) {
      const events = (monthEvents.get(month) || []).slice().sort((a, b) => d3.descending(a.strength, b.strength));
      d3.select(this).selectAll("circle").data(events.slice(0, 4)).join("circle")
        .attr("cy", (_, i) => 42 - i * 9)
        .attr("r", d => 2.3 + d.score * 1.7)
        .attr("fill", d => typeMap[d.type].color).attr("fill-opacity", .82);
    });

    groups.filter(d => d.endsWith("-01")).append("text")
      .attr("y", 74).attr("text-anchor", "middle").attr("class", "svg-small overview-year").text(d => d.slice(0, 4));
  }

  function tooltipEvent(d) {
    return `<b>${d.region} · ${typeMap[d.type].name}</b><br>${d.month} · ${formatEventValue(d)}<br>综合强度 ${d.strength}/100`;
  }

  function showTooltip(event, html) {
    const box = els.visualStage.getBoundingClientRect();
    els.tooltip.innerHTML = html;
    els.tooltip.hidden = false;
    const left = Math.min(event.clientX - box.left + 12, box.width - 230);
    const top = Math.min(event.clientY - box.top + 12, box.height - 100);
    els.tooltip.style.left = `${Math.max(8, left)}px`;
    els.tooltip.style.top = `${Math.max(8, top)}px`;
  }

  function hideTooltip() {
    els.tooltip.hidden = true;
  }

  function selectEvent(event, jumpView) {
    if (!event) return;
    state.selectedEventId = event.id;
    state.selectedRegionId = event.regionId;
    state.selectedMonth = null;
    hideTooltip();
    render();
  }

  function selectRegion(regionId) {
    if (!regionId) return;
    state.selectedRegionId = regionId;
    state.selectedEventId = null;
    state.selectedMonth = null;
    hideTooltip();
    if (state.year !== "all") {
      state.year = "all";
      els.year.value = "all";
      updateDerived();
    }
    render();
  }

  function renderViewMeta() {
    const meta = ["C+A+B", "地理地图 × 时序关系联合视图"];
    document.querySelector("#view-code").textContent = meta[0];
    document.querySelector("#view-title").textContent = meta[1];
  }

  function render() {
    visibleEvents = getVisibleEvents();
    renderViewMeta();
    renderTypeFilters();
    renderEventList();
    renderEventCard();
    updateHeaderStats();
    renderMain();
    renderOverview();
    document.querySelector("#status-text").textContent = `${visibleEvents.length} 个事件可见 · ${state.depth === "all" ? "全部水层" : state.depth}`;
  }

  function stopPlayback() {
    state.playing = false;
    clearInterval(state.timer);
    state.timer = null;
    els.play.querySelector("span").textContent = "▶";
  }

  function togglePlayback() {
    if (state.playing) {
      stopPlayback();
      return;
    }
    state.playing = true;
    els.play.querySelector("span").textContent = "Ⅱ";
    const months = state.year === "all" ? allMonths : allMonths.filter(m => m.startsWith(state.year));
    let index = Math.max(0, months.indexOf(state.selectedMonth));
    state.timer = setInterval(() => {
      state.selectedMonth = months[index % months.length];
      state.selectedEventId = null;
      index += 1;
      render();
    }, 850);
  }

  document.querySelectorAll(".view-btn").forEach(button => {
    button.addEventListener("click", () => {
      state.view = button.dataset.view;
      state.selectedEventId = null;
      state.selectedMonth = null;
      hideTooltip();
      render();
    });
  });

  els.year.addEventListener("change", () => {
    state.year = els.year.value;
    state.selectedMonth = null;
    state.selectedEventId = null;
    updateDerived();
    render();
  });
  els.depth.addEventListener("change", () => {
    state.depth = els.depth.value;
    state.selectedMonth = null;
    state.selectedEventId = null;
    updateDerived();
    render();
  });
  document.querySelector("#reset-btn").addEventListener("click", () => {
    stopPlayback();
    state.year = "all";
    state.depth = "all";
    state.view = "timeline";
    state.selectedMonth = null;
    state.selectedEventId = null;
    state.selectedRegionId = null;
    state.activeTypes = new Set(typeDefs.map(d => d.id));
    els.year.value = "all";
    els.depth.value = "all";
    updateDerived();
    render();
  });
  els.play.addEventListener("click", togglePlayback);

  const resizeObserver = new ResizeObserver(() => {
    cancelAnimationFrame(renderFrame);
    renderFrame = requestAnimationFrame(() => {
      renderMain();
      renderOverview();
    });
  });
  resizeObserver.observe(els.visualStage);

  updateDerived();
  render();
  if (!chinaCoast) {
    fetch("china-coastline-simplified.json")
      .then(response => response.json())
      .then(data => { chinaCoast = data; renderMain(); })
      .catch(() => {});
  }
  if (!chinaFull) {
    fetch("china-full.geojson")
      .then(response => response.json())
      .then(data => { chinaFull = data; renderMain(); })
      .catch(() => {});
  }
})();
