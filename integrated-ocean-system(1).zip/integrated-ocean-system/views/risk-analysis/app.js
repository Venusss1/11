(function () {
  "use strict";

  const DATA = window.LAB3_DATA;
  const GEO = window.LAB3_GEOJSON;
  const CHI = window.CHI_DATA;
  const AGG = window.LAB3_AGGREGATES;
  const RISK = window.LAB3_RISK_MODELS;
  const CORR = window.LAB3_CORRELATION;
  const ANALYTICS = window.LAB3_ANALYTICS;

  if (!DATA || !GEO || !AGG || !RISK) {
    document.body.innerHTML = "<div style='padding:24px;font-family:sans-serif'>数据包未加载，请确认 lab3-runtime-bundle.js 与页面在同一目录。</div>";
    return;
  }

  const records = DATA.records;
  const months = AGG.metadata.months;
  const regions = AGG.metadata.regions;
  const depths = AGG.metadata.depths;
  const colorRisk = d3.scaleLinear()
    .domain([0, 1.5, 4])
    .range(["#2f8c74", "#f4d06f", "#d84a2b"])
    .interpolate(d3.interpolateRgb);
  const levelColor = { "低风险":"#2f8c74", "中风险":"#f2a03a", "高风险":"#d84a2b" };
  const regionColor = d3.scaleOrdinal().domain(regions)
    .range(["#4477aa", "#66ccee", "#228833", "#ccbb44", "#ee6677", "#aa3377"]);
  const algorithmNames = {
    expert_rule:"专家规则阈值法",
    entropy_topsis:"熵权 TOPSIS 法",
    robust_anomaly:"稳健时空异常指数法",
    kmeans_layer:"K-means 风险分层法"
  };
  const scoreByRecord = new Map((RISK.record_scores || []).map(d => [d.record_id, d]));

  const state = {
    month: "2023-06",
    monthStart: "2023-01",
    monthEnd: "2023-06",
    depth: "all",
    algorithm: "expert_rule",
    region: "all",
    selected: null,
    detailMode: "diagnosis",
    analysisMode: "matrix",
    timeRegion: "all",
    playing: false
  };
  let timer = null;

  const tooltip = d3.select("#tooltip");
  const fmt = d3.format(".2f");
  const intFmt = d3.format(",");

  const regionCenters = new Map();
  RISK.consensus.forEach(d => regionCenters.set(d.region, d.center));
  GEO.features.forEach(f => {
    const p = f.properties || {};
    if (!regionCenters.has(p.region_name || p.region)) {
      regionCenters.set(p.region_name || p.region, p.center || d3.geoCentroid(f));
    }
  });

  function filterRecords(sel = {}) {
    return records.filter(d => {
      if (sel.region && sel.region !== "all" && d.region_name !== sel.region) return false;
      if (sel.monthStart || sel.monthEnd) {
        const startIndex = Math.max(0, months.indexOf(sel.monthStart || months[0]));
        const endIndex = Math.max(startIndex, months.indexOf(sel.monthEnd || months[months.length - 1]));
        const monthIndex = months.indexOf(d.month_label);
        if (monthIndex < startIndex || monthIndex > endIndex) return false;
      } else if (sel.month && d.month_label !== sel.month) return false;
      if (sel.depth && sel.depth !== "all" && d.depth_group !== sel.depth) return false;
      return true;
    });
  }

  function selectedMonths() {
    const startIndex = Math.max(0, months.indexOf(state.monthStart));
    const endIndex = Math.max(startIndex, months.indexOf(state.monthEnd));
    return months.slice(startIndex, endIndex + 1);
  }

  function periodLabel() {
    return state.monthStart === state.monthEnd
      ? state.monthStart
      : `${state.monthStart} — ${state.monthEnd}`;
  }

  function periodFilter(extra = {}) {
    return { ...extra, monthStart:state.monthStart, monthEnd:state.monthEnd };
  }

  function riskForRecord(d) {
    const model = scoreByRecord.get(d.record_id);
    const picked = model && model[state.algorithm];
    if (!picked && state.algorithm !== "expert_rule") {
      return { score:+d.risk_score || 0, level:d.risk_level || "低风险", visual:+d.risk_score || 0 };
    }
    const score = picked ? +picked.score || 0 : +d.risk_score || 0;
    const level = picked ? picked.level : d.risk_level || "低风险";
    const visual = state.algorithm === "expert_rule"
      ? score
      : level === "高风险" ? 3.7 + Math.min(.3, score * .3)
      : level === "中风险" ? 2.1 + Math.min(.8, score * .4)
      : Math.min(1.35, .35 + score);
    return { score, level, visual };
  }

  function summarize(list) {
    const out = { count:list.length, low:0, mid:0, high:0, score_mean:0 };
    if (!list.length) return out;
    for (const d of list) {
      const r = riskForRecord(d);
      out.score_mean += r.visual;
      if (r.level === "高风险") out.high++;
      else if (r.level === "中风险") out.mid++;
      else out.low++;
    }
    out.score_mean /= list.length;
    return out;
  }

  function regionSummary(region, depth = state.depth) {
    return summarize(filterRecords(periodFilter({ region, depth })));
  }

  function currentSelection() {
    const selected = state.selected || { region:"all", month:state.month, depth:state.depth };
    return {
      ...selected,
      month:state.month,
      monthStart:state.monthStart,
      monthEnd:state.monthEnd
    };
  }

  function setSelection(sel, options = {}) {
    state.selected = sel;
    state.region = sel.region || "all";
    if (sel.month) state.month = sel.month;
    if (sel.depth && !options.preserveDepth) state.depth = sel.depth;
    updateControls();
    renderAll();
  }

  function showTip(ev, html) {
    tooltip.html(html).style("opacity", 1);
    let x = ev.clientX + 14;
    let y = ev.clientY + 12;
    if (x > window.innerWidth - 280) x = ev.clientX - 270;
    if (y > window.innerHeight - 190) y = ev.clientY - 165;
    tooltip.style("left", x + "px").style("top", y + "px");
  }
  function hideTip() { tooltip.style("opacity", 0); }

  function updateControls() {
    d3.selectAll("[data-depth]").classed("active", function () { return this.dataset.depth === state.depth; });
    d3.selectAll("[data-analysis]").classed("active", function () { return this.dataset.analysis === state.analysisMode; });
    d3.select("#play-btn").classed("active", state.playing).text(state.playing ? "暂停播放" : "播放时间");
    d3.select("#current-pill").text(`${periodLabel()} / ${state.depth === "all" ? "全部深度" : state.depth} / ${algorithmNames[state.algorithm].replace("法","")}`);
    d3.select("#month-label").text(periodLabel());
    d3.select(".time-slider").classed("single-month", state.monthStart === state.monthEnd);
    const startIndex = Math.max(0, months.indexOf(state.monthStart));
    const endIndex = Math.max(startIndex, months.indexOf(state.monthEnd));
    const maxIndex = Math.max(1, months.length - 1);
    d3.select("#month-start-slider").property("value", startIndex);
    d3.select("#month-end-slider").property("value", endIndex);
    d3.select("#month-range-selection")
      .style("left", `${startIndex / maxIndex * 100}%`)
      .style("right", `${100 - endIndex / maxIndex * 100}%`);
    d3.select("#algorithm-select").property("value", state.algorithm);
    d3.select("#analysis-title").text(state.analysisMode === "matrix" ? "海域-月份-深度风险流带" : "风险时间剖面");
    d3.select("#analysis-info").attr("data-tip", state.analysisMode === "matrix"
      ? "借鉴论文中的多协调视图与层级预览思路：每个海域是一条时间流带，不同深度以分层彩带呈现；彩带厚度表示平均风险，发光节点表示高风险记录，点击节点可定位海域、月份与深度。"
      : "时间剖面展示所选海域在 2023-01 至 2025-12 的风险变化；堆叠柱表示低/中/高风险记录数，折线表示当前算法下的平均风险评分。可通过右侧海域下拉切换单海域。");
    d3.select("#time-split-wrap")
      .classed("active", state.analysisMode === "time");
    d3.select("#time-analysis-btn").text(state.timeRegion === "all" ? "时间剖面" : `时间剖面 · ${state.timeRegion}`);
    d3.selectAll("#time-region-menu button").classed("active", function () { return this.dataset.region === state.timeRegion; });
  }

  function drawMap() {
    const svg = d3.select("#risk-map");
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.classed("map-has-selection", state.region !== "all");
    svg.selectAll("*").remove();

    const M = { top:16, right:18, bottom:20, left:22 };
    const projection = d3.geoMercator();
    projection.fitExtent([[M.left, M.top], [W - M.right, H - M.bottom]], {
      type:"Polygon",
      coordinates:[[[107.5,18],[107.5,41.5],[126.5,41.5],[126.5,18],[107.5,18]]]
    });
    const path = d3.geoPath(projection);

    const defs = svg.append("defs");
    const seaGrad = defs.append("linearGradient").attr("id", "sea-grad").attr("x1", "0").attr("y1", "0").attr("x2", "1").attr("y2", "1");
    seaGrad.append("stop").attr("offset", "0%").attr("stop-color", "#0d3854");
    seaGrad.append("stop").attr("offset", "52%").attr("stop-color", "#082238");
    seaGrad.append("stop").attr("offset", "100%").attr("stop-color", "#04101c");
    const currentGrad = defs.append("linearGradient").attr("id", "current-grad").attr("x1", "0").attr("y1", "0").attr("x2", "1").attr("y2", "0");
    currentGrad.append("stop").attr("offset", "0%").attr("stop-color", "#4d9fbd").attr("stop-opacity", 0);
    currentGrad.append("stop").attr("offset", "50%").attr("stop-color", "#4d9fbd").attr("stop-opacity", .46);
    currentGrad.append("stop").attr("offset", "100%").attr("stop-color", "#4d9fbd").attr("stop-opacity", 0);
    svg.append("rect").attr("x", M.left).attr("y", M.top).attr("width", W-M.left-M.right).attr("height", H-M.top-M.bottom).attr("fill", "url(#sea-grad)");
    const grat = d3.geoGraticule().step([4,5]).extent([[107.5,18],[126.5,41.5]]);
    svg.append("path").datum(grat()).attr("d", path).attr("fill", "none").attr("stroke", "rgba(185,228,239,.16)").attr("stroke-width", .6);

    drawOceanContext(svg, projection, W, H, M);

    if (CHI && CHI.basemap) {
      svg.append("g").selectAll("path")
        .data(CHI.basemap.land || [])
        .join("path")
        .attr("class", "land")
        .attr("d", path);
      svg.append("g").selectAll("path")
        .data(CHI.basemap.coastlines || [])
        .join("path")
        .attr("class", "coastline")
        .attr("d", path);
    }

    svg.append("g").selectAll("path")
      .data(GEO.features)
      .join("path")
      .attr("class", d => `region-shape ${state.region === ((d.properties || {}).region_name || (d.properties || {}).region) ? "active" : ""}`)
      .attr("d", path)
      .on("click", (ev, d) => {
        const p = d.properties || {};
        setSelection({ region:p.region_name || p.region, month:state.month, depth:state.depth });
      });

    const cloud = filterRecords(periodFilter({ depth:state.depth })).filter(d => d.longitude && d.latitude);
    svg.append("g").attr("opacity", .62).selectAll("circle.risk-cloud")
      .data(cloud)
      .join("circle")
      .attr("class", "risk-cloud")
      .attr("cx", d => projection([+d.longitude, +d.latitude])[0])
      .attr("cy", d => projection([+d.longitude, +d.latitude])[1])
      .attr("r", d => riskForRecord(d).level === "高风险" ? 2.8 : riskForRecord(d).level === "中风险" ? 2.1 : 1.45)
      .attr("fill", d => levelColor[riskForRecord(d).level] || colorRisk(riskForRecord(d).visual))
      .attr("stroke", "#fff")
      .attr("stroke-width", .35)
      .on("mousemove", (ev, d) => {
        const r = riskForRecord(d);
        showTip(ev, `<div class="tt-title">${d.region_name} · ${d.month_label}</div><div class="tt-row"><span>算法</span><b>${algorithmNames[state.algorithm].replace("法","")}</b></div><div class="tt-row"><span>深度</span><b>${d.depth_group}</b></div><div class="tt-row"><span>风险评分</span><b>${fmt(r.score)}</b></div><div class="tt-row"><span>风险等级</span><b>${r.level.replace("风险","")}</b></div>`);
      })
      .on("mouseout", hideTip);

    const nodes = regions.map(region => {
      const center = regionCenters.get(region);
      const p = projection(center);
      const s = regionSummary(region);
      return { region, center, x:p[0], y:p[1], x0:p[0], y0:p[1], ...s };
    });
    const maxCount = d3.max(nodes, d => d.count) || 1;
    const r = d3.scaleSqrt().domain([0, maxCount]).range([12, 27]);
    d3.forceSimulation(nodes)
      .force("x", d3.forceX(d => d.x0).strength(.28))
      .force("y", d3.forceY(d => d.y0).strength(.28))
      .force("collide", d3.forceCollide(d => r(d.count) + 18).strength(1))
      .stop()
      .tick(130);

    const pairs = [];
    for (let i=0;i<nodes.length;i++) {
      for (let j=i+1;j<nodes.length;j++) {
        const a = nodes[i], b = nodes[j];
        const dist = Math.hypot(a.x-b.x, a.y-b.y);
        const diff = Math.abs(a.score_mean - b.score_mean);
        const weight = (1 / (1 + diff)) * (1 / Math.max(.45, dist / 260));
        pairs.push({ a, b, weight, risk:(a.score_mean + b.score_mean)/2 });
      }
    }
    pairs.sort((a,b) => b.weight - a.weight);
    const links = pairs.slice(0, 9);

    const linkG = svg.append("g");
    linkG.selectAll("path")
      .data(links)
      .join("path")
      .attr("class", d => `risk-link ${d.risk > 2 ? "hot" : ""}`)
      .attr("d", d => curved(d.a, d.b))
      .attr("stroke-width", d => 1 + d.weight * 3);

    const flowG = svg.append("g");
    flowG.selectAll("circle")
      .data(links)
      .join("circle")
      .attr("class", "flow-dot")
      .attr("r", d => 2.2 + d.risk)
      .attr("fill", d => colorRisk(d.risk))
      .append("animateMotion")
      .attr("dur", d => `${3.5 - Math.min(1.8, d.weight)}s`)
      .attr("repeatCount", "indefinite")
      .attr("path", d => curved(d.a, d.b));

    const activeNodes = state.region === "all" ? nodes : nodes.filter(d => d.region === state.region);
    activeNodes.forEach((activeNode) => {
      const beaconR = r(activeNode.count) + 16;
      const beacon = svg.append("g")
        .attr("class", "risk-beacon")
        .attr("transform", `translate(${activeNode.x},${activeNode.y})`);
      [0, 1, 2].forEach(i => {
        beacon.append("circle")
          .attr("class", "risk-beacon-ring")
          .attr("r", beaconR + i * 10)
          .attr("style", `color:${colorRisk(activeNode.score_mean)}; animation-delay:${i * .28}s`);
      });
    });

    const g = svg.append("g").selectAll("g.node")
      .data(nodes)
      .join("g")
      .attr("class", d => `node ${state.region === "all" || state.region === d.region ? "active" : ""} ${state.region !== "all" && state.region !== d.region ? "dimmed" : ""}`)
      .attr("transform", d => `translate(${d.x},${d.y})`)
      .on("click", (ev, d) => setSelection({ region:d.region, month:state.month, depth:state.depth }))
      .on("mousemove", (ev, d) => showTip(ev, tipForSummary(d.region, d)))
      .on("mouseout", hideTip);

    g.each(function (d) {
      const group = d3.select(this);
      const total = Math.max(1, d.low + d.mid + d.high);
      const ringRadius = r(d.count) + 6.5;
      const ringPath = (radius, startAngle, endAngle) => {
        const sx = Math.sin(startAngle) * radius;
        const sy = -Math.cos(startAngle) * radius;
        const ex = Math.sin(endAngle) * radius;
        const ey = -Math.cos(endAngle) * radius;
        const large = endAngle - startAngle > Math.PI ? 1 : 0;
        return `M${sx},${sy} A${radius},${radius} 0 ${large} 1 ${ex},${ey}`;
      };
      let a0 = -Math.PI * .9;
      [
        { key:"low", value:d.low, color:levelColor["低风险"] },
        { key:"mid", value:d.mid, color:levelColor["中风险"] },
        { key:"high", value:d.high, color:levelColor["高风险"] }
      ].forEach((seg, i) => {
        const a1 = a0 + (seg.value / total) * Math.PI * 1.8;
        group.append("path")
          .attr("class", `node-ring ${state.region === "all" || state.region === d.region ? "active" : ""}`)
          .attr("pathLength", 100)
          .attr("d", ringPath(ringRadius, a0, a1))
          .attr("stroke", seg.color)
          .attr("style", state.region === "all" || state.region === d.region ? `animation-delay:${0.5 + i * 0.18}s` : null);
        a0 = a1;
      });
    });

    g.append("circle")
      .attr("class", d => `node-core ${state.region === "all" || state.region === d.region ? "active" : ""}`)
      .attr("r", d => r(d.count))
      .attr("fill", d => colorRisk(d.score_mean))
      .attr("fill-opacity", .92);

    g.append("text")
      .attr("class", "node-label")
      .attr("text-anchor", "middle")
      .attr("y", d => -r(d.count) - 15)
      .text(d => d.region);

    g.append("text")
      .attr("class", "node-score")
      .attr("text-anchor", "middle")
      .attr("dy", ".35em")
      .text(d => fmt(d.score_mean));

    svg.append("rect").attr("class", "map-frame").attr("x", M.left).attr("y", M.top).attr("width", W-M.left-M.right).attr("height", H-M.top-M.bottom);

    const legend = svg.append("g").attr("transform", `translate(${M.left + 10},${H - 72})`);
    legend.append("rect").attr("width", 188).attr("height", 48).attr("rx", 8).attr("fill", "rgba(7,22,35,.78)").attr("stroke", "rgba(137,204,220,.22)");
    legend.append("text").attr("x", 10).attr("y", 18).attr("class", "axis-title").text("节点环: 低/中/高风险构成");
    ["低风险","中风险","高风险"].forEach((k, i) => {
      legend.append("circle").attr("cx", 16 + i * 58).attr("cy", 33).attr("r", 5).attr("fill", levelColor[k]);
      legend.append("text").attr("x", 25 + i * 58).attr("y", 37).attr("class", "axis-text").text(k.replace("风险",""));
    });
  }

  function drawOceanContext(svg, projection, W, H, M) {
    const bath = [
      [[109,20.5],[112,21.4],[116,22.1],[120,23.1],[124,24.7]],
      [[110,24.5],[114,25.4],[118,26.7],[122,28.6],[125.5,30.4]],
      [[111,29.2],[114,30.4],[118,31.7],[122.5,33.1],[125.5,35.0]],
      [[113.5,36.2],[117,36.8],[121,37.5],[124.5,38.8]]
    ];
    const currents = [
      [[120.2,22.2],[121.3,24.1],[122.2,26.3],[122.6,28.8],[123.0,31.2]],
      [[117.0,20.4],[118.8,22.2],[120.4,24.6],[121.4,27.0]],
      [[122.5,32.5],[121.4,34.2],[120.2,36.0],[119.0,38.2]]
    ];
    const line = d3.line().x(d => projection(d)[0]).y(d => projection(d)[1]).curve(d3.curveCatmullRom.alpha(.5));
    svg.append("g").selectAll("path.bath-line")
      .data(bath)
      .join("path")
      .attr("class", "bath-line")
      .attr("d", line);
    svg.append("g").selectAll("path.current-line")
      .data(currents)
      .join("path")
      .attr("class", "current-line")
      .attr("stroke", "url(#current-grad)")
      .attr("d", line);
    const labels = [
      { text:"BOHAI SEA", pos:[119.4,39.3] },
      { text:"YELLOW SEA", pos:[123.2,35.2] },
      { text:"EAST CHINA SEA", pos:[123.5,28.1] },
      { text:"NORTHERN SOUTH CHINA SEA", pos:[114.2,21.1] }
    ];
    svg.append("g").selectAll("text.sea-label")
      .data(labels)
      .join("text")
      .attr("class", "sea-label")
      .attr("x", d => projection(d.pos)[0])
      .attr("y", d => projection(d.pos)[1])
      .attr("text-anchor", "middle")
      .attr("transform", d => `rotate(-12 ${projection(d.pos)[0]} ${projection(d.pos)[1]})`)
      .text(d => d.text);
    svg.append("rect").attr("class", "map-frame").attr("x", M.left).attr("y", M.top).attr("width", W-M.left-M.right).attr("height", H-M.top-M.bottom);
  }

  function curved(a, b) {
    const mx = (a.x + b.x) / 2;
    const my = (a.y + b.y) / 2 - Math.min(58, Math.hypot(a.x-b.x, a.y-b.y) * .18);
    return `M${a.x},${a.y} Q${mx},${my} ${b.x},${b.y}`;
  }

  function drawMatrix() {
    const svg = d3.select("#risk-matrix");
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.selectAll("*").remove();

    const visibleDepths = ["0-10m", "50-100m", "200m"].filter(depth => depths.includes(depth));
    const M = { top:18, right:22, bottom:30, left:86 };
    const iw = W - M.left - M.right;
    const ih = H - M.top - M.bottom;
    const rowGap = ih / Math.max(1, regions.length);
    const x = d3.scalePoint().domain(months).range([0, iw]).padding(.42);
    const y = d3.scalePoint().domain(regions).range([rowGap * .42, ih - rowGap * .42]);
    const depthY = visibleDepths.length > 1
      ? d3.scalePoint().domain(visibleDepths).range([-rowGap * .30, rowGap * .30])
      : () => 0;
    const depthColor = d3.scaleOrdinal()
      .domain(depths)
      .range(["#55d7ff", "#f0c45c", "#ff6a4a", "#8ff0cf", "#aa7cc6"]);

    const cells = [];
    regions.forEach(region => {
      months.forEach(month => {
        visibleDepths.forEach(depth => {
          const s = summarize(filterRecords({ region, month, depth }));
          cells.push({
            region,
            month,
            depth,
            count:s.count,
            high_count:s.high,
            risk_mean:s.score_mean,
            x:x(month),
            y:y(region) + depthY(depth)
          });
        });
      });
    });

    const maxRisk = d3.max(cells, d => d.risk_mean) || 4;
    const thickness = d3.scaleSqrt()
      .domain([0, Math.max(4, maxRisk)])
      .range([Math.max(2.4, rowGap * .035), Math.max(8, rowGap * .16)]);
    const hotSize = d3.scaleSqrt()
      .domain([0, d3.max(cells, d => d.high_count) || 1])
      .range([1.5, 4.4]);
    const g = svg.append("g").attr("transform", `translate(${M.left},${M.top})`);

    const defs = svg.append("defs");
    const glow = defs.append("filter").attr("id", "risk-flow-glow").attr("x", "-65%").attr("y", "-90%").attr("width", "230%").attr("height", "280%");
    glow.append("feGaussianBlur").attr("stdDeviation", "5.6").attr("result", "blur");
    glow.append("feMerge")
      .selectAll("feMergeNode")
      .data(["blur", "SourceGraphic"])
      .join("feMergeNode")
      .attr("in", d => d);

    g.append("rect")
      .attr("class", "flow-plot-bg")
      .attr("x", -8)
      .attr("y", -10)
      .attr("width", iw + 16)
      .attr("height", ih + 18)
      .attr("rx", 14);

    const rangeMonths = selectedMonths();
    const rangeStep = x.step ? x.step() : 0;
    const rangeLeft = Math.max(-8, x(rangeMonths[0]) - rangeStep * .5);
    const rangeRight = Math.min(iw + 8, x(rangeMonths[rangeMonths.length - 1]) + rangeStep * .5);
    g.append("rect")
      .attr("class", "flow-range-window")
      .attr("x", rangeLeft)
      .attr("y", -8)
      .attr("width", Math.max(8, rangeRight - rangeLeft))
      .attr("height", ih + 14)
      .attr("rx", 10);

    g.selectAll("line.flow-month-grid")
      .data(months.filter((_, i) => i % 6 === 0))
      .join("line")
      .attr("class", "flow-month-grid")
      .attr("x1", d => x(d))
      .attr("x2", d => x(d))
      .attr("y1", -6)
      .attr("y2", ih + 6);

    g.selectAll("line.flow-row-base")
      .data(regions)
      .join("line")
      .attr("class", "flow-row-base")
      .attr("x1", 0)
      .attr("x2", iw)
      .attr("y1", d => y(d))
      .attr("y2", d => y(d));

    const area = d3.area()
      .curve(d3.curveCatmullRom.alpha(.55))
      .x(d => d.x)
      .y0(d => d.y - thickness(d.risk_mean))
      .y1(d => d.y + thickness(d.risk_mean));
    const line = d3.line()
      .curve(d3.curveCatmullRom.alpha(.55))
      .x(d => d.x)
      .y(d => d.y);

    const bands = regions.flatMap(region => visibleDepths.map(depth => ({
      region,
      depth,
      values:cells.filter(d => d.region === region && d.depth === depth)
    })));

    const bandG = g.append("g").selectAll("g.flow-band-group")
      .data(bands)
      .join("g")
      .attr("class", "flow-band-group");

    bandG.append("path")
      .attr("class", "flow-band")
      .attr("fill", d => depthColor(d.depth))
      .attr("d", d => area(d.values));

    bandG.append("path")
      .attr("class", "flow-spine")
      .attr("stroke", d => depthColor(d.depth))
      .attr("d", d => line(d.values));

    const sel = currentSelection();
    const haloCells = cells.filter(d => d.high_count > 1 && d.risk_mean >= 2.05);
    g.append("g").selectAll("circle.flow-halo")
      .data(haloCells.flatMap(d => [0, 1].map(pulse => ({ ...d, pulse }))))
      .join("circle")
      .attr("class", d => `flow-halo pulse-${d.pulse}`)
      .attr("cx", d => d.x)
      .attr("cy", d => d.y)
      .attr("r", d => hotSize(d.high_count) + 2.8 + d.pulse * 1.2)
      .attr("fill", "none")
      .attr("stroke", d => colorRisk(d.risk_mean));

    g.append("g").selectAll("circle.flow-knot")
      .data(cells)
      .join("circle")
      .attr("class", d => {
        const active = sel.region !== "all" && sel.region === d.region && sel.month === d.month && sel.depth === d.depth;
        return `flow-knot ${active ? "active" : ""}`;
      })
      .attr("cx", d => d.x)
      .attr("cy", d => d.y)
      .attr("r", d => 1.35 + Math.min(2.65, thickness(d.risk_mean) * .30))
      .attr("fill", d => colorRisk(d.risk_mean))
      .on("click", (_, d) => setSelection(
        { region:d.region, month:d.month, depth:d.depth },
        { preserveDepth:true }
      ))
      .on("mousemove", (ev, d) => showTip(ev, matrixTip({
        row:{ region:d.region, depth:d.depth },
        month:d.month,
        data:d
      })))
      .on("mouseout", hideTip);

    g.append("line")
      .attr("class", "month-cursor flow-cursor")
      .attr("x1", x(state.month))
      .attr("x2", x(state.month))
      .attr("y1", -11)
      .attr("y2", ih + 11);

    const labels = g.append("g");
    labels.selectAll("text")
      .data(regions)
      .join("text")
      .attr("class", d => `row-label flow-row-label ${state.region === d ? "active" : ""}`)
      .attr("x", -10)
      .attr("y", d => y(d) + 4)
      .attr("text-anchor", "end")
      .text(d => d)
      .on("dblclick", (_, d) => { state.region = d; renderAll(); });

    const axis = g.append("g").attr("transform", `translate(0,${ih + 18})`);
    axis.selectAll("text")
      .data(months.filter((_, i) => i % 3 === 0))
      .join("text")
      .attr("class", "axis-text")
      .attr("x", d => x(d))
      .attr("text-anchor", "middle")
      .text(d => d.slice(2));

  }

  function drawTime() {
    const svg = d3.select("#risk-time");
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.selectAll("*").remove();
    const M = { top:18, right:42, bottom:31, left:42 };
    const iw = W - M.left - M.right;
    const ih = H - M.top - M.bottom;
    const all = months.map(month => ({ month, ...summarize(filterRecords({ month, depth:state.depth, region:state.timeRegion })) }));
    const x = d3.scaleBand().domain(months).range([0, iw]).padding(.18);
    const yCount = d3.scaleLinear().domain([0, d3.max(all, d => d.count) || 1]).nice().range([ih, 0]);
    const yRisk = d3.scaleLinear().domain([0, d3.max(all, d => d.score_mean) || 4]).nice().range([ih, 0]);
    const g = svg.append("g").attr("transform", `translate(${M.left},${M.top})`);

    const rangeMonths = selectedMonths();
    const rangeStartX = x(rangeMonths[0]);
    const rangeEndX = x(rangeMonths[rangeMonths.length - 1]) + x.bandwidth();
    g.append("rect")
      .attr("class", "time-range-window")
      .attr("x", rangeStartX)
      .attr("y", 0)
      .attr("width", Math.max(x.bandwidth(), rangeEndX - rangeStartX))
      .attr("height", ih)
      .attr("rx", 6);

    g.selectAll("line.grid").data(yCount.ticks(4)).join("line")
      .attr("class", "grid-line")
      .attr("x1", 0).attr("x2", iw).attr("y1", d => yCount(d)).attr("y2", d => yCount(d));

    const stack = d3.stack().keys(["low", "mid", "high"])(all);
    const cls = { low:"time-bar-low", mid:"time-bar-mid", high:"time-bar-high" };
    g.selectAll("g.stack").data(stack).join("g")
      .attr("class", d => cls[d.key])
      .selectAll("rect").data(d => d.map(v => ({ ...v, key:d.key }))).join("rect")
      .attr("x", d => x(d.data.month))
      .attr("y", d => yCount(d[1]))
      .attr("height", d => Math.max(0, yCount(d[0]) - yCount(d[1])))
      .attr("width", x.bandwidth())
      .attr("rx", 2)
      .on("click", (_, d) => setSelection({ region:state.timeRegion, month:d.data.month, depth:state.depth }));

    const line = d3.line().x(d => x(d.month) + x.bandwidth()/2).y(d => yRisk(d.score_mean)).curve(d3.curveCatmullRom.alpha(.5));
    const linePath = g.append("path").datum(all).attr("class", "risk-line").attr("d", line);
    const pathNode = linePath.node();
    if (pathNode) {
      const len = pathNode.getTotalLength();
      linePath
        .attr("stroke-dasharray", len)
        .attr("stroke-dashoffset", len)
        .transition()
        .duration(900)
        .ease(d3.easeCubicOut)
        .attr("stroke-dashoffset", 0);
    }
    g.selectAll("circle.risk-point").data(all).join("circle")
      .attr("class", d => `risk-point ${d.month === state.month ? "active" : ""}`)
      .attr("cx", d => x(d.month) + x.bandwidth()/2)
      .attr("cy", d => yRisk(d.score_mean))
      .attr("r", 0)
      .on("click", (_, d) => setSelection({ region:state.timeRegion, month:d.month, depth:state.depth }))
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.month}</div><div class="tt-row"><span>算法</span><b>${algorithmNames[state.algorithm].replace("法","")}</b></div><div class="tt-row"><span>平均风险</span><b>${fmt(d.score_mean)}</b></div><div class="tt-row"><span>高风险</span><b>${d.high}</b></div>`))
      .on("mouseout", hideTip);

    g.selectAll("circle.risk-point")
      .transition()
      .delay((_, i) => 180 + i * 28)
      .duration(420)
      .ease(d3.easeBackOut.overshoot(1.7))
      .attr("r", d => d.month === state.month ? 4.6 : 3);

    g.append("line").attr("class", "month-cursor")
      .attr("x1", x(state.month) + x.bandwidth()/2).attr("x2", x(state.month) + x.bandwidth()/2)
      .attr("y1", -6).attr("y2", ih + 4);

    g.selectAll("text.xt").data(months.filter((_, i) => i % 3 === 0)).join("text")
      .attr("class", "axis-text").attr("x", d => x(d)+x.bandwidth()/2).attr("y", ih+18)
      .attr("text-anchor", "middle").text(d => d.slice(2));
    g.selectAll("text.yt").data(yCount.ticks(4)).join("text")
      .attr("class", "axis-text").attr("x", -7).attr("y", d => yCount(d)+3).attr("text-anchor", "end").text(d => d);
    g.append("text").attr("class", "axis-title").attr("x", 0).attr("y", -6).text("记录数");
    g.append("text").attr("class", "axis-title").attr("x", iw + 6).attr("y", 8).text("评分");
  }

  function drawDetail() {
    const sel = currentSelection();
    const list = filterRecords(sel);
    const s = summarize(list);
    const regionAll = summarize(filterRecords({ region:sel.region }));
    const regionLabel = sel.region === "all" ? "全部海域" : sel.region;
    const depthLabel = sel.depth === "all" ? "全部深度" : sel.depth;
    d3.select("#detail-sub").text(`${regionLabel} / ${periodLabel()} / ${depthLabel}`);
    drawDetailOptions();
    const stage = d3.select("#detail-stage");
    stage.html("");
    if (!state.detailMode) {
      stage.append("div")
        .attr("class", "empty-detail")
        .html("请选择上方四个诊断模块之一<br>单个模块会在这里展开，避免多个小图挤在一起。");
    } else if (state.detailMode === "diagnosis") {
      const countMax = Math.max(1, s.count, d3.max(regions.map(region => summarize(
        filterRecords(periodFilter({ region, depth:sel.depth }))
      ).count)) || 1);
      const countPct = clamp(s.count / countMax) * 100;
      const scorePct = clamp(s.score_mean / 4) * 100;
      const longPct = clamp(regionAll.score_mean / 4) * 100;
      const riskTotal = Math.max(1, s.low + s.mid + s.high);
      const lowPct = s.low / riskTotal * 100;
      const midPct = s.mid / riskTotal * 100;
      const highPct = s.high / riskTotal * 100;
      stage.append("div").attr("class", "diagnosis-card").html(`
        <div class="diag-overview">
          <div class="diag-side diag-left">
            <div class="diag-info-grid">
              <div class="diag-info-card"><span>地区</span><b>${regionLabel}</b></div>
              <div class="diag-info-card"><span>月份范围</span><b>${periodLabel()}</b></div>
              <div class="diag-info-card"><span>深度情况</span><b>${depthLabel}</b></div>
              <div class="diag-info-card"><span>算法</span><b>${algorithmNames[state.algorithm].replace("法","")}</b></div>
            </div>
            <div class="diag-note">${diagnosisSentence(sel, s, regionAll)}</div>
          </div>
          <div class="diag-side diag-right">
            <div class="diag-chart diag-count" style="--w:${countPct.toFixed(1)}%">
              <div class="diag-chart-head"><span>记录数</span><b>${intFmt(s.count)}</b></div>
              <div class="diag-meter"><i></i></div>
              <div class="diag-chart-foot">同时间范围最大 ${intFmt(countMax)} 条</div>
            </div>
            <div class="diag-chart diag-score" style="--w:${scorePct.toFixed(1)}%;--mark:${longPct.toFixed(1)}%">
              <div class="diag-chart-head"><span>平均风险评分</span><b>${fmt(s.score_mean)}</b></div>
              <div class="diag-meter"><i></i><em title="区域长期均值"></em></div>
              <div class="diag-scale"><span>0</span><span>2</span><span>4</span></div>
            </div>
            <div class="diag-chart diag-stack-card">
              <div class="diag-chart-head"><span>风险等级构成</span><b>${intFmt(riskTotal)}</b></div>
              <div class="diag-stack" aria-label="低中高风险比例">
                <i class="low" style="--w:${lowPct.toFixed(1)}%"></i>
                <i class="mid" style="--w:${midPct.toFixed(1)}%"></i>
                <i class="high" style="--w:${highPct.toFixed(1)}%"></i>
              </div>
              <div class="diag-stack-legend">
                <span><i class="low"></i>低 ${s.low}</span>
                <span><i class="mid"></i>中 ${s.mid}</span>
                <span><i class="high"></i>高 ${s.high}</span>
              </div>
            </div>
          </div>
        </div>
      `);
    } else if (state.detailMode === "pressure") {
      stage.append("div")
        .attr("class", "upset-scroll")
        .append("svg")
        .attr("id", "risk-upset");
      drawRiskUpSet(sel, list, "#risk-upset");
    } else if (state.detailMode === "modelRing") {
      hideTip();
      stage.append("button")
        .attr("class", "model-return")
        .attr("type", "button")
        .text("返回排序")
        .on("click", () => {
          hideTip();
          state.detailMode = "parallel";
          drawDetail();
        });
      stage.append("svg").attr("id", "model-ring");
      drawModelRing(sel, "#model-ring");
    } else if (state.detailMode === "models") {
      stage.append("svg").attr("id", "parallel-mini");
      drawParallelMini(sel, "#parallel-mini");
    } else if (state.detailMode === "parallel") {
      stage.append("svg").attr("id", "lineup-risk");
      drawRiskLineup(sel, "#lineup-risk");
    }
  }

  function drawDetailOptions() {
    const options = [
      { id:"diagnosis", title:"风险概览", tip:"展示当前选中海域、月份、深度和算法下的文字结论与关键数值，包括记录数、平均风险、高风险和中风险数量等。" },
      { id:"pressure", title:"风险交集模式", tip:"按当前算法先把记录分为高、中、低三个风险等级，再在每个等级内用 UpSet 交集矩阵展示低氧、酸化、营养盐和温盐异常的主要复合组合；记录数 5 及以内的交集已过滤。" },
      { id:"models", title:"海域高维轮廓", tip:"用平行坐标展示各海域在多项海洋环境指标上的综合轮廓，便于比较不同海域的风险结构差异。" },
      { id:"parallel", title:"海域风险排序", tip:"借鉴 LineUp 多属性排序图：每一行表示一个海域，小条形列展示平均风险、高风险占比、要素压力、算法一致性和记录覆盖，最右侧为加权综合排序。" }
    ];
    d3.select("#detail-options")
      .selectAll("button.detail-option")
      .data(options)
      .join("button")
      .attr("class", d => `detail-option ${(state.detailMode === d.id || (state.detailMode === "modelRing" && d.id === "parallel")) ? "active" : ""}`)
      .html(d => `<span class="detail-option-head"><b>${d.title}</b><span class="info-icon detail-info" data-tip="${d.tip}">i</span></span>`)
      .on("click", (_, d) => {
        state.detailMode = d.id;
        drawDetail();
      });
    d3.selectAll(".detail-info").on("click", ev => ev.stopPropagation());
  }

  function riskFactorsForRecord(d) {
    const sets = [];
    if ((+d.bgc_o2 || 0) < 225) sets.push("低氧");
    if ((+d.bgc_ph || 8.2) < 8.06) sets.push("酸化");
    if ((+d.bgc_no3 || 0) > 4.4 || (+d.bgc_po4 || 0) > .44) sets.push("营养盐");
    if (Math.abs((+d.phy_thetao || 18) - 18) > 5.2 || Math.abs((+d.phy_so || 32) - 32) > 2.1) sets.push("温盐异常");
    return sets;
  }

  function drawRiskUpSet(sel, list, target = "#risk-upset") {
    const svg = d3.select(target);
    const node = svg.node();
    const W = node.clientWidth;
    if (!W) return;
    svg.selectAll("*").remove();
    const setNames = ["低氧", "酸化", "营养盐", "温盐异常"];
    const levels = ["高风险", "中风险", "低风险"];
    const groups = new Map(levels.map(level => [level, new Map()]));
    list.forEach(d => {
      const r = riskForRecord(d);
      const levelGroups = groups.get(r.level) || groups.get("低风险");
      const sets = riskFactorsForRecord(d);
      const key = sets.length ? setNames.filter(s => sets.includes(s)).join("|") : "无显著因素";
      if (!levelGroups.has(key)) {
        levelGroups.set(key, { key, level:r.level, sets:new Set(sets), count:0, score:0 });
      }
      const g = levelGroups.get(key);
      g.count += 1;
      g.score += r.visual;
    });
    const sections = levels.map(level => {
      let rows = Array.from(groups.get(level).values())
        .map(d => ({ ...d, score:d.count ? d.score / d.count : 0 }))
        .filter(d => d.count > 5)
        .sort((a, b) => b.count - a.count || b.score - a.score);
      if (!rows.length) {
        rows = [{ key:"暂无超过5条的交集", level, sets:new Set(), count:0, score:0, empty:true }];
      }
      return { level, rows };
    });
    const allRows = sections.flatMap(d => d.rows);
    const rowH = 20;
    const headerH = 25;
    const sectionGap = 5;
    const sectionPad = 8;
    const bottom = 6;
    const sectionHeights = sections.map(section => section.rows.length * rowH + sectionPad);
    const baseContentH = 5 + headerH + d3.sum(sectionHeights) + sectionGap * (sections.length - 1) + bottom;
    const viewportH = node.parentElement ? node.parentElement.clientHeight : 0;
    const H = Math.max(baseContentH, viewportH);
    const top = 5 + Math.max(0, (H - baseContentH) / 2);
    svg.attr("height", H).style("height", `${H}px`);

    const outerPad = 18;
    const rankW = 24;
    const barGap = 24;
    const valueReserve = 34;
    const contentW = Math.max(260, W - outerPad * 2);
    const matrixW = Math.min(190, Math.max(132, contentW * .36));
    const barW = Math.max(48, contentW - rankW - matrixW - barGap - valueReserve);
    const usedW = rankW + matrixW + barGap + barW + valueReserve;
    const contentLeft = Math.max(outerPad, (W - usedW) / 2);
    const matrixLeft = contentLeft + rankW;
    const barX = matrixLeft + matrixW + barGap;
    const dotGap = matrixW / Math.max(1, setNames.length - 1);
    const maxCount = d3.max(allRows, d => d.count) || 1;
    const x = d3.scaleLinear().domain([0, maxCount]).range([0, barW]);

    setNames.forEach((name, i) => {
      svg.append("text")
        .attr("class", "upset-set-label")
        .attr("x", matrixLeft + i * dotGap)
        .attr("y", top + 12)
        .attr("text-anchor", "middle")
        .text(name);
    });
    svg.append("text").attr("class", "upset-set-label").attr("x", barX).attr("y", top + 12).text("记录数");

    let cursorY = top + headerH;
    sections.forEach((section, sectionIndex) => {
      const sectionH = sectionHeights[sectionIndex];
      const rowsHeight = rowH * section.rows.length;
      const rowsTop = cursorY + (sectionH - rowsHeight) / 2;
      svg.append("rect")
        .attr("class", `upset-section-bg level-${section.level === "高风险" ? "high" : section.level === "中风险" ? "mid" : "low"}`)
        .attr("x", 3)
        .attr("y", cursorY)
        .attr("width", W - 6)
        .attr("height", sectionH)
        .attr("rx", 7);

      const row = svg.selectAll(`g.upset-row-${section.level}`)
        .data(section.rows)
        .join("g")
        .attr("class", "upset-row")
        .attr("transform", (_, i) => `translate(0,${rowsTop + i * rowH})`)
        .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.level} · ${d.key}</div><div class="tt-row"><span>记录数</span><b>${d.count}</b></div><div class="tt-row"><span>平均风险</span><b>${fmt(d.score)}</b></div>`))
        .on("mouseout", hideTip);

      row.append("text")
        .attr("class", "upset-rank")
        .attr("x", contentLeft + 4)
        .attr("y", rowH * .64)
        .text((_, i) => i + 1);
      row.selectAll("circle.upset-dot")
        .data(d => setNames.map((name, i) => ({ name, i, on:d.sets.has(name), empty:d.empty })))
        .join("circle")
        .attr("class", d => `upset-dot ${d.on ? "on" : ""}`)
        .attr("cx", d => matrixLeft + d.i * dotGap)
        .attr("cy", rowH * .5)
        .attr("r", d => d.empty ? 0 : d.on ? 4.1 : 2.5);
      row.each(function (d) {
        const active = setNames.map((name, i) => d.sets.has(name) ? matrixLeft + i * dotGap : null).filter(v => v !== null);
        if (active.length > 1) {
          d3.select(this).append("line")
            .attr("class", "upset-connector")
            .attr("x1", d3.min(active))
            .attr("x2", d3.max(active))
            .attr("y1", rowH * .5)
            .attr("y2", rowH * .5)
            .lower();
        }
      });
      row.filter(d => d.empty)
        .append("text")
        .attr("class", "upset-empty")
        .attr("x", matrixLeft)
        .attr("y", rowH * .64)
        .text(d => d.key || "当前筛选下无记录");
      row.filter(d => !d.empty)
        .append("rect")
        .attr("class", "upset-bar")
        .attr("x", barX)
        .attr("y", rowH * .5 - 4.5)
        .attr("height", 9)
        .attr("rx", 5)
        .attr("fill", levelColor[section.level])
        .attr("width", 0)
        .transition().duration(560).ease(d3.easeCubicOut)
        .attr("width", d => x(d.count));
      row.filter(d => !d.empty)
        .append("text")
        .attr("class", "upset-value")
        .attr("x", d => Math.min(barX + x(d.count) + 5, W - outerPad))
        .attr("text-anchor", d => barX + x(d.count) + 5 > W - outerPad ? "end" : "start")
        .attr("y", rowH * .64)
        .text(d => d.count);

      cursorY += sectionH + sectionGap;
    });
  }

  function drawFactorBars(sel, list, target = "#factor-bars") {
    const svg = d3.select(target);
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.selectAll("*").remove();
    const pressures = pressureSummary(list);
    const M = { top:7, right:20, bottom:8, left:72 };
    const x = d3.scaleLinear().domain([0, 1]).range([0, W-M.left-M.right]);
    const y = d3.scaleBand().domain(pressures.map(d => d.name)).range([M.top, H-M.bottom]).padding(.22);
    const g = svg.append("g").attr("transform", `translate(${M.left},0)`);
    g.selectAll("rect").data(pressures).join("rect")
      .attr("class", d => `bar ${d.value > .66 ? "hot" : d.value > .36 ? "mid" : "low"}`)
      .attr("x", 0).attr("y", d => y(d.name))
      .attr("height", y.bandwidth()).attr("rx", 4)
      .attr("width", 0)
      .transition().duration(550)
      .attr("width", d => x(d.value));
    svg.append("g").selectAll("text.lbl").data(pressures).join("text")
      .attr("class", "axis-text").attr("x", M.left - 8).attr("y", d => y(d.name)+y.bandwidth()*.66)
      .attr("text-anchor", "end").text(d => d.name);
    g.selectAll("text.val").data(pressures).join("text")
      .attr("class", "axis-text").attr("x", d => x(d.value)+5).attr("y", d => y(d.name)+y.bandwidth()*.66)
      .text(d => fmt(d.value));
  }

  function drawModelRing(sel, target = "#model-ring") {
    const svg = d3.select(target);
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.selectAll("*").remove();

    const con = RISK.consensus.find(d => d.region === sel.region) || RISK.consensus[0];
    const entries = Object.entries(con.algorithm_levels || {});
    const R = Math.min(W, H) * .34;
    const cx = W * .37;
    const cy = H * .52;
    const pie = d3.pie().value(1).sort(null)(entries);
    const arc = d3.arc().innerRadius(R * .58).outerRadius(R);
    const names = { expert_rule:"规则", entropy_topsis:"TOPSIS", robust_anomaly:"异常", kmeans_layer:"聚类" };
    const g = svg.append("g").attr("transform", `translate(${cx},${cy}) rotate(-95)`);
    g.transition()
      .duration(1150)
      .ease(d3.easeCubicOut)
      .attr("transform", `translate(${cx},${cy}) rotate(0)`);
    g.selectAll("path").data(pie).join("path")
      .attr("d", d => arc({ ...d, endAngle:d.startAngle }))
      .attr("fill", d => levelColor[d.data[1]] || "#9aa5b2")
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .transition()
      .delay((_, i) => i * 230)
      .duration(430)
      .ease(d3.easeCubicOut)
      .attrTween("d", d => {
        const end = d3.interpolate(d.startAngle, d.endAngle);
        return t => arc({ ...d, endAngle:end(t) });
      });
    g.append("text")
      .attr("text-anchor", "middle")
      .attr("y", -3)
      .attr("class", "model-score")
      .attr("font-size", 20)
      .attr("font-weight", 700)
      .attr("opacity", 0)
      .text(Math.round((con.agreement || 0) * 100) + "%")
      .transition()
      .delay(900)
      .duration(280)
      .attr("opacity", 1);
    g.append("text")
      .attr("text-anchor", "middle")
      .attr("y", 15)
      .attr("class", "ring-label")
      .attr("opacity", 0)
      .text("一致度")
      .transition()
      .delay(980)
      .duration(260)
      .attr("opacity", 1);

    const legendGap = 22;
    const legendHeight = Math.max(0, (entries.length - 1) * legendGap);
    const lg = svg.append("g").attr("transform", `translate(${W*.66},${Math.max(18, (H - legendHeight) / 2)})`);
    entries.forEach((d, i) => {
      lg.append("circle")
        .attr("cx", 0)
        .attr("cy", i * legendGap)
        .attr("r", 0)
        .attr("fill", levelColor[d[1]] || "#9aa5b2")
        .transition()
        .delay(220 + i * 230)
        .duration(220)
        .attr("r", 6);
      lg.append("text")
        .attr("x", 11)
        .attr("y", i * legendGap + 4)
        .attr("class", "axis-text model-legend")
        .attr("opacity", 0)
        .text(`${names[d[0]] || d[0]} ${d[1].replace("风险","")}`)
        .transition()
        .delay(260 + i * 230)
        .duration(220)
        .attr("opacity", 1);
    });
  }

  function drawParallelMini(sel, target = "#parallel-mini") {
    const svg = d3.select(target);
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H || !CORR.parallel) return;
    svg.selectAll("*").remove();
    const metrics = ["溶解氧", "叶绿素", "硝酸盐", "磷酸盐", "海表温度", "盐度", "risk_score"];
    const M = { top:10, right:12, bottom:18, left:16 };
    const x = d3.scalePoint().domain(metrics).range([M.left, W - M.right]);
    const scales = {};
    metrics.forEach(m => {
      const ext = d3.extent(CORR.parallel, d => +d[m]);
      scales[m] = d3.scaleLinear().domain(ext[0] === ext[1] ? [0, 1] : ext).range([H-M.bottom, M.top]);
    });
    metrics.forEach(m => {
      svg.append("line").attr("class", "grid-line").attr("x1", x(m)).attr("x2", x(m)).attr("y1", M.top).attr("y2", H-M.bottom);
      svg.append("text").attr("class", "axis-text").attr("x", x(m)).attr("y", H-4).attr("text-anchor", "middle").text(m === "risk_score" ? "风险" : m.slice(0,2));
    });
    CORR.parallel.forEach((row, i) => {
      const line = d3.line()
        .x(m => x(m))
        .y(m => scales[m](+row[m]))
        .curve(d3.curveLinear);
      const p = svg.append("path")
        .datum(metrics)
        .attr("class", `pc-line ${row.region === sel.region ? "active" : ""}`)
        .attr("stroke", row.region === sel.region ? "var(--accent)" : regionColor(row.region))
        .attr("d", line);
      const len = p.node().getTotalLength();
      p.attr("stroke-dasharray", len)
        .attr("stroke-dashoffset", len)
        .transition()
        .delay(i * 90)
        .duration(row.region === sel.region ? 850 : 620)
        .ease(d3.easeCubicOut)
        .attr("stroke-dashoffset", 0);
    });
  }

  function drawRiskLineup(sel, target = "#lineup-risk") {
    const svg = d3.select(target);
    const node = svg.node();
    const W = node.clientWidth;
    const H = node.clientHeight;
    if (!W || !H) return;
    svg.selectAll("*").remove();
    const countMax = Math.max(1, d3.max(regions.map(region =>
      summarize(filterRecords(periodFilter({ region, depth:sel.depth }))).count
    )) || 1);
    const rows = regions.map(region => {
      const list = filterRecords(periodFilter({ region, depth:sel.depth }));
      const s = summarize(list);
      const pressure = d3.mean(pressureSummary(list).slice(0, 3), d => d.value) || 0;
      const consensus = RISK.consensus.find(d => d.region === region);
      const high = s.count ? s.high / s.count : 0;
      const attrs = [
        { key:"risk", label:"平均风险", value:clamp(s.score_mean / 4), color:colorRisk(s.score_mean) },
        { key:"high", label:"高危占比", value:high, color:levelColor["高风险"] },
        { key:"factor", label:"要素压力", value:pressure, color:"#55d7ff" },
        { key:"agree", label:"算法一致性", value:clamp(consensus ? consensus.agreement : 0), color:"#8ff0cf" },
        { key:"cover", label:"记录覆盖", value:clamp(s.count / countMax), color:"#66ccee" }
      ];
      const total = clamp(attrs[0].value * .36 + attrs[1].value * .25 + attrs[2].value * .17 + attrs[3].value * .12 + attrs[4].value * .10);
      return { region, summary:s, attrs, total };
    }).sort((a, b) => b.total - a.total).map((d, i) => ({ ...d, rank:i + 1 }));

    const M = { top:0, right:10, bottom:0, left:86 };
    const rowH = Math.min(32, (H - 28) / rows.length);
    const headerH = 20;
    const contentH = headerH + rows.length * rowH;
    const top = Math.max(8, (H - contentH) / 2);
    const totalW = Math.max(50, Math.min(78, W * .18));
    const gap = 6;
    const attrCount = rows[0]?.attrs.length || 1;
    const attrW = Math.max(20, (W - M.left - totalW - M.right - gap * attrCount - 8) / attrCount);
    const attrLeft = M.left;
    const totalX = attrLeft + attrCount * (attrW + gap) + 8;

    svg.selectAll("text.attr-head")
      .data(rows[0]?.attrs || [])
      .join("text")
      .attr("class", "lineup-head")
      .attr("x", (_, i) => attrLeft + i * (attrW + gap) + attrW / 2)
      .attr("y", top + 13)
      .attr("text-anchor", "middle")
      .text(d => d.label);
    svg.append("text").attr("class", "lineup-head").attr("x", totalX + totalW / 2).attr("y", top + 13).attr("text-anchor", "middle").text("综合排序");

    const g = svg.selectAll("g.lineup-row")
      .data(rows)
      .join("g")
      .attr("class", d => `lineup-row ${sel.region === d.region ? "active" : ""}`)
      .attr("transform", (d, i) => `translate(0,${top + headerH + i * rowH})`)
      .on("click", (_, d) => setSelection({ region:d.region, month:sel.month, depth:sel.depth }))
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">#${d.rank} ${d.region}</div><div class="tt-row"><span>综合排序值</span><b>${fmt(d.total)}</b></div><div class="tt-row"><span>平均风险</span><b>${fmt(d.summary.score_mean)}</b></div><div class="tt-row"><span>高风险</span><b>${d.summary.high}</b></div>`))
      .on("mouseout", hideTip);

    g.append("rect")
      .attr("class", "lineup-row-bg")
      .attr("x", 2)
      .attr("y", 1)
      .attr("width", W - 4)
      .attr("height", Math.max(18, rowH - 5))
      .attr("rx", 5);
    g.append("text").attr("class", "lineup-rank").attr("x", 8).attr("y", rowH * .66).text(d => d.rank);
    g.append("text").attr("class", "lineup-name").attr("x", 27).attr("y", rowH * .66).text(d => d.region);

    const cells = g.selectAll("g.lineup-cell")
      .data(d => d.attrs.map((a, i) => ({ ...a, col:i, region:d.region })))
      .join("g")
      .attr("class", d => `lineup-cell ${d.key === "agree" ? "agree-cell" : ""}`)
      .attr("transform", d => `translate(${attrLeft + d.col * (attrW + gap)},${rowH * .5 - 4})`)
      .on("click", (event, d) => {
        if (d.key !== "agree") return;
        event.stopPropagation();
        state.region = d.region;
        state.selected = { region:d.region, month:sel.month, depth:sel.depth };
        state.detailMode = "modelRing";
        hideTip();
        updateControls();
        renderAll();
      });
    cells.append("rect").attr("class", "lineup-track").attr("width", attrW).attr("height", 7).attr("rx", 4);
    cells.append("rect")
      .attr("class", "lineup-bar")
      .attr("height", 7)
      .attr("rx", 4)
      .attr("fill", d => d.color)
      .attr("width", 0)
      .transition()
      .delay((d, i) => 120 + i * 16)
      .duration(420)
      .attr("width", d => attrW * d.value);

    g.append("rect").attr("class", "lineup-track total").attr("x", totalX).attr("y", rowH * .5 - 4).attr("width", totalW).attr("height", 8).attr("rx", 4);
    g.append("rect")
      .attr("class", "lineup-total")
      .attr("x", totalX)
      .attr("y", rowH * .5 - 4)
      .attr("height", 8)
      .attr("rx", 4)
      .attr("width", 0)
      .transition()
      .delay((_, i) => 180 + i * 45)
      .duration(520)
      .attr("width", d => totalW * d.total);
  }

  function pressureSummary(list) {
    if (!list.length) return [
      { name:"低氧", value:0 }, { name:"藻华", value:0 }, { name:"营养盐", value:0 },
      { name:"酸碱", value:0 }, { name:"温盐", value:0 }, { name:"动力", value:0 }
    ];
    const avg = k => d3.mean(list, d => +d[k]);
    const vals = {
      "低氧": clamp((260 - avg("bgc_o2")) / 100),
      "藻华": clamp(avg("bgc_chl") / 2.2),
      "营养盐": clamp((avg("bgc_no3") / 6.6 + avg("bgc_po4") / .66) / 2),
      "酸碱": clamp(Math.abs(avg("bgc_ph") - 8.15) / .22),
      "温盐": clamp((Math.abs(avg("phy_thetao") - 18) / 14 + Math.abs(avg("phy_so") - 32) / 5) / 2),
      "动力": clamp(avg("current_speed") / .18)
    };
    return Object.entries(vals).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value);
  }

  function clamp(v) { return Math.max(0, Math.min(1, v || 0)); }

  function diagnosisSentence(sel, s, all) {
    const top = pressureSummary(filterRecords(sel))[0];
    const delta = s.score_mean - all.score_mean;
    const trend = delta > .3 ? "显著高于" : delta < -.3 ? "低于" : "接近";
    const regionLabel = sel.region === "all" ? "全部海域" : sel.region;
    const depthLabel = sel.depth === "all" ? "全部深度" : sel.depth;
    return `${regionLabel} ${periodLabel()} 的 ${depthLabel} 风险 ${trend}当前对照水平，主导压力为${top ? top.name : "暂无"}。建议从风险流带继续定位海域、月份与深度，并在网络地图观察相邻海域的联动关系。`;
  }

  function tipForSummary(region, d) {
    return `<div class="tt-title">${region}</div>
      <div class="tt-row"><span>记录数</span><b>${intFmt(d.count)}</b></div>
      <div class="tt-row"><span>平均风险</span><b>${fmt(d.score_mean)}</b></div>
      <div class="tt-row"><span>高风险</span><b>${d.high}</b></div>`;
  }

  function matrixTip(d) {
    const v = d.data || {};
    return `<div class="tt-title">${d.row.region} · ${d.row.depth}</div>
      <div class="tt-row"><span>月份</span><b>${d.month}</b></div>
      <div class="tt-row"><span>平均风险</span><b>${fmt(v.risk_mean || 0)}</b></div>
      <div class="tt-row"><span>高风险</span><b>${v.high_count || 0}</b></div>`;
  }

  function renderAll() {
    updateControls();
    drawMap();
    drawAnalysis();
    drawDetail();
  }

  function drawAnalysis() {
    const stage = d3.select("#analysis-stage");
    stage.html("");
    if (state.analysisMode === "matrix") {
      stage.append("svg").attr("id", "risk-matrix");
      drawMatrix();
    } else {
      stage.append("svg").attr("id", "risk-time");
      drawTime();
    }
  }

  function initTimeRegionSelect() {
    d3.select("#time-region-menu")
      .selectAll("button")
      .data([{ value:"all", label:"全部海域" }, ...regions.map(r => ({ value:r, label:r }))])
      .join("button")
      .attr("type", "button")
      .attr("data-region", d => d.value)
      .text(d => d.label)
      .on("click", (_, d) => {
        state.timeRegion = d.value;
        state.analysisMode = "time";
        d3.select("#time-split-wrap").classed("open", false);
        setSelection({ region:d.value, month:state.month, depth:state.depth });
      });
  }

  function startStopPlay() {
    state.playing = !state.playing;
    if (timer) clearInterval(timer);
    if (state.playing) {
      timer = setInterval(() => {
        const startIndex = Math.max(0, months.indexOf(state.monthStart));
        const endIndex = Math.max(startIndex, months.indexOf(state.monthEnd));
        const span = endIndex - startIndex;
        const nextStart = endIndex >= months.length - 1 ? 0 : startIndex + 1;
        const nextEnd = Math.min(months.length - 1, nextStart + span);
        state.monthStart = months[nextStart];
        state.monthEnd = months[nextEnd];
        state.month = state.monthEnd;
        if (state.selected) state.selected.month = state.month;
        renderAll();
      }, 900);
    }
    updateControls();
  }

  d3.selectAll("[data-depth]").on("click", function () {
    state.depth = this.dataset.depth;
    if (state.selected) state.selected.depth = state.depth;
    renderAll();
  });
  d3.select("#algorithm-select").on("change", function () {
    state.algorithm = this.value;
    renderAll();
  });
  function setMonthRange(startIndex, endIndex, focusIndex) {
    const start = Math.max(0, Math.min(startIndex, months.length - 1));
    const end = Math.max(start, Math.min(endIndex, months.length - 1));
    const focus = Math.max(start, Math.min(focusIndex, end));
    state.monthStart = months[start];
    state.monthEnd = months[end];
    state.month = months[focus];
    if (state.selected) state.selected.month = state.month;
    renderAll();
  }
  d3.select("#month-start-slider").on("input", function () {
    const start = +this.value;
    const currentEnd = +d3.select("#month-end-slider").property("value");
    const end = Math.max(start, currentEnd);
    setMonthRange(start, end, start);
  });
  d3.select("#month-end-slider").on("input", function () {
    const end = +this.value;
    const currentStart = +d3.select("#month-start-slider").property("value");
    const start = Math.min(currentStart, end);
    setMonthRange(start, end, end);
  });
  d3.selectAll("[data-analysis]").on("click", function () {
    state.analysisMode = this.dataset.analysis;
    renderAll();
  });
  d3.select("#time-region-toggle").on("click", (event) => {
    event.stopPropagation();
    const willOpen = !d3.select("#time-split-wrap").classed("open");
    d3.select("#time-split-wrap").classed("open", willOpen);
  });
  d3.select("body").on("click.timeMenu", () => d3.select("#time-split-wrap").classed("open", false));
  d3.select("#play-btn").on("click", startStopPlay);
  window.addEventListener("resize", () => renderAll());

  state.selected = null;
  state.region = "all";
  state.month = "2023-06";
  state.monthStart = "2023-01";
  state.monthEnd = "2023-06";
  state.depth = "all";
  state.algorithm = "expert_rule";
  state.detailMode = "diagnosis";
  initTimeRegionSelect();
  renderAll();
})();
