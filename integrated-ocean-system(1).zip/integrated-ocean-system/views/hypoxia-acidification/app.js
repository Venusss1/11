(function () {
  "use strict";

  const DATA = window.LAB3_DATA;
  const GEO = window.LAB3_GEOJSON;
  const AGG = window.LAB3_AGGREGATES;
  const CHI = window.CHI_DATA;
  const RISK = window.LAB3_RISK_MODELS || {};

  if (!DATA || !GEO || !AGG) {
    document.body.innerHTML = "<div style='padding:24px;font-family:sans-serif'>数据包未加载，请确认页面文件与 lab3-runtime-bundle.js 位于同一目录。</div>";
    return;
  }

  const records = DATA.records || [];
  const months = AGG.metadata.months || Array.from(new Set(records.map(d => d.month_label)));
  const regions = AGG.metadata.regions || Array.from(new Set(records.map(d => d.region_name)));
  const depths = AGG.metadata.depths || Array.from(new Set(records.map(d => d.depth_group)));
  const monthIndex = new Map(months.map((m, i) => [m, i]));

  const regionCenters = new Map();
  (RISK.consensus || []).forEach(d => regionCenters.set(d.region, d.center));
  GEO.features.forEach(f => {
    const p = f.properties || {};
    const name = p.region_name || p.region;
    if (!regionCenters.has(name)) {
      regionCenters.set(name, p.center || d3.geoCentroid(f));
    }
  });

  const state = {
    tensor: "compound",
    split: "month",
    selectedNodeId: "root",
    previousNodeId: null,
    patternChart: "temporal",
    month: months[0],
    monthStart: months[0],
    monthEnd: months[months.length - 1],
    focusRegion: null,
    focusDepth: null,
    drill:null,
    showDeviation: true,
    playing: false
  };
  let timer = null;
  let partition = { nodes:[], links:[], rootSummary:null };
  const chartSignatures = {
    spatial:null,
    depth:null
  };

  const fmt = d3.format(".2f");
  const intFmt = d3.format(",");
  const color = d3.scaleLinear()
    .domain([0, .25, .55, 1])
    .range(["#3f82b7", "#49b6bf", "#f0c76e", "#df5b52"])
    .interpolate(d3.interpolateRgb);
  const residualColor = value => residualTone(value, .45);
  const tooltip = d3.select("#tooltip");

  const tensorNames = {
    compound: "复合压力",
    hypoxia: "缺氧压力",
    acid: "酸化压力"
  };
  const tensorShortNames = {
    compound: "复合",
    hypoxia: "缺氧",
    acid: "酸化"
  };

  const splitNames = {
    month: "年份",
    region: "海域",
    depth: "深度"
  };

  const periods = [
    { id:"p2023", label:"2023 基线期", months:months.filter(m => m.startsWith("2023")) },
    { id:"p2024", label:"2024 转折期", months:months.filter(m => m.startsWith("2024")) },
    { id:"p2025", label:"2025 压力期", months:months.filter(m => m.startsWith("2025")) }
  ].filter(d => d.months.length);

  const regionGroups = regions.map((r, i) => ({
    id:`region_${i + 1}`,
    label:r,
    regions:[r]
  }));

  const depthGroups = depths.map(d => ({
    id:d.replace(/[^a-zA-Z0-9]/g, "_"),
    label:d,
    depths:[d]
  }));

  function clamp(v) {
    return Math.max(0, Math.min(1, Number.isFinite(v) ? v : 0));
  }

  function residualTone(value, extent = .45) {
    const safeExtent = Math.max(.001, Math.abs(extent) || .45);
    const amount = Math.pow(clamp(Math.abs(value || 0) / safeExtent), .72);
    const center = "#193344";
    return value >= 0
      ? d3.interpolateRgb(center, "#ff725e")(amount)
      : d3.interpolateRgb(center, "#64b8ff")(amount);
  }

  function mean(list, fn) {
    return d3.mean(list, fn) || 0;
  }

  function scoreRecord(d) {
    const o2 = +d.bgc_o2 || 0;
    const ph = +d.bgc_ph || 8.1;
    const no3 = +d.bgc_no3 || 0;
    const po4 = +d.bgc_po4 || 0;
    const temp = +d.phy_thetao || 0;
    const sal = +d.phy_so || 32;
    const hypoxia = clamp((265 - o2) / 115);
    const acid = clamp((8.16 - ph) / .24);
    const nutrient = clamp((no3 / 6.8 + po4 / .68) / 2);
    const thermal = clamp((Math.abs(temp - 18) / 14 + Math.abs(sal - 32) / 7) / 2);
    const compound = clamp(hypoxia * .44 + acid * .36 + nutrient * .13 + thermal * .07);
    return { hypoxia, acid, nutrient, thermal, compound };
  }

  function tensorValue(d) {
    return scoreRecord(d)[state.tensor] || 0;
  }

  function summary(list) {
    const out = {
      count:list.length,
      hypoxia:0,
      acid:0,
      nutrient:0,
      thermal:0,
      compound:0,
      o2:0,
      ph:0,
      monthCurve:months.map(m => ({ month:m, value:0, count:0 })),
      regionCurve:regions.map(r => ({ region:r, value:0, count:0 })),
      depthCurve:depths.map(d => ({ depth:d, value:0, count:0 }))
    };
    if (!list.length) return out;
    out.o2 = mean(list, d => +d.bgc_o2 || 0);
    out.ph = mean(list, d => +d.bgc_ph || 0);
    list.forEach(d => {
      const s = scoreRecord(d);
      out.hypoxia += s.hypoxia;
      out.acid += s.acid;
      out.nutrient += s.nutrient;
      out.thermal += s.thermal;
      out.compound += s.compound;
    });
    ["hypoxia", "acid", "nutrient", "thermal", "compound"].forEach(k => out[k] /= list.length);
    out.monthCurve = months.map(m => {
      const sub = list.filter(d => d.month_label === m);
      return { month:m, value:mean(sub, tensorValue), count:sub.length };
    });
    out.regionCurve = regions.map(r => {
      const sub = list.filter(d => d.region_name === r);
      return { region:r, value:mean(sub, tensorValue), count:sub.length };
    });
    out.depthCurve = depths.map(dep => {
      const sub = list.filter(d => d.depth_group === dep);
      return { depth:dep, value:mean(sub, tensorValue), count:sub.length };
    });
    return out;
  }

  function combineFilters(a = {}, b = {}) {
    return {
      months:b.months || a.months,
      regions:b.regions || a.regions,
      depths:b.depths || a.depths
    };
  }

  function matchesFilter(d, filters = {}) {
    if (filters.months && !filters.months.includes(d.month_label)) return false;
    if (filters.regions && !filters.regions.includes(d.region_name)) return false;
    if (filters.depths && !filters.depths.includes(d.depth_group)) return false;
    return true;
  }

  function subset(filters) {
    return records.filter(d => matchesFilter(d, filters));
  }

  function rangeIndexes() {
    const start = Math.max(0, monthIndex.get(state.monthStart) ?? 0);
    const end = Math.max(start, monthIndex.get(state.monthEnd) ?? months.length - 1);
    return [start, Math.min(end, months.length - 1)];
  }

  function selectedRangeMonths() {
    const [start, end] = rangeIndexes();
    return months.slice(start, end + 1);
  }

  function periodLabel(list = selectedRangeMonths()) {
    if (!list.length) return "全部时间";
    return list[0] === list[list.length - 1] ? list[0] : `${list[0]} — ${list[list.length - 1]}`;
  }

  function setTimeRange(monthList, anchor = "start") {
    const valid = (monthList || []).filter(m => monthIndex.has(m));
    if (!valid.length) return;
    const indexes = valid.map(m => monthIndex.get(m)).sort((a, b) => a - b);
    state.monthStart = months[indexes[0]];
    state.monthEnd = months[indexes[indexes.length - 1]];
    const range = selectedRangeMonths();
    if (!range.includes(state.month)) {
      state.month = anchor === "end" ? state.monthEnd : state.monthStart;
    }
  }

  function activeMonthsForNode(node = selectedNode()) {
    const range = selectedRangeMonths();
    const nodeMonths = node?.filters?.months || null;
    if (!nodeMonths?.length) return range;
    const overlap = range.filter(m => nodeMonths.includes(m));
    return overlap.length ? overlap : nodeMonths;
  }

  function filtersWithoutMonths(filters = {}) {
    return {
      regions:filters.regions,
      depths:filters.depths
    };
  }

  function effectiveNodeFilters(node = selectedNode()) {
    return {
      ...filtersWithoutMonths(node?.filters || {}),
      months:activeMonthsForNode(node)
    };
  }

  function yearLabelForMonths(monthList = []) {
    const years = Array.from(new Set(monthList.map(m => String(m).slice(0, 4)))).filter(Boolean);
    return years.length === 1 ? `${years[0]}年` : periodLabel(monthList);
  }

  function monthLabelForMonths(monthList = []) {
    if (!monthList.length || monthList.length === months.length) return "所有月份";
    if (monthList.length === 1) return `${Number(monthList[0].slice(5, 7))}月`;
    const years = Array.from(new Set(monthList.map(m => m.slice(0, 4))));
    if (years.length === 1) {
      const fullYear = months.filter(m => m.startsWith(years[0]));
      if (monthList.length === fullYear.length && monthList.every(m => fullYear.includes(m))) return "所有月份";
      return `${Number(monthList[0].slice(5, 7))}-${Number(monthList[monthList.length - 1].slice(5, 7))}月`;
    }
    return "范围月份";
  }

  function contextText(node = selectedNode()) {
    const filters = effectiveNodeFilters(node);
    const activeMonths = filters.months || months;
    const depthText = filters.depths?.length === 1 ? filters.depths[0] : "所有深度";
    const regionText = filters.regions?.length === 1 ? filters.regions[0] : "所有海域";
    const yearText = activeMonths.length === months.length ? "所有年份" : yearLabelForMonths(activeMonths);
    const monthText = monthLabelForMonths(activeMonths);
    return `${depthText} · ${yearText} · ${monthText} · ${regionText}`;
  }

  function drillConfigForNode(node) {
    if (!node || node.level !== 2 || state.drill) return null;
    const nodeMonths = node.filters?.months || [];
    if (!nodeMonths.length) return null;
    const yearText = yearLabelForMonths(nodeMonths);
    const sourceNodeId = node.id;
    if (state.split === "month" && node.filters?.depths?.length === 1) {
      const depth = node.filters.depths[0];
      return {
        source:"month-depth",
        sourceNodeId,
        label:`${yearText} · ${depth}`,
        months:nodeMonths,
        filters:{ months:nodeMonths, depths:[depth] },
        depth
      };
    }
    if (state.split === "region" && node.filters?.regions?.length === 1) {
      const region = node.filters.regions[0];
      return {
        source:"region-year",
        sourceNodeId,
        label:`${region} · ${yearText}`,
        months:nodeMonths,
        filters:{ months:nodeMonths, regions:[region] },
        region
      };
    }
    return null;
  }

  function enterDrill(node) {
    const config = drillConfigForNode(node);
    if (!config) return;
    state.drill = config;
    state.previousNodeId = null;
    state.selectedNodeId = "root";
    state.focusDepth = config.depth || null;
    state.focusRegion = config.region || null;
    setTimeRange(config.months);
    hideTip();
    render();
  }

  function leaveDrill() {
    const config = state.drill;
    if (!config) return;
    state.drill = null;
    state.previousNodeId = null;
    state.selectedNodeId = config.sourceNodeId || "root";
    state.focusDepth = config.depth || null;
    state.focusRegion = config.region || null;
    if (config.months?.length) setTimeRange(config.months);
    hideTip();
    render();
  }

  function reconcileSelectedNodeWithRange() {
    const node = selectedNode();
    const nodeMonths = node?.filters?.months || null;
    if (!nodeMonths?.length) return;
    const range = selectedRangeMonths();
    const hasOverlap = range.some(m => nodeMonths.includes(m));
    if (!hasOverlap) {
      state.previousNodeId = state.selectedNodeId;
      state.selectedNodeId = "root";
      if (node.filters?.regions?.length) state.focusRegion = null;
      if (node.filters?.depths?.length) state.focusDepth = null;
    }
  }

  function primaryDefs() {
    if (state.split === "region") {
      return regionGroups.map(d => ({ ...d, filters:{ regions:d.regions } }));
    }
    if (state.split === "depth") {
      return depthGroups.map(d => ({ ...d, filters:{ depths:d.depths } }));
    }
    return periods.map(d => ({ ...d, filters:{ months:d.months } }));
  }

  function secondaryDefsFor(parent) {
    if (state.split === "month") {
      return depthGroups.map(d => ({ ...d, filters:combineFilters(parent.filters, { depths:d.depths }) }));
    }
    if (state.split === "region") {
      return periods.map(d => ({ ...d, filters:combineFilters(parent.filters, { months:d.months }) }));
    }
    return regionGroups.map(d => ({ ...d, filters:combineFilters(parent.filters, { regions:d.regions }) }));
  }

  function buildPartition() {
    if (state.drill) {
      const drillFilters = state.drill.filters || {};
      const rootRecords = subset(drillFilters);
      const root = {
        id:"root",
        label:state.drill.label,
        level:0,
        parent:null,
        filters:drillFilters,
        records:rootRecords,
        summary:summary(rootRecords),
        drillRoot:true
      };
      const nodes = [root];
      const links = [];
      (state.drill.months || []).forEach((month, i) => {
        const filters = combineFilters(drillFilters, { months:[month] });
        const node = {
          id:`drill-month-${month.replace(/[^0-9]/g, "_")}`,
          label:month,
          level:1,
          parent:"root",
          filters,
          records:subset(filters),
          order:i,
          drillMonth:true
        };
        node.summary = summary(node.records);
        nodes.push(node);
        links.push({ source:"root", target:node.id, records:node.records });
      });
      if (!nodes.some(n => n.id === state.selectedNodeId)) {
        state.selectedNodeId = "root";
        state.previousNodeId = null;
      }
      partition = { nodes, links, rootSummary:root.summary };
      return partition;
    }

    const rootRecords = records;
    const root = {
      id:"root",
      label:"全部数据",
      level:0,
      parent:null,
      filters:{},
      records:rootRecords,
      summary:summary(rootRecords)
    };
    const nodes = [root];
    const links = [];
    primaryDefs().forEach((def, i) => {
      const node = {
        id:`${state.split}-${def.id}`,
        label:def.label,
        level:1,
        parent:"root",
        filters:def.filters,
        records:subset(def.filters)
      };
      node.summary = summary(node.records);
      nodes.push(node);
      links.push({ source:"root", target:node.id, records:node.records });
      secondaryDefsFor(def).forEach(sec => {
        const leaf = {
          id:`${node.id}-${sec.id}`,
          label:sec.label,
          level:2,
          parent:node.id,
          filters:sec.filters,
          records:subset(sec.filters)
        };
        leaf.summary = summary(leaf.records);
        nodes.push(leaf);
        links.push({ source:node.id, target:leaf.id, records:leaf.records });
      });
      node.order = i;
    });
    if (!nodes.some(n => n.id === state.selectedNodeId)) {
      state.selectedNodeId = "root";
      state.previousNodeId = null;
    }
    partition = { nodes, links, rootSummary:root.summary };
    return partition;
  }

  function selectedNode() {
    return partition.nodes.find(n => n.id === state.selectedNodeId) || partition.nodes[0];
  }

  function nodeValue(node) {
    return node.summary[state.tensor] || 0;
  }

  function nodeDeviation(node) {
    const root = partition.rootSummary;
    const diffs = node.summary.monthCurve.map((d, i) => Math.abs(d.value - root.monthCurve[i].value));
    return d3.mean(diffs) || 0;
  }

  function showTip(ev, html) {
    tooltip.html(html).style("opacity", 1);
    let x = ev.clientX + 14;
    let y = ev.clientY + 12;
    if (x > window.innerWidth - 320) x = ev.clientX - 320;
    if (y > window.innerHeight - 180) y = ev.clientY - 150;
    tooltip.style("left", `${x}px`).style("top", `${y}px`);
  }

  function hideTip() {
    tooltip.style("opacity", 0);
  }

  function setNode(id) {
    state.previousNodeId = state.selectedNodeId;
    state.selectedNodeId = id;
    const node = partition.nodes.find(d => d.id === id);
    if (state.drill && node?.drillMonth && node.filters?.months?.length) {
      state.month = node.filters.months[0];
    } else if ((state.split === "month" || state.split === "region") && node?.filters?.months?.length) {
      setTimeRange(node.filters.months);
    }
    if (state.split === "region" || state.split === "depth") {
      const nodeRegions = node?.filters?.regions || [];
      state.focusRegion = nodeRegions.length === 1 ? nodeRegions[0] : null;
    }
    if (state.split === "month" || state.split === "depth") {
      const nodeDepths = node?.filters?.depths || [];
      state.focusDepth = nodeDepths.length === 1 ? nodeDepths[0] : null;
    }
    hideTip();
    render();
  }

  function selectRegionFromMap(region) {
    const current = selectedNode();
    const currentRegion = current?.filters?.regions?.length === 1 ? current.filters.regions[0] : null;
    if (state.split === "region" && currentRegion !== region) {
      const target = partition.nodes.find(node =>
        node.level === 1 &&
        node.filters?.regions?.length === 1 &&
        node.filters.regions[0] === region
      );
      if (target) {
        state.focusRegion = region;
        setNode(target.id);
        return;
      }
    }
    if (state.split === "region") {
      state.focusRegion = region;
      render();
      return;
    }
    if (state.split === "depth") {
      const currentDepth = current?.filters?.depths?.length === 1 ? current.filters.depths[0] : null;
      if (currentDepth && currentRegion !== region) {
        const target = partition.nodes.find(node =>
          node.level === 2 &&
          node.filters?.depths?.includes(currentDepth) &&
          node.filters?.regions?.includes(region)
        );
        if (target) {
          state.focusRegion = region;
          setNode(target.id);
          return;
        }
      }
      if (currentDepth) {
        state.focusRegion = region;
        render();
        return;
      }
    }
    state.focusRegion = state.focusRegion === region ? null : region;
    render();
  }

  function updateControls() {
    d3.selectAll("[data-tensor]").classed("active", function () {
      return this.dataset.tensor === state.tensor;
    });
    d3.selectAll("[data-split]").classed("active", function () {
      return this.dataset.split === state.split;
    });
    d3.select("#deviation-toggle").property("checked", state.showDeviation);
    const [startIndex, endIndex] = rangeIndexes();
    const maxIndex = Math.max(1, months.length - 1);
    d3.select("#month-label").text(periodLabel());
    d3.select("#month-start-slider")
      .attr("max", months.length - 1)
      .property("value", startIndex);
    d3.select("#month-end-slider")
      .attr("max", months.length - 1)
      .property("value", endIndex);
    const rangeNode = d3.select(".dual-range").node();
    const rangeWidth = rangeNode?.clientWidth || 168;
    const thumbInset = 8;
    const trackWidth = Math.max(1, rangeWidth - thumbInset * 2);
    const startPx = thumbInset + trackWidth * (startIndex / maxIndex);
    const endPx = thumbInset + trackWidth * (endIndex / maxIndex);
    d3.select("#month-range-selection")
      .style("left", `${startPx}px`)
      .style("right", `${Math.max(0, rangeWidth - endPx)}px`);
    d3.select("#month-start-handle").style("--x", `${startPx}px`);
    d3.select("#month-end-handle").style("--x", `${endPx}px`);
    d3.select("#play-btn").classed("active", state.playing).text(state.playing ? "暂停" : "播放");
    d3.selectAll(".chart-tab").classed("active", function () {
      return this.dataset.chart === state.patternChart;
    });
    d3.selectAll("[data-chart-panel]").classed("active", function () {
      return this.dataset.chartPanel === state.patternChart;
    });
  }

  function drawPartitionTree() {
    const svg = d3.select("#partition-tree");
    svg.selectAll("*").remove();
    const nodeBox = svg.node().getBoundingClientRect();
    const W = Math.max(570, Math.round(nodeBox.width || 570));
    const H = Math.max(400, Math.round(nodeBox.height || 400));
    svg.attr("viewBox", `0 0 ${W} ${H}`);
    const defs = svg.append("defs");
    const grad = defs.append("linearGradient").attr("id", "nodeGrad").attr("x1", "0").attr("x2", "1");
    grad.append("stop").attr("offset", "0%").attr("stop-color", "rgba(85,215,255,.14)");
    grad.append("stop").attr("offset", "100%").attr("stop-color", "rgba(6,24,38,.92)");
    const signalGrad = defs.append("linearGradient")
      .attr("id", "treeSignalGrad")
      .attr("gradientUnits", "userSpaceOnUse")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", W)
      .attr("y2", 0);
    signalGrad.append("stop").attr("offset", "0%").attr("stop-color", "#75ffd8").attr("stop-opacity", .78);
    signalGrad.append("stop").attr("offset", "48%").attr("stop-color", "#55d7ff").attr("stop-opacity", 1);
    signalGrad.append("stop").attr("offset", "100%").attr("stop-color", "#d9faff").attr("stop-opacity", .9);

    const nodes = partition.nodes;
    const links = partition.links;
    const maxCount = d3.max(nodes, d => d.records.length) || 1;
    const drillCtaW = 50;
    const drillCtaGap = 3;
    const hasDrillCta = !state.drill && (state.split === "month" || state.split === "region");
    const ctaReserve = hasDrillCta ? drillCtaW + drillCtaGap + 2 : 0;
    const lineLeafMode = state.drill || state.split !== "month";
    const contentTop = lineLeafMode ? 6 : 4;
    const contentHeight = Math.max(240, H - contentTop);
    const root = nodes[0];
    root.w = 138;
    root.h = 52;
    root.x = 2;
    root.y = contentTop + contentHeight / 2 - root.h / 2;

    const primary = nodes.filter(d => d.level === 1);
    const leaves = nodes.filter(d => d.level === 2);
    const leafH = lineLeafMode ? 12 : (leaves.length > 12 ? 20 : 32);
    const leafScale = d3.scalePoint()
      .domain(leaves.map(d => d.id))
      .range([
        contentTop + (lineLeafMode ? 26 : 34),
        H - (lineLeafMode ? 22 : 26)
      ])
      .padding(0);
    leaves.forEach(d => {
      d.w = lineLeafMode ? 116 : 144;
      d.h = leafH;
      d.x = W - d.w - 6 - ctaReserve;
      d.y = leafScale(d.id) - d.h / 2;
    });
    primary.forEach(d => {
      if (state.drill) {
        d.w = 148;
        d.h = 15;
        const scale = d3.scalePoint()
          .domain(primary.map(p => p.id))
          .range([contentTop + 18, H - 20])
          .padding(.08);
        const availableGap = Math.max(58, W - root.x - root.w - d.w - 16);
        const drillGap = Math.max(58, availableGap * .52);
        d.x = Math.min(W - d.w - 12, root.x + root.w + drillGap);
        d.y = scale(d.id) - d.h / 2;
      } else {
        const childYs = leaves.filter(l => l.parent === d.id).map(l => l.y + l.h / 2);
        d.w = 150;
        d.h = 52;
        const minPrimaryX = root.x + root.w + 44;
        const maxPrimaryX = (leaves[0]?.x || W - 128 - ctaReserve) - d.w - 38;
        d.x = Math.min(maxPrimaryX, Math.max(minPrimaryX, W * .39 - d.w / 2));
        d.y = (d3.mean(childYs) || contentTop + contentHeight / 2) - d.h / 2;
      }
    });

    const byId = new Map(nodes.map(d => [d.id, d]));
    const active = selectedNode();
    const linkKey = d => `${d.source}->${d.target}`;
    const litNodes = new Set();
    const litLinks = new Set();
    const signalLinks = new Set();
    const revealLinks = new Set();
    const revealNodes = new Set();
    const nodeDelays = new Map();
    const linkDelays = new Map();
    const linkFor = (source, target) => links.find(d => d.source === source && d.target === target);
    const pathToRoot = node => {
      const path = [];
      let cur = node;
      while (cur) {
        path.unshift(cur);
        cur = byId.get(cur.parent);
      }
      return path;
    };
    const previous = byId.get(state.previousNodeId);
    const activePath = pathToRoot(active);
    const previousPath = previous ? pathToRoot(previous) : [];
    let revealStart = activePath[0] || root;
    if (previousPath.length) {
      for (let i = 0; i < Math.min(activePath.length, previousPath.length); i += 1) {
        if (activePath[i].id !== previousPath[i].id) break;
        revealStart = activePath[i];
      }
    }
    const markNodeReveal = (id, delay) => {
      if (!id) return;
      revealNodes.add(id);
      nodeDelays.set(id, delay);
    };
    const markSignalLink = link => {
      if (!link) return;
      const key = linkKey(link);
      litLinks.add(key);
      signalLinks.add(key);
    };
    const markLinkReveal = (link, delay) => {
      if (!link) return;
      const key = linkKey(link);
      litLinks.add(key);
      signalLinks.add(key);
      revealLinks.add(key);
      linkDelays.set(key, delay);
    };
    const revealAlongPath = path => {
      const startIndex = Math.max(0, path.findIndex(d => d.id === revealStart.id));
      markNodeReveal(path[startIndex].id, 0);
      for (let i = startIndex + 1; i < path.length; i += 1) {
        const step = i - startIndex - 1;
        markLinkReveal(linkFor(path[i - 1].id, path[i].id), 80 + step * 460);
        markNodeReveal(path[i].id, 500 + step * 460);
      }
    };
    if (active.level === 0) {
      nodes.forEach(d => litNodes.add(d.id));
      links.forEach(d => litLinks.add(linkKey(d)));
    } else if (active.level === 1) {
      litNodes.add(root.id);
      litNodes.add(active.id);
      markSignalLink(linkFor(root.id, active.id));
      revealAlongPath(activePath);
      links.forEach(d => {
        if (d.source === active.id) {
          litNodes.add(d.target);
          const activeDelay = nodeDelays.get(active.id) || 0;
          markLinkReveal(d, activeDelay + 40);
          markNodeReveal(d.target, activeDelay + 460);
        }
      });
    } else {
      const parent = byId.get(active.parent);
      activePath.forEach(d => litNodes.add(d.id));
      activePath.forEach((d, i) => {
        if (i > 0) markSignalLink(linkFor(activePath[i - 1].id, d.id));
      });
      if (parent) revealAlongPath(activePath);
    }
    const nodeClass = d => [
      "node",
      litNodes.has(d.id) ? "lit" : "dim",
      revealNodes.has(d.id) ? "reveal" : "",
      d.id === active.id ? "active" : ""
    ].filter(Boolean).join(" ");
    const linkClass = d => {
      const key = linkKey(d);
      return [
        "tree-link",
        litLinks.has(key) ? "lit" : "dim",
        signalLinks.has(key) ? "signal" : "",
        revealLinks.has(key) ? "active" : ""
      ].filter(Boolean).join(" ");
    };
    const linkDelay = d => {
      return linkDelays.get(linkKey(d)) || 0;
    };
    const nodeDelay = d => nodeDelays.get(d.id) || 0;

    svg.append("g")
      .selectAll("path")
      .data(links)
      .join("path")
      .attr("class", linkClass)
      .attr("stroke", d => signalLinks.has(linkKey(d)) ? "url(#treeSignalGrad)" : color(nodeValue(byId.get(d.target))))
      .attr("stroke-width", d => 2 + 14 * Math.sqrt(d.records.length / maxCount))
      .attr("pathLength", d => revealLinks.has(linkKey(d)) ? 1 : null)
      .style("--tree-delay", d => `${linkDelay(d)}ms`)
      .attr("d", d => {
        const s = byId.get(d.source);
        const t = byId.get(d.target);
        const rootLink = s.level === 0;
        const x1 = s.x + s.w;
        const y1 = rootLink ? s.y + s.h / 2 : s.y + s.h / 2;
        const x2 = t.x;
        const y2 = t.y + t.h / 2;
        const mx = state.drill ? x1 + Math.max(42, (x2 - x1) * .36) : (x1 + x2) / 2;
        return `M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`;
      });

    const g = svg.append("g")
      .selectAll("g.node")
      .data(nodes)
      .join("g")
      .attr("class", nodeClass)
      .style("--node-delay", d => `${nodeDelay(d)}ms`)
      .attr("transform", d => `translate(${d.x},${d.y})`)
      .on("click", (_, d) => setNode(d.id))
      .on("mousemove", (ev, d) => {
        showTip(ev, `<div class="tt-title">${d.label}</div>
          <div class="tt-row"><span>记录数</span><b>${intFmt(d.records.length)}</b></div>
          <div class="tt-row"><span>${tensorNames[state.tensor]}</span><b>${fmt(nodeValue(d))}</b></div>
          <div class="tt-row"><span>平均溶解氧</span><b>${fmt(d.summary.o2)}</b></div>
          <div class="tt-row"><span>平均 pH</span><b>${fmt(d.summary.ph)}</b></div>`);
      })
      .on("mouseout", hideTip);

    g.append("rect")
      .attr("class", d => lineLeafMode && (d.level === 2 || (state.drill && d.level === 1)) ? "node-box line-node-box" : "node-box")
      .attr("width", d => d.w)
      .attr("height", d => d.h)
      .attr("rx", 6)
      .attr("fill", "url(#nodeGrad)");

    g.each(function (d) {
      const group = d3.select(this);
      const stripX = 8;
      const asLineLeaf = lineLeafMode && (d.level === 2 || (state.drill && d.level === 1));
      const devH = asLineLeaf ? 0 : d.level === 2 ? (d.h <= 22 ? 5 : 7) : 7;
      const stripH = asLineLeaf ? 5 : d.level === 0 ? 18 : d.level === 1 ? 13 : (d.h <= 22 ? 7 : 11);
      const stripY = asLineLeaf ? Math.max(3, d.h / 2 - stripH / 2) : d.level === 2
        ? Math.max(3, (d.h - stripH - (state.showDeviation ? devH + 3 : 0)) / 2)
        : 24;
      const stripW = d.w - 16;
      const cellW = stripW / months.length;
      group.append("g")
        .selectAll("rect.heat-cell")
        .data(d.summary.monthCurve)
        .join("rect")
        .attr("class", "heat-cell")
        .attr("x", (_, i) => stripX + i * cellW)
        .attr("y", stripY)
        .attr("width", Math.max(.8, cellW - .3))
        .attr("height", stripH)
        .attr("fill", m => color(m.value));

      if (state.showDeviation && d.level > 0 && !asLineLeaf) {
        const rootCurve = partition.rootSummary.monthCurve;
        group.append("g")
          .selectAll("rect.deviation-cell")
          .data(d.summary.monthCurve)
          .join("rect")
          .attr("class", "deviation-cell")
          .attr("x", (_, i) => stripX + i * cellW)
          .attr("y", stripY + stripH + 3)
          .attr("width", Math.max(.8, cellW - .3))
          .attr("height", devH)
          .attr("fill", (m, i) => residualColor(m.value - rootCurve[i].value));
      }
    });

    g.append("text")
      .attr("x", d => state.drill && d.level === 1 ? -7 : 9)
      .attr("y", d => state.drill && d.level === 1 ? 10 : 15)
      .attr("text-anchor", d => state.drill && d.level === 1 ? "end" : "start")
      .attr("class", d => d.level === 0 ? "root-label" : state.drill && d.level === 1 ? "compact-month-label" : null)
      .text(d => state.drill && d.level === 1 ? "" : d.level === 2 ? "" : d.label);
    g.append("rect")
      .attr("class", "node-hit")
      .attr("width", d => d.w + (drillConfigForNode(d) ? drillCtaW + drillCtaGap : 0))
      .attr("height", d => d.h)
      .attr("rx", 6);

    const drillCta = g.filter(d => Boolean(drillConfigForNode(d)))
      .append("g")
      .attr("class", "node-drill-cta")
      .attr("transform", d => `translate(${d.w + drillCtaGap},0)`)
      .on("click", (event, d) => {
        event.stopPropagation();
        enterDrill(d);
      });
    drillCta.append("rect")
      .attr("width", drillCtaW)
      .attr("height", d => d.h)
      .attr("rx", d => Math.min(7, d.h / 2));
    drillCta.append("text")
      .attr("class", "drill-cta-arrow")
      .attr("x", 10)
      .attr("y", d => d.h / 2)
      .attr("dy", ".34em")
      .text("→");
    drillCta.append("text")
      .attr("class", "drill-cta-label")
      .attr("x", 27)
      .attr("y", d => d.h / 2)
      .attr("dy", ".34em")
      .text("月");

    if (state.drill) {
      const back = svg.append("g")
        .attr("class", "tree-drill-back")
        .attr("transform", "translate(12,12)")
        .on("click", event => {
          event.stopPropagation();
          leaveDrill();
        });
      back.append("rect")
        .attr("width", 104)
        .attr("height", 28)
        .attr("rx", 14);
      back.append("text")
        .attr("x", 52)
        .attr("y", 14)
        .attr("dy", ".35em")
        .attr("text-anchor", "middle")
        .text("← 返回上一级");
    }

    d3.select("#tree-status").text(contextText(active));
  }

  function drawTemporalChart(node) {
    const svg = d3.select("#temporal-chart");
    svg.selectAll("*").remove();
    const W = 460, H = 360;
    const m = { top:96, right:16, bottom:30, left:34 };
    const iw = W - m.left - m.right;
    const ih = H - m.top - m.bottom;
    svg.attr("viewBox", `0 0 ${W} ${H}`);
    const x = d3.scalePoint().domain(months).range([0, iw]).padding(.35);
    const y = d3.scaleLinear().domain([0, 1]).range([ih, 0]);
    const rootCurve = partition.rootSummary.monthCurve;
    const depthColors = new Map([
      ["0-10m", "#55d7ff"],
      ["50-100m", "#8ff0cf"],
      ["200m", "#f0c45c"]
    ]);
    const regionColors = new Map(regions.map((region, i) => [
      region,
      ["#55d7ff", "#8ff0cf", "#f0c45c", "#ff7f67", "#aa8cff", "#62d6b4"][i % 6]
    ]));
    const curveFor = filters => summary(subset(filters)).monthCurve;
    const selectedDepth = node.filters?.depths?.length === 1 ? node.filters.depths[0] : null;
    const selectedRegion = node.filters?.regions?.length === 1
      ? node.filters.regions[0]
      : state.focusRegion;
    let showBaseline = true;
    let series = [];
    if (state.split === "month") {
      const context = node.filters?.months ? { months:node.filters.months } : {};
      series = [
        {
          key:"all-depths",
          label:"全部深度",
          color:"#d9faff",
          curve:curveFor(context),
          active:!selectedDepth,
          aggregate:true
        },
        ...depths.map(depth => ({
          key:`depth-${depth}`,
          label:depth,
          color:depthColors.get(depth) || color(.5),
          curve:curveFor(combineFilters(context, { depths:[depth] })),
          active:selectedDepth === depth
        }))
      ];
    } else if (state.split === "region") {
      const context = node.filters?.months ? { months:node.filters.months } : {};
      series = regions.map(region => ({
        key:`region-${region}`,
        label:region,
        color:regionColors.get(region),
        curve:curveFor(combineFilters(context, { regions:[region] })),
        active:selectedRegion === region
      }));
    } else if (!selectedDepth) {
      series = depths.map(depth => ({
        key:`depth-${depth}`,
        label:depth,
        color:depthColors.get(depth) || color(.5),
        curve:curveFor({ depths:[depth] }),
        active:false
      }));
    } else {
      showBaseline = false;
      series = regions.map(region => ({
        key:`region-${region}`,
        label:region,
        color:regionColors.get(region),
        curve:curveFor({ depths:[selectedDepth], regions:[region] }),
        active:selectedRegion === region
      }));
    }
    const hasActive = series.some(d => d.active);
    const legendRows = [
      ...(showBaseline ? [{
        key:"baseline",
        label:"全部数据基线",
        color:"#9ec4d1",
        baseline:true,
        active:!hasActive
      }] : []),
      ...series
    ];
    const legendHtml = legendRows.map(d => `
      <span class="legend-line ${d.active ? "active" : hasActive && !d.baseline ? "dimmed" : ""}">
        <i style="--legend-color:${d.color}" class="${d.baseline || d.aggregate ? "dashed" : ""}"></i>
        <b>${d.label}</b>
      </span>
    `).join("");
    d3.select("#temporal-legend-tip").html(legendHtml);
    d3.select("#temporal-series-legend").html("");
    const g = svg.append("g").attr("transform", `translate(${m.left},${m.top})`);
    g.selectAll("line.grid-line")
      .data(y.ticks(4))
      .join("line")
      .attr("class", "grid-line")
      .attr("x1", 0).attr("x2", iw)
      .attr("y1", y).attr("y2", y);
    const line = d3.line().x(d => x(d.month)).y(d => y(d.value)).curve(d3.curveCatmullRom.alpha(.5));
    const rangeMonths = selectedRangeMonths();
    const showRangeBand = rangeMonths.length && !state.drill;
    if (showRangeBand) {
      const x0 = x(rangeMonths[0]);
      const x1 = x(rangeMonths[rangeMonths.length - 1]);
      const halfStep = Math.max(3, iw / Math.max(1, months.length - 1) * .42);
      g.append("rect")
        .attr("class", "temporal-range-band")
        .attr("x", Math.max(0, x0 - halfStep))
        .attr("y", -6)
        .attr("width", Math.min(iw, x1 + halfStep) - Math.max(0, x0 - halfStep))
        .attr("height", ih + 10);
    }
    if (showBaseline) {
      g.append("path").datum(rootCurve).attr("class", "root-line").attr("d", line);
    }
    const paths = g.selectAll("path.temporal-series")
      .data(series)
      .join("path")
      .attr("class", d => `temporal-series ${d.active ? "active" : hasActive ? "dimmed" : ""} ${d.aggregate ? "aggregate" : ""}`)
      .attr("stroke", d => d.color)
      .attr("d", d => line(d.curve))
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.label}</div><div class="tt-row"><span>分区维度</span><b>${splitNames[state.split]}</b></div><div class="tt-row"><span>${tensorNames[state.tensor]}</span><b>${fmt(mean(d.curve.filter(v => v.count), v => v.value))}</b></div>`))
      .on("mouseout", hideTip);
    paths.each(function (_, i) {
      const path = d3.select(this);
      const total = this.getTotalLength();
      path.attr("stroke-dasharray", `${total} ${total}`)
        .attr("stroke-dashoffset", total)
        .transition()
        .delay(i * 75)
        .duration(720)
        .ease(d3.easeCubicOut)
        .attr("stroke-dashoffset", 0)
        .on("end", function () {
          d3.select(this).attr("stroke-dasharray", null).attr("stroke-dashoffset", null);
        });
    });
    g.append("line")
      .attr("class", "month-cursor")
      .attr("x1", x(state.month)).attr("x2", x(state.month))
      .attr("y1", -6).attr("y2", ih + 4);
    const activeSeries = series.find(d => d.active);
    g.selectAll("circle.click-dot")
      .data(activeSeries ? activeSeries.curve : [])
      .join("circle")
      .attr("class", "click-dot")
      .attr("cx", d => x(d.month))
      .attr("cy", d => y(d.value))
      .attr("r", d => d.month === state.month ? 4.5 : 2.8)
      .attr("fill", d => d.month === state.month ? "#1d3345" : color(d.value))
      .on("click", (_, d) => {
        state.month = d.month;
        if (!state.drill) {
          state.monthStart = d.month;
          state.monthEnd = d.month;
          reconcileSelectedNodeWithRange();
        }
        render();
      })
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.month}</div><div class="tt-row"><span>${tensorNames[state.tensor]}</span><b>${fmt(d.value)}</b></div><div class="tt-row"><span>记录</span><b>${d.count}</b></div>`))
      .on("mouseout", hideTip);
    g.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`)
      .call(d3.axisBottom(x).tickValues(months.filter((_, i) => i % 6 === 0)).tickFormat(d => d.slice(2)));
    g.append("g").attr("class", "axis").call(d3.axisLeft(y).ticks(4));
  }

  function drawSpatialChart(node) {
    const svg = d3.select("#spatial-chart");
    svg.selectAll("*").remove();
    const W = 460, H = 360;
    const m = { top:68, right:32, bottom:34, left:76 };
    const iw = W - m.left - m.right;
    const ih = H - m.top - m.bottom;
    svg.attr("viewBox", `0 0 ${W} ${H}`);
    const context = {
      months:activeMonthsForNode(node),
      depths:node.filters?.depths
    };
    const data = regions.map(region => {
      const filters = combineFilters(context, { regions:[region] });
      const list = subset(filters);
      return {
        region,
        value:mean(list, tensorValue),
        count:list.length,
        active:node.filters?.regions?.length === 1 && node.filters.regions[0] === region
      };
    }).sort((a, b) => b.value - a.value);
    const valueSignature = data.map(d => `${d.region}:${d.count}:${d.value.toFixed(5)}`).join("|");
    const animateBars = chartSignatures.spatial !== valueSignature;
    chartSignatures.spatial = valueSignature;
    const x = d3.scaleLinear().domain([0, 1]).range([0, iw]);
    const y = d3.scaleBand().domain(data.map(d => d.region)).range([0, ih]).padding(.22);
    const g = svg.append("g").attr("transform", `translate(${m.left},${m.top})`);
    g.selectAll("line.grid-line").data(x.ticks(4)).join("line")
      .attr("class", "grid-line")
      .attr("x1", x).attr("x2", x).attr("y1", 0).attr("y2", ih);
    const row = g.selectAll("g.region-row").data(data).join("g")
      .attr("class", "region-row")
      .attr("transform", d => `translate(0,${y(d.region)})`)
      .classed("active-row", d => d.active)
      .on("click", (_, d) => {
        state.focusRegion = state.focusRegion === d.region ? null : d.region;
        render();
      })
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.region}</div><div class="tt-row"><span>${tensorNames[state.tensor]}</span><b>${fmt(d.value)}</b></div><div class="tt-row"><span>记录</span><b>${d.count}</b></div>`))
      .on("mouseout", hideTip);
    row.append("text").attr("class", "bar-label").attr("x", -8).attr("y", y.bandwidth() * .68).attr("text-anchor", "end").text(d => d.region);
    row.append("rect").attr("x", 0).attr("y", 1).attr("height", y.bandwidth() - 2).attr("rx", 3).attr("width", iw).attr("fill", "#e5eef3");
    const valueBar = row.append("rect")
      .attr("y", 1)
      .attr("height", y.bandwidth() - 2)
      .attr("rx", 3)
      .attr("fill", d => color(d.value))
      .attr("width", d => animateBars ? 0 : x(d.value));
    if (animateBars) {
      valueBar.transition().duration(620).attr("width", d => x(d.value));
    }
    row.append("text").attr("class", "bar-value").attr("x", d => x(d.value) + 5).attr("y", y.bandwidth() * .68).text(d => fmt(d.value));
    g.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x).ticks(4));
  }

  function drawDepthChart(node) {
    const svg = d3.select("#depth-chart");
    svg.selectAll("*").remove();
    const W = 460, H = 360;
    const m = { top:42, right:58, bottom:34, left:82 };
    const iw = W - m.left - m.right;
    const ih = H - m.top - m.bottom;
    svg.attr("viewBox", `0 0 ${W} ${H}`);
    const context = {
      months:activeMonthsForNode(node),
      regions:node.filters?.regions
    };
    const data = depths.map(depth => {
      const filters = combineFilters(context, { depths:[depth] });
      const list = subset(filters);
      return {
        depth,
        value:mean(list, tensorValue),
        count:list.length,
        active:node.filters?.depths?.length === 1 && node.filters.depths[0] === depth
      };
    });
    const valueSignature = data.map(d => `${d.depth}:${d.count}:${d.value.toFixed(5)}`).join("|");
    const animateBars = chartSignatures.depth !== valueSignature;
    chartSignatures.depth = valueSignature;
    const x = d3.scaleLinear().domain([0, 1]).range([0, iw]);
    const y = d3.scaleBand().domain(data.map(d => d.depth)).range([0, ih]).padding(.42);
    const g = svg.append("g").attr("transform", `translate(${m.left},${m.top})`);
    const row = g.selectAll("g.depth-row").data(data).join("g")
      .attr("class", "depth-row")
      .attr("transform", d => `translate(0,${y(d.depth)})`)
      .classed("active-row", d => d.active);
    row.append("text")
      .attr("class", "bar-label")
      .attr("x", -12)
      .attr("y", y.bandwidth() * .68)
      .attr("text-anchor", "end")
      .text(d => d.depth);
    row.append("rect")
      .attr("class", "depth-track")
      .attr("x", 0)
      .attr("y", 0)
      .attr("width", iw)
      .attr("height", y.bandwidth())
      .attr("rx", Math.min(8, y.bandwidth() / 2));
    const valueBar = row.append("rect")
      .attr("class", "depth-bar")
      .attr("x", 0)
      .attr("y", 0)
      .attr("height", y.bandwidth())
      .attr("rx", Math.min(8, y.bandwidth() / 2))
      .attr("fill", d => color(d.value))
      .attr("width", d => animateBars ? 0 : x(d.value));
    if (animateBars) {
      valueBar.transition()
        .duration(650)
        .attr("width", d => x(d.value));
    }
    row.append("text")
      .attr("class", "bar-value depth-value")
      .attr("x", iw + 8)
      .attr("y", y.bandwidth() * .68)
      .text(d => fmt(d.value));
    g.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x).ticks(4));
  }

  function drawResidualChart(node) {
    const svg = d3.select("#residual-chart");
    svg.selectAll("*").remove();
    const W = 460, H = 360;
    const m = { top:66, right:16, bottom:28, left:62 };
    const iw = W - m.left - m.right;
    const ih = H - m.top - m.bottom;
    svg.attr("viewBox", `0 0 ${W} ${H}`);
    const activeMonths = activeMonthsForNode(node);
    const selectedMonths = activeMonths.length < months.length || node.filters?.months?.length ? activeMonths : null;
    const selectedRegions = node.filters?.regions?.length ? node.filters.regions : null;
    const selectedDepths = node.filters?.depths?.length ? node.filters.depths : null;
    const matrixFilters = selectedDepths ? { depths:selectedDepths } : {};
    const matrixRecords = subset(matrixFilters);
    const monthBaseline = new Map(months.map(mo => {
      const list = matrixRecords.filter(d => d.month_label === mo);
      return [mo, mean(list, tensorValue)];
    }));
    const data = [];
    regions.forEach(r => {
      months.forEach(mo => {
        const sub = matrixRecords.filter(d => d.region_name === r && d.month_label === mo);
        const val = sub.length ? mean(sub, tensorValue) : null;
        const base = monthBaseline.get(mo) || 0;
        const inSelectedMonth = !selectedMonths || selectedMonths.includes(mo);
        const inSelectedRegion = !selectedRegions || selectedRegions.includes(r);
        data.push({
          region:r,
          month:mo,
          value:val == null ? null : val - base,
          count:sub.length,
          selected:inSelectedMonth && inSelectedRegion
        });
      });
    });
    const residualMax = Math.max(.025, d3.max(data, d => d.value == null ? 0 : Math.abs(d.value)) || .025);
    const residualCellColor = value => residualTone(value, residualMax);
    const x = d3.scaleBand().domain(months).range([0, iw]).padding(.03);
    const y = d3.scaleBand().domain(regions).range([0, ih]).padding(.08);
    const g = svg.append("g").attr("transform", `translate(${m.left},${m.top})`);
    g.selectAll("rect")
      .data(data)
      .join("rect")
      .attr("class", d => {
        const hasSelection = Boolean(selectedMonths || selectedRegions);
        return [
          "residual-cell",
          hasSelection ? (d.selected ? "selected-selection" : "outside-selection") : ""
        ].filter(Boolean).join(" ");
      })
      .attr("x", d => x(d.month))
      .attr("y", d => y(d.region))
      .attr("width", x.bandwidth())
      .attr("height", y.bandwidth())
      .attr("fill", d => d.count ? residualCellColor(d.value) : "rgba(255,255,255,.08)")
      .on("mousemove", (ev, d) => showTip(ev, `<div class="tt-title">${d.region} · ${d.month}</div><div class="tt-row"><span>残差</span><b>${fmt(d.value)}</b></div><div class="tt-row"><span>记录</span><b>${d.count}</b></div>`))
      .on("mouseout", hideTip);
    if (selectedMonths || selectedRegions) {
      const monthRange = selectedMonths?.filter(mo => x(mo) != null);
      const regionRange = selectedRegions?.filter(r => y(r) != null);
      const x0 = monthRange?.length ? d3.min(monthRange, mo => x(mo)) : 0;
      const x1 = monthRange?.length ? d3.max(monthRange, mo => x(mo) + x.bandwidth()) : iw;
      const y0 = regionRange?.length ? d3.min(regionRange, r => y(r)) : 0;
      const y1 = regionRange?.length ? d3.max(regionRange, r => y(r) + y.bandwidth()) : ih;
      g.append("rect")
        .attr("class", "residual-selection-frame")
        .attr("x", Math.max(-2, x0 - 2))
        .attr("y", Math.max(-2, y0 - 2))
        .attr("width", Math.min(iw + 4, x1 - x0 + 4))
        .attr("height", Math.min(ih + 4, y1 - y0 + 4));
    }
    g.selectAll("text.res-label").data(regions).join("text")
      .attr("class", "res-label")
      .attr("x", -8).attr("y", d => y(d) + y.bandwidth() * .66)
      .attr("text-anchor", "end").text(d => d);
    g.selectAll("text.month-tick").data(months.filter((_, i) => i % 6 === 0)).join("text")
      .attr("class", "axis-text")
      .attr("x", d => x(d) + x.bandwidth() / 2)
      .attr("y", ih + 16)
      .attr("text-anchor", "middle")
      .text(d => d.slice(2));
  }

  function currentMapRecords(region) {
    const node = selectedNode();
    const activeMonths = new Set(activeMonthsForNode(node));
    const nodeFilters = filtersWithoutMonths(node.filters);
    return records.filter(d => {
      if (region && d.region_name !== region) return false;
      if (!activeMonths.has(d.month_label)) return false;
      if (state.focusDepth && d.depth_group !== state.focusDepth) return false;
      return matchesFilter(d, nodeFilters);
    });
  }

  function drawMap() {
    const svg = d3.select("#tensor-map");
    svg.selectAll("*").remove();
    const mapBox = svg.node().getBoundingClientRect();
    const W = Math.max(320, Math.round(mapBox.width || 420));
    const H = Math.max(520, Math.round(mapBox.height || 620));
    svg.attr("viewBox", `0 0 ${W} ${H}`)
      .attr("preserveAspectRatio", "xMidYMid meet")
      .classed("map-has-region-focus", !!state.focusRegion);
    const defs = svg.append("defs");
    const seaGrad = defs.append("linearGradient").attr("id", "tensor-sea-grad").attr("x1", "0").attr("y1", "0").attr("x2", "1").attr("y2", "1");
    seaGrad.append("stop").attr("offset", "0%").attr("stop-color", "#09263d");
    seaGrad.append("stop").attr("offset", "52%").attr("stop-color", "#061827");
    seaGrad.append("stop").attr("offset", "100%").attr("stop-color", "#030b14");
    const currentGrad = defs.append("linearGradient").attr("id", "tensor-current-grad").attr("x1", "0").attr("y1", "0").attr("x2", "1").attr("y2", "0");
    currentGrad.append("stop").attr("offset", "0%").attr("stop-color", "#4d9fbd").attr("stop-opacity", 0);
    currentGrad.append("stop").attr("offset", "50%").attr("stop-color", "#4d9fbd").attr("stop-opacity", .46);
    currentGrad.append("stop").attr("offset", "100%").attr("stop-color", "#4d9fbd").attr("stop-opacity", 0);
    const arrow = defs.append("marker")
      .attr("id", "flow-arrow")
      .attr("viewBox", "0 -4 8 8")
      .attr("refX", 7)
      .attr("refY", 0)
      .attr("markerWidth", 5)
      .attr("markerHeight", 5)
      .attr("orient", "auto");
    arrow.append("path").attr("class", "flow-arrow-head").attr("d", "M0,-3 L7,0 L0,3 Z");
    svg.append("rect").attr("class", "sea-wash").attr("x", 0).attr("y", 0).attr("width", W).attr("height", H).attr("fill", "#03111c");

    const M = { top:16, right:18, bottom:20, left:22 };
    const projection = d3.geoMercator().fitExtent([[M.left, M.top], [W - M.right, H - M.bottom]], {
      type:"Polygon",
      coordinates:[[[107.5,18],[107.5,41.5],[126.5,41.5],[126.5,18],[107.5,18]]]
    });
    const path = d3.geoPath(projection);
    const selected = selectedNode();
    function projectedCenter(r) {
      const feature = GEO.features.find(f => {
        const p = f.properties || {};
        return (p.region_name || p.region) === r;
      });
      return projection(regionCenters.get(r) || (feature ? d3.geoCentroid(feature) : [117, 30]));
    }

    const grat = d3.geoGraticule().step([4,5]).extent([[107.5,18],[126.5,41.5]]);
    svg.append("path").datum(grat()).attr("class", "map-grid").attr("d", path);
    drawOceanContext(svg, projection, W, H);
    if (CHI && CHI.basemap) {
      svg.append("g").selectAll("path")
        .data(CHI.basemap.land || [])
        .join("path")
        .attr("class", "land")
        .attr("d", path);
      svg.append("g").selectAll("path")
        .data(CHI.basemap.coastlines || [])
        .join("path")
        .attr("class", "coastline")
        .attr("d", path);
    }

    const regionStats = new Map(regions.map(r => {
      const list = currentMapRecords(r);
      return [r, summary(list)];
    }));

    svg.append("g")
      .selectAll("path")
      .data(GEO.features)
      .join("path")
      .attr("class", d => {
        const name = d.properties.region_name || d.properties.region;
        return `region-shape ${
          !state.focusRegion ? "" :
          state.focusRegion === name ? "focused" : "dim"
        }`;
      })
      .attr("d", path)
      .on("click", (_, d) => {
        const name = d.properties.region_name || d.properties.region;
        selectRegionFromMap(name);
      })
      .on("mousemove", (ev, d) => {
        const name = d.properties.region_name || d.properties.region;
        const s = regionStats.get(name);
        showTip(ev, `<div class="tt-title">${name} · ${periodLabel(activeMonthsForNode(selectedNode()))}</div>
          <div class="tt-row"><span>缺氧压力</span><b>${fmt(s?.hypoxia || 0)}</b></div>
          <div class="tt-row"><span>酸化压力</span><b>${fmt(s?.acid || 0)}</b></div>
          <div class="tt-row"><span>复合压力</span><b>${fmt(s?.compound || 0)}</b></div>`);
      })
      .on("mouseout", hideTip);

    const glyphRadius = Math.max(17, Math.min(24, W * .058));
    const ringRadius = glyphRadius + 6;
    const ringPath = (radius, startAngle, endAngle) => {
      const sx = Math.sin(startAngle) * radius;
      const sy = -Math.cos(startAngle) * radius;
      const ex = Math.sin(endAngle) * radius;
      const ey = -Math.cos(endAngle) * radius;
      const large = endAngle - startAngle > Math.PI ? 1 : 0;
      return `M${sx},${sy} A${radius},${radius} 0 ${large} 1 ${ex},${ey}`;
    };
    const glyphLayer = svg.append("g").attr("class", "glyph-layer");
    const glyph = glyphLayer
      .selectAll("g.glyph")
      .data(regions)
      .join("g")
      .attr("transform", r => {
        const c = projectedCenter(r);
        return `translate(${c[0]},${c[1]})`;
      })
      .attr("class", r => `glyph ${state.focusRegion && state.focusRegion !== r ? "dimmed" : "active"}`)
      .on("click", (event, r) => {
        event.stopPropagation();
        selectRegionFromMap(r);
      })
      .on("mousemove", (ev, r) => {
        const s = regionStats.get(r);
        showTip(ev, `<div class="tt-title">${r} · ${periodLabel(activeMonthsForNode(selectedNode()))}</div>
          <div class="tt-row"><span>复合压力</span><b>${fmt(s?.compound || 0)}</b></div>
          <div class="tt-row"><span>缺氧压力</span><b>${fmt(s?.hypoxia || 0)}</b></div>
          <div class="tt-row"><span>酸化压力</span><b>${fmt(s?.acid || 0)}</b></div>`);
      })
      .on("mouseout", hideTip);

    glyph.append("circle")
      .attr("class", "glyph-base")
      .attr("r", glyphRadius)
      .style("--risk-fill", r => color(regionStats.get(r)?.[state.tensor] || 0));
    glyph.each(function (r) {
      const s = regionStats.get(r) || {};
      const parts = [
        { key:"hypoxia", start:0, end:Math.PI * 2 / 3, color:"#54ad8b" },
        { key:"acid", start:Math.PI * 2 / 3, end:Math.PI * 4 / 3, color:"#ee8f54" },
        { key:"compound", start:Math.PI * 4 / 3, end:Math.PI * 2, color:"#aa7cc6" }
      ];
      d3.select(this).selectAll("path.glyph-ring")
        .data(parts)
        .join("path")
        .attr("class", "glyph-ring")
        .attr("pathLength", 100)
        .attr("stroke", d => d.color)
        .attr("opacity", d => .66 + .34 * (s[d.key] || 0))
        .attr("d", d => ringPath(ringRadius, d.start, d.start + (d.end - d.start) * clamp(s[d.key] || 0)));
    });

    glyph.append("text")
      .attr("class", "glyph-value")
      .attr("text-anchor", "middle")
      .attr("dy", "-0.12em")
      .text(r => fmt(regionStats.get(r)?.[state.tensor] || 0));

    glyph.append("text")
      .attr("class", "glyph-caption")
      .attr("text-anchor", "middle")
      .attr("dy", "1.1em")
      .text(tensorShortNames[state.tensor]);

    glyph.append("text")
      .attr("class", "map-label")
      .attr("x", glyphRadius + 15)
      .attr("y", 5)
      .text(d => d);

    const flowStreams = regions.flatMap((r, ri) => {
      const list = currentMapRecords(r);
      const u = mean(list, d => +d.phy_uo || 0);
      const vy = -(mean(list, d => +d.phy_vo || 0));
      const rawNorm = Math.hypot(u, vy);
      const fallbackAngle = -Math.PI / 3 + ri * .28;
      const ux = rawNorm < .002 ? Math.cos(fallbackAngle) : u / rawNorm;
      const uy = rawNorm < .002 ? Math.sin(fallbackAngle) : vy / rawNorm;
      const px = -uy;
      const py = ux;
      const c = projectedCenter(r);
      const intensity = clamp(rawNorm / .035);
      const streamLen = 34 + intensity * 26;
      return [-1, 0, 1].map((offset, j) => {
        const side = offset * (glyphRadius * .55);
        const start = glyphRadius + 18 + j * 3;
        const x0 = c[0] + ux * start + px * side;
        const y0 = c[1] + uy * start + py * side;
        const x1 = c[0] + ux * (start + streamLen) + px * side;
        const y1 = c[1] + uy * (start + streamLen) + py * side;
        const cx = c[0] + ux * (start + streamLen * .52) + px * (side + (j - 1) * 7);
        const cy = c[1] + uy * (start + streamLen * .52) + py * (side + (j - 1) * 7);
        return {
          r,
          d:`M${x0},${y0} Q${cx},${cy} ${x1},${y1}`,
          delay:`${(ri * .16 + j * .1).toFixed(2)}s`,
          opacity:.24 + intensity * .32,
          active:!state.focusRegion || state.focusRegion === r
        };
      });
    });
    const streamLayer = svg.insert("g", ".glyph-layer").attr("class", "flow-stream-layer");
    streamLayer
      .selectAll("path.flow-stream")
      .data(flowStreams)
      .join("path")
      .attr("class", d => `flow-stream ${d.active ? "active" : "dimmed"}`)
      .attr("d", d => d.d)
      .attr("opacity", d => d.opacity)
      .style("--delay", d => d.delay)
      .attr("marker-end", "url(#flow-arrow)");

    svg.append("text")
      .attr("class", "map-note")
      .attr("x", 14)
      .attr("y", H - 14)
      .text(`${selected.label} · ${periodLabel(activeMonthsForNode(selected))} · ${state.focusDepth || "全部深度"} · ${state.focusRegion || "全部海域"}`);
  }

  function drawOceanContext(svg, projection) {
    const bath = [
      [[109,20.5],[112,21.4],[116,22.1],[120,23.1],[124,24.7]],
      [[110,24.5],[114,25.4],[118,26.7],[122,28.6],[125.5,30.4]],
      [[111,29.2],[114,30.4],[118,31.7],[122.5,33.1],[125.5,35.0]],
      [[113.5,36.2],[117,36.8],[121,37.5],[124.5,38.8]]
    ];
    const currents = [
      [[120.2,22.2],[121.3,24.1],[122.2,26.3],[122.6,28.8],[123.0,31.2]],
      [[117.0,20.4],[118.8,22.2],[120.4,24.6],[121.4,27.0]],
      [[122.5,32.5],[121.4,34.2],[120.2,36.0],[119.0,38.2]]
    ];
    const line = d3.line().x(d => projection(d)[0]).y(d => projection(d)[1]).curve(d3.curveCatmullRom.alpha(.5));
    svg.append("g").selectAll("path.bath-line")
      .data(bath)
      .join("path")
      .attr("class", "bath-line")
      .attr("d", line);
    svg.append("g").selectAll("path.current-line")
      .data(currents)
      .join("path")
      .attr("class", "current-line")
      .attr("stroke", "url(#tensor-current-grad)")
      .attr("d", line);
    const labels = [
      { text:"BOHAI SEA", pos:[119.4,39.3] },
      { text:"YELLOW SEA", pos:[123.2,35.2] },
      { text:"EAST CHINA SEA", pos:[123.5,28.1] },
      { text:"NORTHERN SOUTH CHINA SEA", pos:[114.2,21.1] }
    ];
    svg.append("g").selectAll("text.sea-label")
      .data(labels)
      .join("text")
      .attr("class", "sea-label")
      .attr("x", d => projection(d.pos)[0])
      .attr("y", d => projection(d.pos)[1])
      .attr("text-anchor", "middle")
      .attr("transform", d => `rotate(-12 ${projection(d.pos)[0]} ${projection(d.pos)[1]})`)
      .text(d => d.text);
  }

  function varianceForDimension(list, dim) {
    const values = (dim === "month" ? months : dim === "region" ? regions : depths).map(key => {
      const sub = list.filter(d => dim === "month" ? d.month_label === key : dim === "region" ? d.region_name === key : d.depth_group === key);
      return mean(sub, tensorValue);
    });
    return d3.variance(values) || 0;
  }

  function drawSteerPanel(node) {
    const activeMonths = activeMonthsForNode(node);
    const activeFilters = effectiveNodeFilters(node);
    const s = summary(subset(activeFilters));
    const yearValue = activeMonths.length < months.length || node.filters?.months?.length
      ? periodLabel(activeMonths)
      : "全部年份";
    const regionValue = node.filters?.regions?.length
      ? node.filters.regions.join("、")
      : "全部海域";
    const depthValue = node.filters?.depths?.length
      ? node.filters.depths.join("、")
      : "全部深度";
    const dimensionMetrics = state.split === "month"
      ? [
          { label:"年份", value:yearValue },
          { label:"深度", value:depthValue }
        ]
      : state.split === "region"
      ? [
          { label:"海域", value:regionValue },
          { label:"年份", value:yearValue }
        ]
      : [
          { label:"深度", value:depthValue },
          { label:"海域", value:regionValue }
        ];
    d3.select("#node-summary").html(`
      <div class="summary-title">当前数据分区</div>
      <div class="summary-grid">
        ${dimensionMetrics.map(metric => `
          <div class="metric"><span>${metric.label}</span><b>${metric.value}</b></div>
        `).join("")}
        <div class="metric"><span>记录数</span><b>${intFmt(s.count)}</b></div>
        <div class="metric compound"><span>复合压力</span><b>${fmt(s.compound)}</b></div>
        <div class="metric hypoxia"><span>缺氧压力</span><b>${fmt(s.hypoxia)}</b></div>
        <div class="metric acid"><span>酸化压力</span><b>${fmt(s.acid)}</b></div>
      </div>
    `);

    const rootCurve = partition.rootSummary.monthCurve;
    const selectedMonths = state.drill?.months?.length
      ? state.drill.months
      : activeMonths.length < months.length || node.filters?.months?.length
      ? activeMonths
      : null;
    const displayFilters = {
      regions:node.filters?.regions,
      depths:node.filters?.depths
    };
    const hasContextFilter = Boolean(displayFilters.regions?.length || displayFilters.depths?.length);
    const rootMean = mean(rootCurve.filter(d => d.count), d => d.value);
    const displayCurve = selectedMonths
      ? summary(subset(displayFilters)).monthCurve
      : node.summary.monthCurve;
    const monthRows = displayCurve.map((month, i) => ({
      ...month,
      deviation:month.value - (hasContextFilter ? rootCurve[i].value : rootMean),
      selected:!selectedMonths || selectedMonths.includes(month.month)
    }));
    const detailBaselineRows = selectedMonths
      ? monthRows.filter(d => d.count && d.selected)
      : [];
    const detailLocalBaseline = detailBaselineRows.length
      ? mean(detailBaselineRows, d => d.value)
      : null;
    monthRows.forEach(d => {
      d.detailDeviation = detailLocalBaseline == null ? d.deviation : d.value - detailLocalBaseline;
    });
    const detailResidualFallbackRows = monthRows.filter(d => d.count);
    const detailResidualExtent = Math.max(
      .025,
      d3.max(detailResidualFallbackRows, d => Math.abs(d.detailDeviation)) || .025
    );
    const insightRows = s.monthCurve.filter(d => d.count);
    const populated = insightRows;
    const peak = populated.length ? populated.reduce((a, b) => b.value > a.value ? b : a) : null;
    const low = populated.length ? populated.reduce((a, b) => b.value < a.value ? b : a) : null;
    const insightDeviations = insightRows.map(d => {
      const i = monthIndex.get(d.month) || 0;
      return { ...d, deviation:d.value - rootCurve[i].value };
    });
    const strongestDeviation = insightDeviations.length
      ? insightDeviations.reduce((a, b) => Math.abs(b.deviation) > Math.abs(a.deviation) ? b : a)
      : null;
    const pressureCells = monthRows.map(d => `
      <i class="detail-strip-cell ${d.selected ? "selected-period" : "outside-period"}"
        style="--cell-color:${d.count ? color(d.value) : "rgba(255,255,255,.055)"}"
        title="${d.month}：${tensorNames[state.tensor]} ${fmt(d.value)}，记录 ${d.count} 条"></i>
    `).join("");
    const deviationCells = monthRows.map(d => `
      <i class="detail-strip-cell ${d.selected ? "selected-period" : "outside-period"}"
        style="--cell-color:${d.count ? residualTone(d.detailDeviation, detailResidualExtent) : "rgba(255,255,255,.055)"}"
        title="${d.month}：相对全部数据 ${d.deviation >= 0 ? "+" : ""}${fmt(d.deviation)}"></i>
    `).join("");
    const selectionStart = selectedMonths ? monthIndex.get(selectedMonths[0]) || 0 : 0;
    const selectionWidth = selectedMonths ? selectedMonths.length : 0;
    const activeMonthIndex = state.drill && state.month ? monthIndex.get(state.month) : null;
    const showDeviation = node.level !== 0;
    d3.select("#partition-detail").html(`
      <div class="detail-head">
        <div>
          <div class="detail-title">分区详情 · ${contextText(node)}</div>
        </div>
        <div class="detail-pressure">
          <span>缺氧 <b>${fmt(s.hypoxia)}</b></span>
          <span>酸化 <b>${fmt(s.acid)}</b></span>
          <span>复合 <b>${fmt(s.compound)}</b></span>
          <span>O2 <b>${fmt(s.o2)}</b></span>
          <span>pH <b>${fmt(s.ph)}</b></span>
        </div>
      </div>
      <div class="detail-bands ${showDeviation ? "" : "single-band"}">
        <div class="detail-band-grid">
          <div class="detail-band-labels">
          <div class="detail-band-label">
              <b>月份压力变化 <i class="detail-info-icon" data-tip="展示各月份的压力强度。颜色由蓝色、青色、黄色到红色逐渐升高；选择年份时，该年份保持明亮，其他年份降低亮度。">i</i></b>
          </div>
            ${showDeviation ? `
          <div class="detail-band-label">
                <b>相对基线偏差 <i class="detail-info-icon" data-tip="年份分区时比较各月份相对整体平均压力的偏差；叠加海域或深度分区时比较当前分区与同月份全局值的差异。蓝色表示偏低，深色表示接近，红色表示偏高。">i</i></b>
          </div>
            ` : ""}
          </div>
          <div class="detail-strips-wrap"
            style="--selection-left:${selectionStart / months.length * 100}%;--selection-width:${selectionWidth / months.length * 100}%;--active-month-left:${activeMonthIndex == null ? 0 : activeMonthIndex / months.length * 100}%;--active-month-width:${1 / months.length * 100}%">
            <div class="detail-strip">${pressureCells}</div>
            ${showDeviation ? `<div class="detail-strip">${deviationCells}</div>` : ""}
            ${selectedMonths ? `<i class="detail-year-selection"></i>` : ""}
            ${activeMonthIndex == null ? "" : `<i class="detail-month-selection"></i>`}
          </div>
        </div>
        <div class="detail-year-axis">
          <span>2023</span><span>2024</span><span>2025</span>
        </div>
      </div>
      <div class="detail-insights">
        <div>
          <span>压力峰值</span>
          <b>${peak ? `<i>${peak.month}</i><em>${fmt(peak.value)}</em>` : "暂无"}</b>
        </div>
        <div>
          <span>压力低值</span>
          <b>${low ? `<i>${low.month}</i><em>${fmt(low.value)}</em>` : "暂无"}</b>
        </div>
        <div>
          <span>${showDeviation ? "最大偏差" : "压力变化幅度"}</span>
          <b>${showDeviation
            ? strongestDeviation
              ? `<i>${strongestDeviation.month}</i><em>${strongestDeviation.deviation >= 0 ? "+" : ""}${fmt(strongestDeviation.deviation)}</em>`
              : "暂无"
            : peak && low ? `<em>${fmt(peak.value - low.value)}</em>` : "暂无"}</b>
        </div>
        <div><span>时间覆盖</span><b>${populated.length} / ${activeMonths.length}</b></div>
      </div>
    `);
  }

  function render() {
    buildPartition();
    updateControls();
    const node = selectedNode();
    const activeCount = subset(effectiveNodeFilters(node)).length;
    d3.select("#node-status").text(`${node.label} · ${intFmt(activeCount)} 条`);
    drawPartitionTree();
    drawActivePattern(node);
    drawMap();
    drawSteerPanel(node);
  }

  function drawActivePattern(node = selectedNode()) {
    d3.selectAll("#temporal-chart, #spatial-chart, #depth-chart, #residual-chart").selectAll("*").remove();
    if (state.patternChart === "temporal") drawTemporalChart(node);
    if (state.patternChart === "spatial") drawSpatialChart(node);
    if (state.patternChart === "depth") drawDepthChart(node);
    if (state.patternChart === "residual") drawResidualChart(node);
  }

  function bindEvents() {
    d3.selectAll("[data-tensor]").on("click", function () {
      state.tensor = this.dataset.tensor;
      render();
    });
    d3.selectAll("[data-split]").on("click", function () {
      state.split = this.dataset.split;
      state.drill = null;
      state.selectedNodeId = "root";
      state.previousNodeId = null;
      state.focusRegion = null;
      state.focusDepth = null;
      render();
    });
    d3.selectAll("[data-chart]").on("click", function () {
      state.patternChart = this.dataset.chart;
      updateControls();
      drawActivePattern();
    });
    d3.select("#deviation-toggle").on("change", function () {
      state.showDeviation = this.checked;
      render();
    });
    d3.selectAll("#month-start-slider, #month-end-slider")
      .attr("max", months.length - 1)
      .on("input", function () {
        let start = +d3.select("#month-start-slider").property("value");
        let end = +d3.select("#month-end-slider").property("value");
        if (start > end) {
          if (this.id === "month-start-slider") end = start;
          else start = end;
        }
        state.monthStart = months[start] || months[0];
        state.monthEnd = months[end] || months[months.length - 1];
        const range = selectedRangeMonths();
        state.month = range.includes(state.month) ? state.month : state.monthStart;
        reconcileSelectedNodeWithRange();
        render();
      });
    let draggingRangeHandle = null;
    const indexFromPointer = event => {
      const node = d3.select(".dual-range").node();
      const rect = node.getBoundingClientRect();
      const inset = 8;
      const usable = Math.max(1, rect.width - inset * 2);
      const ratio = clamp((event.clientX - rect.left - inset) / usable);
      return Math.round(ratio * (months.length - 1));
    };
    const applyRangeIndex = (index, handle) => {
      let [start, end] = rangeIndexes();
      if (handle === "start") start = Math.min(index, end);
      else end = Math.max(index, start);
      state.monthStart = months[start] || months[0];
      state.monthEnd = months[end] || months[months.length - 1];
      const range = selectedRangeMonths();
      state.month = range.includes(state.month) ? state.month : state.monthStart;
      reconcileSelectedNodeWithRange();
      render();
    };
    d3.select("#month-start-handle").on("pointerdown", function (event) {
      event.preventDefault();
      event.stopPropagation();
      draggingRangeHandle = "start";
      this.setPointerCapture?.(event.pointerId);
      applyRangeIndex(indexFromPointer(event), draggingRangeHandle);
    });
    d3.select("#month-end-handle").on("pointerdown", function (event) {
      event.preventDefault();
      event.stopPropagation();
      draggingRangeHandle = "end";
      this.setPointerCapture?.(event.pointerId);
      applyRangeIndex(indexFromPointer(event), draggingRangeHandle);
    });
    d3.select(".dual-range").on("pointerdown", function (event) {
      if (event.target.classList.contains("dual-range-handle")) return;
      event.preventDefault();
      const index = indexFromPointer(event);
      const [start, end] = rangeIndexes();
      draggingRangeHandle = Math.abs(index - start) <= Math.abs(index - end) ? "start" : "end";
      this.setPointerCapture?.(event.pointerId);
      applyRangeIndex(index, draggingRangeHandle);
    });
    d3.select(window)
      .on("pointermove.hypoxiaRange", event => {
        if (!draggingRangeHandle) return;
        applyRangeIndex(indexFromPointer(event), draggingRangeHandle);
      })
      .on("pointerup.hypoxiaRange pointercancel.hypoxiaRange", () => {
        draggingRangeHandle = null;
      });
    d3.select("#play-btn").on("click", () => {
      state.playing = !state.playing;
      if (state.playing) {
        timer = setInterval(() => {
          const [start, end] = rangeIndexes();
          const span = end - start;
          const nextStart = end >= months.length - 1 ? 0 : start + 1;
          const nextEnd = Math.min(months.length - 1, nextStart + span);
          state.monthStart = months[nextStart];
          state.monthEnd = months[nextEnd];
          state.month = state.monthStart;
          reconcileSelectedNodeWithRange();
          render();
        }, 900);
      } else {
        clearInterval(timer);
      }
      updateControls();
    });
    window.addEventListener("resize", () => render());
  }

  bindEvents();
  render();
})();
